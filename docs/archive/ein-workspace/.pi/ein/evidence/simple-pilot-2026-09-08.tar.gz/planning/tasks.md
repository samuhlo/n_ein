# Tasks — supervised cheap executor pilot

status: ready
blocked_by: none

## // 001. fechas

- outcome: fechaInicio accepts only exact calendar dates while preserving the request schema contract.

- [ ] 1.1 Add strict calendar validation to fechaInicio without changing other fields.
  - skills: none
  - why: A nonempty string currently accepts malformed dates and impossible calendar days.
  - learn: Date shape and calendar validity are separate checks; automatic date normalization can hide invalid input.
  - architecture: Keep validation in generateBodySchema, with any private calendar helper inside this source file; preserve exports, inferred field types, and passthrough.
  - avoid: Do not use permissive Date parsing, coerce or trim input, introduce timezone logic, or add domain restrictions such as holidays or minimum years.
  - read: `design.md`, `cases/fechas/source.ts`, `cases/fechas/visible.test.ts`, `tsconfig.json`
  - edit: `cases/fechas/source.ts` | modify | Retain the existing string minimum-length check and its fechaInicio requerido message. Append a calendar refinement that lets the empty string pass the refinement so only the existing required check rejects it. For nonempty strings require exactly 10 characters, ASCII digits in four-digit year and two-digit month/day positions, and hyphens at positions 5 and 8. Parse those components numerically; require month 1–12 and day 1 through that month's length. Under strict and noUncheckedIndexedAccess, numeric month bounds do not narrow an indexed array lookup: after rejecting out-of-range months, store daysInMonth[month - 1] in a local monthLength, explicitly return false if monthLength === undefined, and only then compare the day against monthLength. Do not use non-null assertions, type assertions, compiler suppressions, or relaxed compiler options to bypass this check. Use Gregorian leap-year arithmetic (divisible by 4 except centuries not divisible by 400) for February; add no year bounds beyond the four-digit shape. Use fechaInicio debe ser una fecha válida YYYY-MM-DD for nonempty invalid dates. Leave the rest of the schema unchanged.
  - behavior: Valid dates including 2024-02-29 and 2000-02-29 pass unchanged; 2023-02-29, 1900-02-29, April 31, zero month/day, missing padding, whitespace, trailing newlines, and timestamp suffixes fail. Empty input retains the required message; extra object keys and unrelated fields retain existing behavior.
  - stop: Return control if preserving the existing schema type or empty-input error requires changing anything outside this case's source file.
  - verify: `bun test cases/fechas/visible.test.ts`
  - verify: `tsc --noEmit -p tsconfig.json`

## // 002. horario

- outcome: Complete schedule preferences obey the exact start-time grid and inclusive 21:00 end limit.

- [ ] 2.1 Validate the start-time format, bounds, and quarter-hour grid before computing the end time.
  - skills: none
  - why: The current parser accepts single-digit hours and out-of-range clock components.
  - learn: Validate clock components before converting to minutes; a final-time check alone cannot establish valid input.
  - architecture: Keep all decisions in validarHorario and preserve its input/output types, nullish short circuit, and incompatible reason.
  - avoid: Do not introduce defaults, trim time strings, validate incomplete pairs, or infer valid minutes solely from the computed end time.
  - read: `design.md`, `cases/horario/source.ts`, `cases/horario/visible.test.ts`
  - edit: `cases/horario/source.ts` | modify | Keep the missing/null horas-or-hora return first and the existing 4/5/6 hours check. Require the supplied time string to have exactly five characters consisting of two ASCII hour digits, a colon, and two ASCII minute digits. After parsing, reject hours outside 8–20 and minutes other than 0, 15, 30, or 45. Only then calculate start and end minutes; retain rejection only when the end exceeds MAX_END_MINUTES. Route every invalid complete pair to the existing incompatible result and preserve all exports.
  - behavior: Missing pieces remain ok without defaults. Complete pairs reject 8:00, 07:45, 21:00, 08:60, 08:10, and suffixed strings. 17:00 with 4 hours passes at exactly 21:00; 17:15 with 4 hours fails. A grid-valid start such as 20:45 still fails if its duration crosses 21:00.
  - stop: Return control if satisfying the time contract requires changing the exported schedule types or missing-piece behavior rather than this source's validation alone.
  - verify: `bun test cases/horario/visible.test.ts`

## // 003. progreso

- outcome: Every progress payload contains finite, sanitized counts and ratios derived from those same counts.

- [ ] 3.1 Sanitize total and hechos before computing or returning progress.
  - skills: none
  - why: Fractional counts and infinite completed values currently leak into the returned payload despite ratio clamping.
  - learn: Sanitizing only a derived ratio does not sanitize the authoritative counts exposed beside it.
  - architecture: Keep the numerical contract inside calcularProgresoEvaluable; retain its signature, ProgresoEvaluable, and the existing local clamp helper.
  - avoid: Do not round counts, divide by the original total, treat positive infinity as completion, impose safe-integer caps, or change consumers.
  - read: `design.md`, `cases/progreso/source.ts`, `cases/progreso/visible.test.ts`
  - edit: `cases/progreso/source.ts` | modify | Return the existing all-zero payload for a nonfinite total. Truncate finite total toward zero and return the same neutral payload if the truncated value is nonpositive. Otherwise map nonfinite or negative hechos to zero; truncate remaining hechos toward zero and clamp it between zero and the sanitized total, normalizing negative zero to zero. Compute valor using these sanitized counts and the existing clamp01, and porcentaje using Math.round of valor times 100. Return sanitized hechos and total rather than raw inputs. Update only local comments that incorrectly describe the old sanitization rules.
  - behavior: Nonfinite totals, negative totals, and positive totals below 1 yield four zeros. Nonfinite or negative hechos yield zero completion with a valid sanitized total. For hechos 3.9 and total 5.9 return counts 3 and 5, ratio 0.6, and percentage 60; hechos exceeding total returns capped counts and 100 percent. All fields remain finite.
  - stop: Return control if the required payload invariants cannot be preserved with the current numeric signature and edits confined to this helper's source file.
  - verify: `bun test cases/progreso/visible.test.ts`

## // 004. stun

- outcome: The stunUrl slot rejects TURN schemes without changing TURN configuration or error precedence for valid STUN entries.

- [ ] 4.1 Require STUN_SCHEMES membership in the stunUrl branch.
  - skills: none
  - why: Shared URI validation accepts TURN URLs, but the STUN configuration slot must not.
  - learn: A syntactically valid shared protocol value can still be invalid for the specific field that owns it.
  - architecture: Enforce the slot-specific restriction in buildIceServers; keep the shared parser and validator capable of handling both protocol families.
  - avoid: Do not restrict validateEntry globally, rewrite URL parsing, fix the independent ice-query case here, or change TURN credential handling.
  - read: `design.md`, `cases/stun/source.ts`, `cases/stun/visible.test.ts`
  - edit: `cases/stun/source.ts` | modify | In the nonblank stunUrl branch, extend the existing invalid-stun-url guard to reject either a failed validateEntry result or a successful result whose scheme is not in the existing STUN_SCHEMES set. Inspect scheme only after successful validation. Keep this guard before the STUN credential check and leave parsing, trimming, server assembly, the TURN branch, and exported types unchanged.
  - behavior: stun and stuns retain existing valid behavior. turn or turns in stunUrl returns invalid-stun-url, including valid TURN URIs with transport queries or accompanying STUN credentials. Valid STUN with credentials still returns unexpected-turn-credentials. TURN URLs with credentials and all existing TURN errors remain unchanged.
  - stop: Return control if enforcing STUN-slot membership requires altering shared URI acceptance or TURN-branch behavior outside this localized guard.
  - verify: `bun test cases/stun/visible.test.ts`

## // 005. ice-query

- outcome: ICE URL parsing rejects every URL containing multiple literal question marks instead of ignoring its suffix.

- [ ] 5.1 Reject repeated query delimiters before the existing bounded split.
  - skills: none
  - why: Splitting with a limit of two silently discards malformed suffixes after a second question mark.
  - learn: Delimiter cardinality must be checked before a lossy split when the whole input must be validated.
  - architecture: Put the whole-URL guard in parseIceUrl so both slots use it; preserve existing slot error mapping and all other parsing rules.
  - avoid: Do not decode percent escapes before counting delimiters, replace the ICE parser with a generic URL parser, change query parameter rules, or port the independent stun-slot fix into this case.
  - read: `design.md`, `cases/ice-query/source.ts`, `cases/ice-query/visible.test.ts`
  - edit: `cases/ice-query/source.ts` | modify | At the start of parseIceUrl, find the first literal question mark in the complete url and, if present, search for a second after it; return null whenever a second exists. Leave the existing scheme match, bounded split, URLSearchParams checks, transport validation, host/port validation, builder, and exports unchanged. This guard must inspect the whole url, not only a retained query fragment.
  - behavior: Two or more literal question marks anywhere yield the existing invalid URL error for the configured slot, including repeated delimiters, trailing delimiters, and otherwise valid transport queries with ignored suffixes. A single TURN transport=udp or transport=tcp query remains valid; unknown or duplicated keys and any STUN query remain rejected. Percent-encoded question marks continue through existing validation rather than being treated as literal delimiters.
  - stop: Return control if rejecting repeated delimiters requires changing the accepted single-query grammar or any non-query validation rule instead of adding the source-local guard.
  - verify: `bun test cases/ice-query/visible.test.ts`
