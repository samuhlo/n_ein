import {test,expect} from 'bun:test';
import {calcularProgresoEvaluable as check} from './source';
test('acceptance examples',()=>{expect(check(Infinity,10)).toEqual({hechos:0,total:10,valor:0,porcentaje:0});expect(check(3,2)).toEqual({hechos:2,total:2,valor:1,porcentaje:100});});
