// Validating ICE server builder, shared by server (turn-credentials endpoint)
// and client (app/composables/use-ice-config.ts degraded fallback) so both
// sides enforce the same contract instead of drifting apart. Pure, never
// throws: returns a result so a malformed entry is a diagnosable value, not a
// blank page. See design.md D10.

export type PeerIceServer = Readonly<{
  readonly urls: string | readonly string[]
  readonly username?: string
  readonly credential?: string
}>

export type IceConfigError =
  | 'invalid-stun-url'
  | 'invalid-turn-url'
  | 'missing-turn-credentials'
  | 'unexpected-turn-credentials'

export type IceServersResult =
  | { ok: true; value: PeerIceServer[] }
  | { ok: false; error: IceConfigError }

export type IceServerConfig = Readonly<{
  stunUrl?: string
  // STUN entries must never carry credentials (R7); these exist only so the
  // validator can reject a misconfiguration explicitly instead of silently
  // discarding it.
  stunUsername?: string
  stunCredential?: string
  turnUrl?: string
  turnUsername?: string
  turnCredential?: string
}>

const RELAY_SCHEMES = new Set(['turn', 'turns'])
const STUN_SCHEMES = new Set(['stun', 'stuns'])
// host[:port], where host is a DNS label sequence or a bracketed IPv6 literal.
const HOST_PATTERN = /^(\[[0-9a-fA-F:]+\]|[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?)*)(?::(\d+))?$/

function parseIceUrl(url: string): { scheme: string; host: string; port?: number; transport?: string } | null {
  const match = /^([a-z]+):(.+)$/.exec(url)
  if (!match) return null
  const [, scheme = '', rest = ''] = match

  const [authorityAndPath = '', query] = rest.split('?', 2)
  let transport: string | undefined
  if (query !== undefined) {
    const params = new URLSearchParams(query)
    const values = params.getAll('transport')
    if (values.length !== 1) return null
    transport = values[0]
    // No other query parameter is permitted (D10).
    if ([...params.keys()].some(key => key !== 'transport')) return null
  }

  const hostMatch = HOST_PATTERN.exec(authorityAndPath)
  if (!hostMatch) return null
  const host = hostMatch[1] ?? ''
  const port = hostMatch[2] !== undefined ? Number(hostMatch[2]) : undefined
  if (port !== undefined && (!Number.isInteger(port) || port < 1 || port > 65535)) return null
  if (host.length === 0) return null

  return { scheme, host, port, transport }
}

function validateEntry(url: string): { ok: true; scheme: string } | { ok: false } {
  const parsed = parseIceUrl(url)
  if (parsed === null) return { ok: false }
  const isRelay = RELAY_SCHEMES.has(parsed.scheme)
  const isStun = STUN_SCHEMES.has(parsed.scheme)
  if (!isRelay && !isStun) return { ok: false }
  if (parsed.transport !== undefined) {
    if (!isRelay || (parsed.transport !== 'udp' && parsed.transport !== 'tcp')) return { ok: false }
  }
  return { ok: true, scheme: parsed.scheme }
}

/** Validates and assembles the ICE server list. Never throws. */
export function buildIceServers(config: IceServerConfig): IceServersResult {
  const servers: PeerIceServer[] = []

  const stun = config.stunUrl?.trim()
  if (stun) {
    const validated = validateEntry(stun)
    if (!validated.ok) return { ok: false, error: 'invalid-stun-url' }
    if (config.stunUsername?.trim() || config.stunCredential?.trim()) {
      return { ok: false, error: 'unexpected-turn-credentials' }
    }
    servers.push({ urls: stun })
  }

  // A blank TURN host is deliberate STUN-only mode, not an error (D10).
  const turn = config.turnUrl?.trim()
  if (turn) {
    const validated = validateEntry(turn)
    if (!validated.ok || !RELAY_SCHEMES.has(validated.scheme)) return { ok: false, error: 'invalid-turn-url' }
    const username = config.turnUsername?.trim()
    const credential = config.turnCredential?.trim()
    if (!username || !credential) return { ok: false, error: 'missing-turn-credentials' }
    servers.push({ urls: turn, username, credential })
  }

  return { ok: true, value: servers }
}
