# Design — supervised cheap executor pilot

Only change the source.ts of the assigned group. Tests are read-only. Existing exported signatures and unrelated behavior remain stable. No dependency installation, no commits, no external services. Each case is independent.

## fechas
fechaInicio debe aceptar solo fechas reales YYYY-MM-DD de exactamente 10 caracteres, incluidos años bisiestos correctos; conservar mensaje de requerido para vacío, passthrough y resto del schema.

## horario
Cuando ambas preferencias existen, validar hora de 08:00 a 20:45 en cuartos de hora y formato HH:mm de dos dígitos. Mantener horas permitidas 4/5/6, final hasta 21:00 inclusive y piezas ausentes como ok. No añadir defaults.

## progreso
Garantizar payload finito con enteros hechos/total >=0: total no finito o truncado <=0 da neutro; total finito positivo se trunca. hechos no finito o negativo da0; demás se trunca y limita a total saneado. Calcular ratio y porcentaje desde esos valores. Mantener firma y ninguna dependencia.

## stun
stunUrl solo acepta esquemas stun y stuns. Si tiene turn/turns, devolver invalid-stun-url aunque sea URI válida para TURN. Mantener TURN con credenciales y todos los errores y entradas válidas existentes. Cambio localizado, sin dependencias.

## ice-query
Rechazar URLs ICE con varios signos ? en cualquier parte: ahora split con límite ignora sufijos inválidos. Conservar query única transport=udp/tcp para TURN, rechazo de claves desconocidas/duplicadas y de query en STUN. No cambiar las demás reglas.