import {test,expect} from 'bun:test';
import {buildIceServers as check} from './source';
test('acceptance examples',()=>{expect(check({stunUrl:'turn:relay.example:3478'})).toEqual({ok:false,error:'invalid-stun-url'});expect(check({stunUrl:'stun:stun.example:3478'}).ok).toBe(true);});
