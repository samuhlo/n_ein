import {test,expect} from 'bun:test';
import {validarHorario as check} from './source';
test('acceptance examples',()=>{expect(check({horas:4,hora:'17:00'})).toEqual({ok:true});expect(check({horas:4,hora:'08:60'})).toEqual({ok:false,reason:'incompatible'});expect(check({horas:4,hora:'08:01'}).ok).toBe(false);});
