import {test,expect} from 'bun:test';
import {generateBodySchema as schema} from './source'; const ok=(d:string)=>schema.safeParse({fechaInicio:d,horasDiarias:4}).success;
test('acceptance examples',()=>{expect(ok('2024-02-29')).toBe(true); expect(ok('2026-02-30')).toBe(false); expect(ok('2026-09-08T12:00:00Z')).toBe(false);});
