import {test,expect} from 'bun:test';
import {buildIceServers} from './source'; const check=(turnUrl:string)=>buildIceServers({turnUrl,turnUsername:'u',turnCredential:'p'});
test('acceptance examples',()=>{expect(check('turn:relay.example:3478?transport=udp?ignored=1')).toEqual({ok:false,error:'invalid-turn-url'});expect(check('turn:relay.example:3478?transport=tcp').ok).toBe(true);});
