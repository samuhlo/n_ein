import {test,expect} from 'bun:test';
import {calcularProgresoEvaluable as check} from './source';
test('independent regression cases',()=>{expect(check(2.9,4.9)).toEqual({hechos:2,total:4,valor:0.5,porcentaje:50});for(const total of [0,-1,NaN,Infinity,0.8])expect(check(4,total)).toEqual({hechos:0,total:0,valor:0,porcentaje:0});for(const n of [NaN,-Infinity,-1])expect(check(n,4)).toEqual({hechos:0,total:4,valor:0,porcentaje:0});expect(check(1,3).porcentaje).toBe(33);});
