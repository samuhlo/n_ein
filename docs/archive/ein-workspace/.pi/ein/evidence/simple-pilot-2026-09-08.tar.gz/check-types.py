import pathlib,json,subprocess
r=pathlib.Path('/tmp/ein-simple-pilot-20260908');rows=json.loads((r/'worker-results.json').read_text());out=[]
for x in rows:
 run=f"{x['case']}-{x['model']}";source=r/'runs'/run/'cases'/x['case']/'source.ts'
 args=['/Users/samu/Documents/01_Proyectos/ein-agent/node_modules/.bin/tsc','--noEmit','--target','es2022','--module','esnext','--moduleResolution','bundler','--strict','--noUncheckedIndexedAccess','--skipLibCheck',str(source)]
 p=subprocess.run(args,capture_output=True,text=True,timeout=30)
 (r/'logs'/f'{run}-typecheck.log').write_text(p.stdout+p.stderr)
 out.append({'case':x['case'],'model':x['model'],'exitCode':p.returncode,'pass':x['pass'] and p.returncode==0})
print(json.dumps(out));(r/'typecheck-results.json').write_text(json.dumps(out,indent=2)+'\n')
