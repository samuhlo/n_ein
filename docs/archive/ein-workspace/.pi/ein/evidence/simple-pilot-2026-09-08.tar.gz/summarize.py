import pathlib,json,hashlib,tarfile,subprocess
r=pathlib.Path('/tmp/ein-simple-pilot-20260908');repo=pathlib.Path('/Users/samu/Documents/01_Proyectos/ein-agent')
def usage(path):
 msgs=[]
 for l in path.read_text().splitlines():
  try:x=json.loads(l)
  except:continue
  if x.get('type')=='message_end' and x.get('message',{}).get('role')=='assistant':msgs.append(x['message'])
 return {'costUsd':sum(m['usage']['cost']['total'] for m in msgs),'totalTokens':sum(m['usage']['totalTokens'] for m in msgs),'turns':len(msgs),'models':sorted({m['model'] for m in msgs})}
workers=json.loads((r/'worker-results.json').read_text());types=json.loads((r/'typecheck-results.json').read_text());repair=json.loads((r/'repair-results.json').read_text());context=json.loads((r/'context-results.json').read_text())
for row in workers:
 t=next(t for t in types if (t['case'],t['model'])==(row['case'],row['model']))
 row['behaviorPassed']=row['pass'];row['typecheckExit']=t['exitCode'];row['pass']=t['pass'];row.pop('final',None)
planner=usage(r/'planner-events.jsonl');plannerRepair=usage(r/'planner-repair-events.jsonl');arms={}
for model in ['gpt-6-astra','gpt-5.6-luna']:
 xs=[x for x in workers if x['model']==model];extra=repair if model=='gpt-5.6-luna' else []
 arms[model]={'firstPass':sum(x['pass'] for x in xs),'cases':len(xs),'executionCostUsd':sum(x['usage']['cost'] for x in xs),'executionTokens':sum(x['usage']['totalTokens'] for x in xs),'executionElapsedMs':sum(x['elapsedMs'] for x in xs),'totalWithPlanningAndRepairUsd':planner['costUsd']+sum(x['usage']['cost'] for x in xs+extra)+(plannerRepair['costUsd'] if extra else 0),'totalTokensWithPlanningAndRepair':planner['totalTokens']+sum(x['usage']['totalTokens'] for x in xs+extra)+(plannerRepair['totalTokens'] if extra else 0)}
summary={'date':'2026-09-08','baseCommit':'b9e6959','planner':planner,'plannerRepair':plannerRepair,'arms':arms,'workers':workers,'repair':repair,'context':context,'continuity':json.loads((r/'continuity/result.json').read_text()),'localModels':json.loads((r/'local-model-probe.json').read_text()),'versions':{'pi':subprocess.check_output([str(repo/'node_modules/.bin/pi'),'--version'],text=True).strip(),'bun':subprocess.check_output(['bun','--version'],text=True).strip(),'typescript':json.loads((repo/'node_modules/typescript/package.json').read_text())['version'],'zod':json.loads((r/'planning/node_modules/zod/package.json').read_text())['version']},'limitations':['Five one-file tasks from copied modules, one historical regression and four hardening proposals; not full applications or a production SDD chain.','Explicit pilot task attribution, not a repair of the existing global accounting observer.','Original pilot omitted source compiler options; independent review applied them to both arms, found one Luna failure, then added the missing context to the repaired plan.','Shared planning cost is allocated once per hypothetical arm; additional paid pilot setup/research and human/Codex supervision are not measured as arm costs.','Provider usage costs are accounting estimates with actual cache behavior, not a billing invoice.','No running local model was available; no local quality or hardware-performance claim.','Context trials use the same controlled prompt composition and no tools; they exclude installed extension/tool schemas and do not establish long-session or production-startup savings.','First context reduction failed the identity probe; v1 results and subsequent correction are retained.','Workspace diffs were audited, but no process sandbox or production confinement was proven.']}
(r/'summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
# Retain self-contained source, checks, prompts and all attempts, but no credentials.
include=['cases.json','summary.json','worker-results.json','typecheck-results.json','repair-results.json','context-results.json','context-results-v1.json','local-model-probe.json','planning','holdout','runs','logs','context-runs','context-runs-v1','continuity','continuity-short-history']
include += [p.name for p in r.iterdir() if p.is_file() and (p.suffix in ['.py','.ts','.txt','.log'] or p.name.startswith('planner-') or p.name.endswith('-packet.json'))]
files=[]
for name in sorted(set(include)):
 p=r/name
 candidates=p.rglob('*') if p.is_dir() else [p]
 for f in candidates:
  if f.is_file() and 'node_modules' not in f.parts:files.append(f)
manifest={str(f.relative_to(r)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(set(files))}
(r/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');files.append(r/'evidence-manifest.json')
out=repo/'.pi/ein/evidence';out.mkdir(parents=True,exist_ok=True);archive=out/'simple-pilot-2026-09-08.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for f in sorted(set(files)):t.add(f,arcname=str(f.relative_to(r)),recursive=False)
with tarfile.open(archive) as t:
 assert not any('agent-home' in n or 'continuity-home' in n or n.endswith('auth.json') for n in t.getnames())
sha=hashlib.sha256(archive.read_bytes()).hexdigest();(r/'artifact.json').write_text(json.dumps({'path':str(archive),'sha256':sha,'bytes':archive.stat().st_size},indent=2)+'\n')
print(json.dumps({'arms':arms,'artifact':str(archive),'sha256':sha,'bytes':archive.stat().st_size},indent=2))
