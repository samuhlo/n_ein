import {mkdtempSync,mkdirSync,writeFileSync,rmSync,cpSync} from 'node:fs';
import {join} from 'node:path';
import assert from 'node:assert/strict';
import {registerAgentPromptHook} from '/Users/samu/Documents/01_Proyectos/ein-agent/ein-pi/agent/extensions/internal/ein-agent-prompt-hook.ts';
const dir=mkdtempSync('/tmp/ein-prompt-role-');
try {
 for(const name of ['comment-style','logging-style','file-naming']){
  const path=join(dir,'.pi/skills',name);mkdirSync(path,{recursive:true});
  writeFileSync(join(path,'SKILL.md'),`---\nname: ${name}\ndescription: House convention\n---\n\n- ROLE_CONVENTION_SENTINEL\n`);
 }
 let handler:any;
 registerAgentPromptHook({on(name:string,cb:any){if(name==='before_agent_start')handler=cb;}} as any);
 const ctx={cwd:dir,hasUI:false,sessionManager:{getSessionId:()=>dir}};
 for(const name of [undefined,'sdd-apply','sdd-verify']){
  const r=await handler({systemPrompt:'BASE',prompt:'bounded task',...(name?{agentName:name}:{})},ctx);
  assert.equal(r.systemPrompt.includes('## Code conventions'),name==='sdd-apply');
 }
 console.log('Prompt hook: parent and verify omit code conventions; apply retains them.');
} finally {rmSync(dir,{recursive:true,force:true});}
