import {readFileSync,writeFileSync} from 'node:fs';
import {loadSkills,formatSkillsForPrompt} from '/Users/samu/Documents/01_Proyectos/ein-agent/node_modules/@earendil-works/pi-coding-agent/dist/core/skills.js';
import {codeConventionSkillBlock} from '/Users/samu/Documents/01_Proyectos/ein-agent/ein-pi/agent/extensions/ein-skill-registry.ts';
import {einContextDirective} from '/Users/samu/Documents/01_Proyectos/ein-agent/ein-pi/agent/lib/project-context.ts';
const root='/tmp/ein-simple-pilot-20260908',repo='/Users/samu/Documents/01_Proyectos/ein-agent',home='/Users/samu/.pi-ein/agent';
const skills=loadSkills({cwd:repo,agentDir:home,skillPaths:[home+'/skills/local',home+'/skills/downloaded'],includeDefaults:true});
const common=readFileSync(repo+'/runtime/AGENTS.md','utf8')+'\n'+einContextDirective(repo)+'\n'+formatSkillsForPrompt(skills.skills);
for(const arm of ['before','after'])writeFileSync(root+'/context-'+arm+'.txt',common+'\n'+readFileSync(root+'/prompt-'+arm+'.txt','utf8')+(arm==='before'?'\n'+codeConventionSkillBlock(repo):''));
console.log('Controlled context: same shared rules, project and skill catalog; only persona duplication and parent conventions differ.');
