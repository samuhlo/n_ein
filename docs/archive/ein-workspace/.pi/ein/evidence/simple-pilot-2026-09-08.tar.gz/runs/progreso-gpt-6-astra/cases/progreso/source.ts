/**
 * [UTILS] :: PROGRESO_EVALUABLE
 * =====================================================================
 * DESC:   Contrato numerico puro y compartible del ratio evaluable.
 *         Es la unica fuente de verdad del payload `{ hechos, total,
 *         valor, porcentaje }` que consumen:
 *           - Anexo V (Evaluacion) en `use-progreso-anexos.ts`.
 *           - Anexo VI (Informe), que copia por valor esas 4 cifras.
 *           - Agregado de tarjeta de curso (grupo // 003).
 *
 *         Reglas (experiencia-cursos-y-progreso-anexos // 002, R3):
 *           - `total` truncado <= 0 o no finito => payload neutro
 *             `{ hechos: 0, total: 0, valor: 0, porcentaje: 0 }`.
 *             Sin division por cero, sin `NaN`, sin `Infinity`.
 *           - `hechos` no finito o negativo -> 0; se trunca y limita al total saneado.
 *           - `valor` se clampa a `[0, 1]`.
 *           - `porcentaje` se calcula con `Math.round(valor * 100)`.
 *
 *         El helper NO conoce etiquetas de etapa, ni labels, ni rutas.
 *         Es aritmetica pura testeable sin Vue, sin Pinia, sin DB.
 *
 *         SLICE:  experiencia-cursos-y-progreso-anexos / APPLY / // 002.
 *         STATUS: NEW
 * =====================================================================
 */

/**
 * Payload estructurado del progreso evaluable.
 * `valor` ∈ [0, 1]; `porcentaje` ∈ [0, 100] (entero).
 * `hechos` y `total` son enteros >= 0.
 */
export interface ProgresoEvaluable {
  /** Unidades/pasos completados saneados (entero >= 0). */
  hechos: number
  /** Unidades/pasos totales que aplican (entero >= 0; `0` = sin datos). */
  total: number
  /** Fraccion de completitud clampada en [0, 1]. */
  valor: number
  /** Porcentaje entero `Math.round(valor * 100)`. */
  porcentaje: number
}

/**
 * Clampa `n` al intervalo `[0, 1]`. NaN -> 0. ±Infinity cae por las
 * ramas `< 0` / `> 1`. Es la unica funcion que aplica el clamp; el
 * resto del modulo la consume.
 */
function clamp01(n: number): number {
  if (Number.isNaN(n)) return 0
  if (n < 0) return 0
  if (n > 1) return 1
  return n
}

/**
 * Calcula el ratio evaluable canonico.
 *
 * Invariantes:
 *   - `total` truncado <= 0 o no finito => neutro total (`0/0/0/0`); no se
 *     divide por cero y no se filtra `hechos` aunque sea > 0, porque
 *     sin ambito autoritativo no hay progreso que reportar.
 *   - `hechos` no finito o negativo => 0; se trunca y limita al total saneado.
 *   - `valor` clampado a `[0, 1]` (overflow de configs en unit keys
 *     invalidas no infla el ratio por encima de 1).
 *   - `porcentaje` redondeado con `Math.round`.
 *
 * La firma acepta cualquier par `(hechos, total)`; los consumidores
 * (composable de progreso, agregado batched de tarjeta) deciden cuando
 * computar y con que datos; este helper solo garantiza la aritmetica.
 */
export function calcularProgresoEvaluable(hechos: number, total: number): ProgresoEvaluable {
  // Sin ambito: payload neutro. FAIL CLOSED -> si no hay estructura
  // oficial, progreso es 0/0 aunque haya configs persistidas sueltas.
  if (!Number.isFinite(total) || Math.trunc(total) <= 0) {
    return { hechos: 0, total: 0, valor: 0, porcentaje: 0 }
  }
  // CORTE -> hechos corruptos o negativos se anulan antes de tocar el ratio.
  const totalSaneado = Math.trunc(total)
  const hechosSaneados = !Number.isFinite(hechos) || hechos < 0
    ? 0
    : Math.max(0, Math.min(Math.trunc(hechos), totalSaneado))
  const valor = clamp01(hechosSaneados / totalSaneado)
  return {
    hechos: hechosSaneados,
    total: totalSaneado,
    valor,
    porcentaje: Math.round(valor * 100),
  }
}
