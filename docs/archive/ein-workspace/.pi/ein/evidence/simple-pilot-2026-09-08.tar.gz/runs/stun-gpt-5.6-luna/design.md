# Design

stunUrl solo acepta esquemas stun y stuns. Si tiene turn/turns, devolver invalid-stun-url aunque sea URI válida para TURN. Mantener TURN con credenciales y todos los errores y entradas válidas existentes. Cambio localizado, sin dependencias.
Existing exports and unrelated behavior stay unchanged. Tests are read-only; no new dependencies.