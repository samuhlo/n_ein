# Design

Rechazar URLs ICE con varios signos ? en cualquier parte: ahora split con límite ignora sufijos inválidos. Conservar query única transport=udp/tcp para TURN, rechazo de claves desconocidas/duplicadas y de query en STUN. No cambiar las demás reglas.
Existing exports and unrelated behavior stay unchanged. Tests are read-only; no new dependencies.