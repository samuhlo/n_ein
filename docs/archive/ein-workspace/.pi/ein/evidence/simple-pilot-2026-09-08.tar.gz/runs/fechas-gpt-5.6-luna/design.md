# Design

fechaInicio debe aceptar solo fechas reales YYYY-MM-DD de exactamente 10 caracteres, incluidos años bisiestos correctos; conservar mensaje de requerido para vacío, passthrough y resto del schema.
Existing exports and unrelated behavior stay unchanged. Tests are read-only; no new dependencies.