# Tasks

status: ready
blocked_by: none

## // 001. horario

- outcome: Complete schedule preferences obey the exact start-time grid and inclusive 21:00 end limit.

- [ ] 2.1 Validate the start-time format, bounds, and quarter-hour grid before computing the end time.
  - skills: none
  - why: The current parser accepts single-digit hours and out-of-range clock components.
  - learn: Validate clock components before converting to minutes; a final-time check alone cannot establish valid input.
  - architecture: Keep all decisions in validarHorario and preserve its input/output types, nullish short circuit, and incompatible reason.
  - avoid: Do not introduce defaults, trim time strings, validate incomplete pairs, or infer valid minutes solely from the computed end time.
  - read: `design.md`, `cases/horario/source.ts`, `cases/horario/visible.test.ts`
  - edit: `cases/horario/source.ts` | modify | Keep the missing/null horas-or-hora return first and the existing 4/5/6 hours check. Require the supplied time string to have exactly five characters consisting of two ASCII hour digits, a colon, and two ASCII minute digits. After parsing, reject hours outside 8–20 and minutes other than 0, 15, 30, or 45. Only then calculate start and end minutes; retain rejection only when the end exceeds MAX_END_MINUTES. Route every invalid complete pair to the existing incompatible result and preserve all exports.
  - behavior: Missing pieces remain ok without defaults. Complete pairs reject 8:00, 07:45, 21:00, 08:60, 08:10, and suffixed strings. 17:00 with 4 hours passes at exactly 21:00; 17:15 with 4 hours fails. A grid-valid start such as 20:45 still fails if its duration crosses 21:00.
  - stop: Return control if satisfying the time contract requires changing the exported schedule types or missing-piece behavior rather than this source's validation alone.
  - verify: `bun test cases/horario/visible.test.ts`

