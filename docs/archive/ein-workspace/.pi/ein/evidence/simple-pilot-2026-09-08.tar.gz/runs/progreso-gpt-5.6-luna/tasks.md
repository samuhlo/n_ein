# Tasks

status: ready
blocked_by: none

## // 001. progreso

- outcome: Every progress payload contains finite, sanitized counts and ratios derived from those same counts.

- [ ] 3.1 Sanitize total and hechos before computing or returning progress.
  - skills: none
  - why: Fractional counts and infinite completed values currently leak into the returned payload despite ratio clamping.
  - learn: Sanitizing only a derived ratio does not sanitize the authoritative counts exposed beside it.
  - architecture: Keep the numerical contract inside calcularProgresoEvaluable; retain its signature, ProgresoEvaluable, and the existing local clamp helper.
  - avoid: Do not round counts, divide by the original total, treat positive infinity as completion, impose safe-integer caps, or change consumers.
  - read: `design.md`, `cases/progreso/source.ts`, `cases/progreso/visible.test.ts`
  - edit: `cases/progreso/source.ts` | modify | Return the existing all-zero payload for a nonfinite total. Truncate finite total toward zero and return the same neutral payload if the truncated value is nonpositive. Otherwise map nonfinite or negative hechos to zero; truncate remaining hechos toward zero and clamp it between zero and the sanitized total, normalizing negative zero to zero. Compute valor using these sanitized counts and the existing clamp01, and porcentaje using Math.round of valor times 100. Return sanitized hechos and total rather than raw inputs. Update only local comments that incorrectly describe the old sanitization rules.
  - behavior: Nonfinite totals, negative totals, and positive totals below 1 yield four zeros. Nonfinite or negative hechos yield zero completion with a valid sanitized total. For hechos 3.9 and total 5.9 return counts 3 and 5, ratio 0.6, and percentage 60; hechos exceeding total returns capped counts and 100 percent. All fields remain finite.
  - stop: Return control if the required payload invariants cannot be preserved with the current numeric signature and edits confined to this helper's source file.
  - verify: `bun test cases/progreso/visible.test.ts`

