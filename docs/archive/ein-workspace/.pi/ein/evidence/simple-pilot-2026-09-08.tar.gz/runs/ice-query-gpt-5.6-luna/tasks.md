# Tasks

status: ready
blocked_by: none

## // 001. ice-query

- outcome: ICE URL parsing rejects every URL containing multiple literal question marks instead of ignoring its suffix.

- [ ] 5.1 Reject repeated query delimiters before the existing bounded split.
  - skills: none
  - why: Splitting with a limit of two silently discards malformed suffixes after a second question mark.
  - learn: Delimiter cardinality must be checked before a lossy split when the whole input must be validated.
  - architecture: Put the whole-URL guard in parseIceUrl so both slots use it; preserve existing slot error mapping and all other parsing rules.
  - avoid: Do not decode percent escapes before counting delimiters, replace the ICE parser with a generic URL parser, change query parameter rules, or port the independent stun-slot fix into this case.
  - read: `design.md`, `cases/ice-query/source.ts`, `cases/ice-query/visible.test.ts`
  - edit: `cases/ice-query/source.ts` | modify | At the start of parseIceUrl, find the first literal question mark in the complete url and, if present, search for a second after it; return null whenever a second exists. Leave the existing scheme match, bounded split, URLSearchParams checks, transport validation, host/port validation, builder, and exports unchanged. This guard must inspect the whole url, not only a retained query fragment.
  - behavior: Two or more literal question marks anywhere yield the existing invalid URL error for the configured slot, including repeated delimiters, trailing delimiters, and otherwise valid transport queries with ignored suffixes. A single TURN transport=udp or transport=tcp query remains valid; unknown or duplicated keys and any STUN query remain rejected. Percent-encoded question marks continue through existing validation rather than being treated as literal delimiters.
  - stop: Return control if rejecting repeated delimiters requires changing the accepted single-query grammar or any non-query validation rule instead of adding the source-local guard.
  - verify: `bun test cases/ice-query/visible.test.ts`
