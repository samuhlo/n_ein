/**
 * [UTILS] :: PERFIL_HORARIO
 * =====================================================================
 * DESC:   Helper puro compartido para validar la compatibilidad de
 *         una pareja `prefHorasDiarias` + `prefHoraInicio`.
 *
 *         Regla vigente del wizard (21:00 limite duro legal de final
 *         de jornada formativa, mismo dato que
 *         `use-schedule-calculator.ts` → MAX_END_HOUR).
 *
 *         Si falta una pieza, devuelve `{ ok: true }` para que la
 *         precarga decida (no se aplica un default nuevo aqui).
 *
 *         SLICE:  perfil-enriquecido / Fase APPLY / Grupo // 002.
 *         STATUS: NEW
 * =====================================================================
 */

// 21:00 es limite duro legal de final de jornada formativa.
// Si la pareja hora + horas lo cruza, la franja no es valida.
const MAX_END_MINUTES = 21 * 60

export type HorasDiarias = 4 | 5 | 6
export type HoraInicioValida =
  | '08:00' | '08:15' | '08:30' | '08:45' | '09:00' | '09:15' | '09:30' | '09:45'
  | '10:00' | '10:15' | '10:30' | '10:45' | '11:00' | '11:15' | '11:30' | '11:45'
  | '12:00' | '12:15' | '12:30' | '12:45' | '13:00' | '13:15' | '13:30' | '13:45'
  | '14:00' | '14:15' | '14:30' | '14:45' | '15:00' | '15:15' | '15:30' | '15:45'
  | '16:00' | '16:15' | '16:30' | '16:45' | '17:00' | '17:15' | '17:30' | '17:45'
  | '18:00' | '18:15' | '18:30' | '18:45' | '19:00' | '19:15' | '19:30' | '19:45'
  | '20:00' | '20:15' | '20:30' | '20:45'

export type ValidarHorarioInput = {
  horas?: HorasDiarias | null
  hora?: HoraInicioValida | string | null
}

export type ValidarHorarioResultado =
  | { ok: true }
  | { ok: false; reason: 'incompatible' }

/**
 * Compara una pareja (horas, hora) contra el limite de 21:00.
 * Devuelve un discriminated union testeable sin Vue.
 */
export function validarHorario(input: ValidarHorarioInput): ValidarHorarioResultado {
  const { horas, hora } = input
  // Si falta una pieza, no decidimos (la precarga tomara la decision).
  if (horas == null || hora == null) return { ok: true }

  // Defensa en profundidad: si horas llega fuera del conjunto {4,5,6}
  // (no deberia pasar: el schema Zod ya lo filtra), marcamos
  // incompatible para no propagar defaults divergentes.
  if (horas !== 4 && horas !== 5 && horas !== 6) {
    return { ok: false, reason: 'incompatible' }
  }

  const match = /^([0-9]{2}):([0-9]{2})$/.exec(hora)
  if (hora.length !== 5 || !match) return { ok: false, reason: 'incompatible' }
  const h = Number(match[1])
  const m = Number(match[2])
  if (h < 8 || h > 20 || (m !== 0 && m !== 15 && m !== 30 && m !== 45)) {
    return { ok: false, reason: 'incompatible' }
  }
  const startMinutes = h * 60 + m
  const endMinutes = startMinutes + horas * 60
  if (endMinutes > MAX_END_MINUTES) {
    return { ok: false, reason: 'incompatible' }
  }
  return { ok: true }
}
