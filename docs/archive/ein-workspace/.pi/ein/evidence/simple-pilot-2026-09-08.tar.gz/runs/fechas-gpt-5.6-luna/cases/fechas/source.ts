// Schema Zod puro para el body del endpoint `/api/generate`.
// SM-385 Slice 5 (siguiente tras Slice 4): mismo patron que
// `anexo3-export-body-schema.ts` — schema en modulo puro para poder
// importarlo desde el endpoint y desde los tests sin arrastrar
// globals de Nitro / Nuxt.
//
// Frontera minima deliberada:
//   - Solo valida la forma de la peticion POST.
//   - Reglas de dominio (domingo, festivos, horas por modulo,
//     estrategia, validacion de UFs) siguen siendo trabajo del motor
//     `calculatePlanning()` (ver `server/utils/calculatePlanning.ts`).
//   - Defaults como `certificadoCodigo = 'IFCD0110'` siguen siendo del use case.
//
// Por que `horasDiarias` es literal union y no `z.number().int().min(4).max(6)`:
//   - El motor `calculatePlanning()` exige `4 | 5 | 6` como tipo
//     (`hoursPerDay: 4 | 5 | 6`). Forzar la interseccion en la frontera
//     evita casteos `as` dentro del handler y protege contra inputs
//     ambiguos como `4.5` o `7` que el frontend jamas envia.
//   - Si el frontend cambia el set, el schema se actualiza junto al motor.
//
// Por que `centro` y `complementarios` son passthrough:
//   - La forma exacta viene del wizard (`app/stores/wizard-form.ts`).
//   - El motor no las consume: el handler las proyecta al `PlanningInput`
//     (`center`, `complementaryModules`) y vuelve a validar campos
//     concretos segun necesite.
//   - `.passthrough()` mantiene la forma original para no romper
//     consumidores que esperan el payload integro.

import { z } from 'zod'

// =============================================================================
// SCHEMA
// =============================================================================

function isValidCalendarDate(value: string): boolean {
  if (value === '') return true
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false

  const year = Number(value.slice(0, 4))
  const month = Number(value.slice(5, 7))
  const day = Number(value.slice(8, 10))
  const leapYear = year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0)
  const daysInMonth = [31, leapYear ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]

  return month >= 1 && month <= 12 && day >= 1 && day <= daysInMonth[month - 1]
}

export const generateBodySchema = z.object({
  // BLINDAJE -> Sin fecha no hay planning. Empty string cuenta como falta.
  fechaInicio: z.string()
    .min(1, 'fechaInicio requerido')
    .refine(isValidCalendarDate, 'fechaInicio debe ser una fecha válida YYYY-MM-DD'),

  // HARD STOP -> Solo 4/5/6 horas diarias. Cualquier otra cosa es bug del cliente.
  horasDiarias: z.union([z.literal(4), z.literal(5), z.literal(6)], {
    error: 'horasDiarias debe ser 4, 5 o 6',
  }),

  // Defaults son del endpoint (certificadoCodigo -> 'IFCD0110').
  certificadoCodigo: z.string().min(1).optional(),

  // Passthrough: la forma exacta la define el wizard.
  centro: z.record(z.string(), z.unknown()).optional(),

  // Passthrough: el handler proyecta al shape `ComplementaryModule` del motor.
  complementarios: z.array(z.record(z.string(), z.unknown())).optional(),

  // Metadata horario (SAM-351 / SAM-SCHEDULE-SELECTOR / SAM-352): strings laxos,
  // se reenvian al response tal cual llegan.
  horario: z.string().optional(),
  horaInicio: z.string().optional(),
  franjaHoraria: z.string().optional(),
}).passthrough()

export type GenerateBody = z.infer<typeof generateBodySchema>
