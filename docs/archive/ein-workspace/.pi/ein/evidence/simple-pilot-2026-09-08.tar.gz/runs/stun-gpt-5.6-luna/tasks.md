# Tasks

status: ready
blocked_by: none

## // 001. stun

- outcome: The stunUrl slot rejects TURN schemes without changing TURN configuration or error precedence for valid STUN entries.

- [ ] 4.1 Require STUN_SCHEMES membership in the stunUrl branch.
  - skills: none
  - why: Shared URI validation accepts TURN URLs, but the STUN configuration slot must not.
  - learn: A syntactically valid shared protocol value can still be invalid for the specific field that owns it.
  - architecture: Enforce the slot-specific restriction in buildIceServers; keep the shared parser and validator capable of handling both protocol families.
  - avoid: Do not restrict validateEntry globally, rewrite URL parsing, fix the independent ice-query case here, or change TURN credential handling.
  - read: `design.md`, `cases/stun/source.ts`, `cases/stun/visible.test.ts`
  - edit: `cases/stun/source.ts` | modify | In the nonblank stunUrl branch, extend the existing invalid-stun-url guard to reject either a failed validateEntry result or a successful result whose scheme is not in the existing STUN_SCHEMES set. Inspect scheme only after successful validation. Keep this guard before the STUN credential check and leave parsing, trimming, server assembly, the TURN branch, and exported types unchanged.
  - behavior: stun and stuns retain existing valid behavior. turn or turns in stunUrl returns invalid-stun-url, including valid TURN URIs with transport queries or accompanying STUN credentials. Valid STUN with credentials still returns unexpected-turn-credentials. TURN URLs with credentials and all existing TURN errors remain unchanged.
  - stop: Return control if enforcing STUN-slot membership requires altering shared URI acceptance or TURN-branch behavior outside this localized guard.
  - verify: `bun test cases/stun/visible.test.ts`

