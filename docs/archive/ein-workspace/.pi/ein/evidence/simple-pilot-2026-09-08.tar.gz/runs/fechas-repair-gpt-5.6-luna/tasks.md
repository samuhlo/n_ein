# Tasks

status: ready
blocked_by: none

## // 001. fechas

- outcome: fechaInicio accepts only exact calendar dates while preserving the request schema contract.

- [ ] 1.1 Add strict calendar validation to fechaInicio without changing other fields.
  - skills: none
  - why: A nonempty string currently accepts malformed dates and impossible calendar days.
  - learn: Date shape and calendar validity are separate checks; automatic date normalization can hide invalid input.
  - architecture: Keep validation in generateBodySchema, with any private calendar helper inside this source file; preserve exports, inferred field types, and passthrough.
  - avoid: Do not use permissive Date parsing, coerce or trim input, introduce timezone logic, or add domain restrictions such as holidays or minimum years.
  - read: `design.md`, `cases/fechas/source.ts`, `cases/fechas/visible.test.ts`, `tsconfig.json`
  - edit: `cases/fechas/source.ts` | modify | Retain the existing string minimum-length check and its fechaInicio requerido message. Append a calendar refinement that lets the empty string pass the refinement so only the existing required check rejects it. For nonempty strings require exactly 10 characters, ASCII digits in four-digit year and two-digit month/day positions, and hyphens at positions 5 and 8. Parse those components numerically; require month 1–12 and day 1 through that month's length. Under strict and noUncheckedIndexedAccess, numeric month bounds do not narrow an indexed array lookup: after rejecting out-of-range months, store daysInMonth[month - 1] in a local monthLength, explicitly return false if monthLength === undefined, and only then compare the day against monthLength. Do not use non-null assertions, type assertions, compiler suppressions, or relaxed compiler options to bypass this check. Use Gregorian leap-year arithmetic (divisible by 4 except centuries not divisible by 400) for February; add no year bounds beyond the four-digit shape. Use fechaInicio debe ser una fecha válida YYYY-MM-DD for nonempty invalid dates. Leave the rest of the schema unchanged.
  - behavior: Valid dates including 2024-02-29 and 2000-02-29 pass unchanged; 2023-02-29, 1900-02-29, April 31, zero month/day, missing padding, whitespace, trailing newlines, and timestamp suffixes fail. Empty input retains the required message; extra object keys and unrelated fields retain existing behavior.
  - stop: Return control if preserving the existing schema type or empty-input error requires changing anything outside this case's source file.
  - verify: `bun test cases/fechas/visible.test.ts`
  - verify: `tsc --noEmit -p tsconfig.json`

