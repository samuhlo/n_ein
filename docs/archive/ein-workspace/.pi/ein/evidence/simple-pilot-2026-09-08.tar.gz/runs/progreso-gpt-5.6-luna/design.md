# Design

Garantizar payload finito con enteros hechos/total >=0: total no finito o truncado <=0 da neutro; total finito positivo se trunca. hechos no finito o negativo da0; demás se trunca y limita a total saneado. Calcular ratio y porcentaje desde esos valores. Mantener firma y ninguna dependencia.
Existing exports and unrelated behavior stay unchanged. Tests are read-only; no new dependencies.