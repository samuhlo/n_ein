# Design

Cuando ambas preferencias existen, validar hora de 08:00 a 20:45 en cuartos de hora y formato HH:mm de dos dígitos. Mantener horas permitidas 4/5/6, final hasta 21:00 inclusive y piezas ausentes como ok. No añadir defaults.
Existing exports and unrelated behavior stay unchanged. Tests are read-only; no new dependencies.