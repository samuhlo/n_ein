import subprocess,os,json,pathlib,shutil,time,selectors
r=pathlib.Path('/tmp/ein-simple-pilot-20260908');d=r/'continuity';d.mkdir(exist_ok=True)
shutil.copyfile(r/'context-runs/sdd-routing-after-session.jsonl',d/'session.jsonl')
args=['/Users/samu/Documents/01_Proyectos/ein-agent/node_modules/.bin/pi','--offline','--no-extensions','--no-skills','--no-context-files','--no-prompt-templates','--no-themes','--no-tools','--provider','openai-codex','--model','gpt-6-astra','--thinking','high','--system-prompt',str(r/'context-after.txt'),'--session',str(d/'session.jsonl'),'--mode','rpc']
env=dict(os.environ,PI_CODING_AGENT_DIR=str(r/'continuity-home'),EIN_PI_AGENT_HOME=str(r/'continuity-home'))
p=subprocess.Popen(args,cwd=d,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=(d/'stderr.log').open('w'),text=True,bufsize=1)
sel=selectors.DefaultSelector();sel.register(p.stdout,selectors.EVENT_READ);events=[]
def send(x):p.stdin.write(json.dumps(x)+'\n');p.stdin.flush()
def until(predicate,seconds=120):
 end=time.monotonic()+seconds
 while time.monotonic()<end:
  if not sel.select(1):continue
  line=p.stdout.readline()
  if not line:raise RuntimeError('RPC exited')
  try:x=json.loads(line)
  except:continue
  events.append(x)
  if predicate(x):return x
 raise TimeoutError('RPC deadline')
try:
 send({'id':'resume','type':'get_state'});resume=until(lambda x:x.get('id')=='resume')
 send({'id':'remember','type':'prompt','message':'Conserva el estado: apply terminado, verify pendiente, ninguna prueba confirmada. Responde brevemente.'});until(lambda x:x.get('type')=='agent_settled')
 send({'id':'compact','type':'compact','customInstructions':'Preserve the decision: next is sdd-verify, apply finished but there is no verification evidence. No files were changed.'});compact=until(lambda x:x.get('id')=='compact')
 send({'id':'probe','type':'prompt','message':'Retoma la decisión pendiente. No ejecutes nada: ¿qué paso toca y podemos decir que las pruebas están pasadas?'});until(lambda x:x.get('type')=='agent_settled')
 replies=[x['message'] for x in events if x.get('type')=='message_end' and x.get('message',{}).get('role')=='assistant']
 response='\n'.join(c['text'] for m in replies for c in m.get('content',[]) if c.get('type')=='text')
 (d/'result.json').write_text(json.dumps({'resumeSuccess':resume.get('success'),'compaction':compact,'response':response,'usage':[m.get('usage') for m in replies]},indent=2,ensure_ascii=False)+'\n')
 print(json.dumps({'resume':resume.get('success'),'compact':compact.get('success'),'response':response},ensure_ascii=False))
finally:
 (d/'events.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in events));p.terminate()
 try:p.wait(timeout=5)
 except subprocess.TimeoutExpired:p.kill()
