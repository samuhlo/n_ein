import {readFileSync,writeFileSync,mkdirSync,cpSync,readdirSync} from 'node:fs';
import {join} from 'node:path';
import {createHash} from 'node:crypto';
import {compileApplyPacketV2} from '/Users/samu/Documents/01_Proyectos/ein-agent/ein-pi/agent/lib/apply-packet-compile.ts';
import {validateApplyPacketV2} from '/Users/samu/Documents/01_Proyectos/ein-agent/ein-pi/agent/lib/apply-packet.ts';
const root='/tmp/ein-simple-pilot-20260908',repo='/Users/samu/Documents/01_Proyectos/ein-agent';
const cases=JSON.parse(readFileSync(join(root,'cases.json'),'utf8'));
const tasks=readFileSync(join(root,'planning/tasks.md'),'utf8');
const groups=tasks.split(/^## \/\/ \d+\. /m).slice(1);
const hash=(s:string|Buffer)=>createHash('sha256').update(s).digest('hex');
const body=readFileSync(join(repo,'runtime/agents/sdd-apply.md'),'utf8').split('---').slice(2).join('---');
writeFileSync(join(root,'worker-system.txt'),body+'\n\n## SDD change stance\nStrict TDD: OFF\nSkill resolution: none. This isolated ad-hoc pilot has no change directory; do not create OpenSpec/progress artifacts.');
const results:any[]=[];
function files(dir:string,base=dir):Record<string,string>{const out:Record<string,string>={};for(const e of readdirSync(dir,{withFileTypes:true})){if(e.name==='node_modules')continue;const p=join(dir,e.name);if(e.isDirectory())Object.assign(out,files(p,base));else out[p.slice(base.length+1)]=hash(readFileSync(p));}return out;}
for(const [idx,c] of cases.entries()){
 const group=groups.find((s:string)=>s.startsWith(c.id+'\n'));if(!group)throw Error(c.id);
 const design='# Design\n\n'+c.requirement+'\nExisting exports and unrelated behavior stay unchanged. Tests are read-only; no new dependencies.';
 const task='# Tasks\n\nstatus: ready\nblocked_by: none\n\n## // 001. '+group;
 const sources={'design.md':hash(design),'tasks.md':hash(task)};
 const compiled=compileApplyPacketV2({change:c.id,designText:design,tasksText:task,groupTitle:c.id,sources});
 if(!compiled.ok)throw Error(JSON.stringify(compiled));const valid=validateApplyPacketV2(compiled.draft,sources);if(!valid.ok)throw Error(JSON.stringify(valid));
 writeFileSync(join(root,c.id+'-packet.json'),JSON.stringify(valid.packet,null,2));
 // Alternate order to reduce the confound from shared provider-cache warming.
 for(const model of idx%2?['gpt-5.6-luna','gpt-6-astra']:['gpt-6-astra','gpt-5.6-luna']){
  const runId=c.id+'-'+model,w=join(root,'runs',runId),logs=join(root,'logs');mkdirSync(logs,{recursive:true});mkdirSync(w,{recursive:true});
  cpSync(join(root,'planning/cases',c.id),join(w,'cases',c.id),{recursive:true});
  if(c.id==='fechas')cpSync(join(root,'planning/node_modules'),join(w,'node_modules'),{recursive:true});
  writeFileSync(join(w,'design.md'),design);writeFileSync(join(w,'tasks.md'),task);
  const request='Execute only the attached closed apply-packet/v2 as an ad-hoc sdd-apply. The deterministic Ein compiler validated it. Strict TDD is OFF. Read tasks.md/design.md only if needed. Modify only the packet writeAllowlist. Existing tests are read-only. Run its focused check. Do not create reports, commit, install packages, or edit tasks.md. No skills are required. Report any blocker instead of expanding scope.\n\n'+JSON.stringify(valid.packet,null,2);
  writeFileSync(join(w,'request.txt'),request);const before=files(w);
  const baseline=Bun.spawnSync(['bun','test',`cases/${c.id}/visible.test.ts`],{cwd:w,stdout:'pipe',stderr:'pipe'});
  writeFileSync(join(logs,runId+'-red.log'),baseline.stderr);
  const started=Date.now(),eventFile=join(logs,runId+'-events.jsonl'),errFile=join(logs,runId+'-stderr.log');
  const child=Bun.spawn([join(repo,'node_modules/.bin/pi'),'--offline','--no-extensions','--no-skills','--no-context-files','--no-prompt-templates','--no-themes','--provider','openai-codex','--model',model,'--thinking','low','--tools','read,grep,find,edit,write,bash','--system-prompt',join(root,'worker-system.txt'),'--mode','json','--session',join(logs,runId+'-session.jsonl'),'-p','@request.txt'],{cwd:w,env:{...process.env,PI_CODING_AGENT_DIR:join(root,'agent-home'),EIN_PI_AGENT_HOME:join(root,'agent-home')},stdout:Bun.file(eventFile),stderr:Bun.file(errFile)});
  let timedOut=false;const timeout=setTimeout(()=>{timedOut=true;child.kill();},240000);const code=await child.exited;clearTimeout(timeout);const elapsedMs=Date.now()-started;
  const after=files(w),changed=[...new Set([...Object.keys(before),...Object.keys(after)])].filter(p=>before[p]!==after[p]);
  // Restore independent tests after the model exits, then verify current source.
  cpSync(join(root,'planning/cases',c.id,'visible.test.ts'),join(w,'cases',c.id,'visible.test.ts'));
  cpSync(join(root,'holdout',c.id,'holdout.test.ts'),join(w,'cases',c.id,'holdout.test.ts'));
  const check=Bun.spawnSync(['bun','test',`cases/${c.id}`],{cwd:w,stdout:'pipe',stderr:'pipe'});writeFileSync(join(logs,runId+'-verify.log'),check.stderr);
  const diff=Bun.spawnSync(['git','diff','--no-index','--',join(root,'planning/cases',c.id,'source.ts'),join(w,'cases',c.id,'source.ts')],{stdout:'pipe',stderr:'pipe'});writeFileSync(join(logs,runId+'.diff'),diff.stdout);
  const rows=readFileSync(eventFile,'utf8').split('\n').flatMap(l=>{try{return [JSON.parse(l)]}catch{return []}});
  const messages=rows.filter(r=>r.type==='message_end'&&r.message?.role==='assistant').map(r=>r.message);
  const usage=messages.reduce((s,m)=>{const u=m.usage??{};for(const k of ['input','output','cacheRead','cacheWrite','totalTokens'])s[k]+=(u[k]??0);s.cost+=u.cost?.total??0;return s;},{input:0,output:0,cacheRead:0,cacheWrite:0,totalTokens:0,cost:0});
  const escaped=changed.filter(p=>!valid.packet.writeAllowlist.includes(p));
  const result={case:c.id,model,thinking:'low',exitCode:code,timedOut,elapsedMs,packetSha256:hash(JSON.stringify(valid.packet)),redExit:baseline.exitCode,verifyExit:check.exitCode,changed,escaped,pass:code===0&&!timedOut&&check.exitCode===0&&escaped.length===0&&baseline.exitCode!==0,turns:messages.length,usage,reportedModels:[...new Set(messages.map(m=>m.model))],final:messages.at(-1)?.content?.filter((c:any)=>c.type==='text').map((c:any)=>c.text).join('\n')};
  results.push(result);writeFileSync(join(root,'worker-results.json'),JSON.stringify(results,null,2)+'\n');console.log(JSON.stringify({case:c.id,model,pass:result.pass,seconds:Math.round(elapsedMs/1000),turns:messages.length,cost:usage.cost}));
 }
}
