import {mkdirSync,writeFileSync,readFileSync} from 'node:fs';
const root='/tmp/ein-simple-pilot-20260908',repo='/Users/samu/Documents/01_Proyectos/ein-agent';
const scenarios=[
 {id:'conversation',prompt:'¿Qué eres? Responde en español en una frase, sin ejecutar herramientas ni afirmar que tienes memoria disponible.'},
 {id:'small-change',prompt:'Solo quiero cambiar una errata en el texto de un botón, en un archivo ya identificado. No ejecutes nada todavía. Explica brevemente por qué vía de Ein lo harías y si activarías SDD completo o TDD estricto.'},
 {id:'sdd-routing',prompt:'Consulta de estado; no ejecutes nada. ein_sdd_status acaba de devolver next: sdd-verify; apply ya terminó, pero todavía no hay verificación de esta ejecución. ¿Qué paso corresponde y qué puedes afirmar ahora sobre el resultado? Responde brevemente.'}
];const results:any[]=[];const dir=root+'/context-runs';mkdirSync(dir,{recursive:true});
for(const [index,s] of scenarios.entries())for(const arm of index%2?['after','before']:['before','after']){
 const id=s.id+'-'+arm,start=Date.now(),events=dir+'/'+id+'-events.jsonl';
 const child=Bun.spawn([repo+'/node_modules/.bin/pi','--offline','--no-extensions','--no-skills','--no-context-files','--no-prompt-templates','--no-themes','--no-tools','--provider','openai-codex','--model','gpt-6-astra','--thinking','high','--system-prompt',root+'/context-'+arm+'.txt','--mode','json','--session',dir+'/'+id+'-session.jsonl','-p',s.prompt],{cwd:dir,env:{...process.env,PI_CODING_AGENT_DIR:root+'/agent-home',EIN_PI_AGENT_HOME:root+'/agent-home'},stdout:Bun.file(events),stderr:Bun.file(dir+'/'+id+'-stderr.log')});
 let timedOut=false;const timer=setTimeout(()=>{timedOut=true;child.kill();},180000);const exitCode=await child.exited;clearTimeout(timer);
 const rows=readFileSync(events,'utf8').split('\n').flatMap(l=>{try{return [JSON.parse(l)]}catch{return []}});const msgs=rows.filter(r=>r.type==='message_end'&&r.message?.role==='assistant').map(r=>r.message);const first=msgs[0];
 const result={scenario:s.id,arm,exitCode,timedOut,elapsedMs:Date.now()-start,promptBytes:Buffer.byteLength(readFileSync(root+'/context-'+arm+'.txt')),firstInputTokens:first?first.usage.input+first.usage.cacheRead+first.usage.cacheWrite:null,usage:msgs.map(m=>m.usage),reportedModels:[...new Set(msgs.map(m=>m.model))],response:msgs.at(-1)?.content?.filter((c:any)=>c.type==='text').map((c:any)=>c.text).join('\n')};
 results.push(result);writeFileSync(root+'/context-results.json',JSON.stringify(results,null,2)+'\n');console.log(JSON.stringify({scenario:s.id,arm,input:result.firstInputTokens,seconds:Math.round(result.elapsedMs/1000)}));
}
