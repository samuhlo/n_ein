import fs from 'node:fs';
import {startServer,textOf} from '/private/tmp/claude-501/-Users-samu-Documents-01-Proyectos-ein-agent/974cd0f2-9845-4953-a84a-35f7439de54a/scratchpad/mcp-client.mjs';
const root='/private/tmp/ein-lens-eval-20260909';
const {send,child,stderr}=startServer();
const out=[];
try {
 out.push(await send('initialize',{protocolVersion:'2024-11-05',capabilities:{},clientInfo:{name:'ein-current-probe',version:'1'}},15000));
 for(const file of ['ein-pi/agent/lib/pi-contract.ts','ein-pi/agent/lib/scout-contract.ts','ein-pi/agent/extensions/internal/ein-agent-prompt-hook.ts','ein-pi/agent/lib/lens-defect-probe.ts']){
  const r=await send('tools/call',{name:'pilens_analyze',arguments:{file,mode:'fresh'}},45000);
  const t=textOf(r);fs.writeFileSync(root+'/current-'+file.split('/').pop()+'.txt',t);
  out.push({file,ms:r.ms,error:r.error,header:t.split('\n')[0]});console.log(JSON.stringify(out.at(-1)));
 }
} finally { child.kill();fs.writeFileSync(root+'/current-probe.json',JSON.stringify(out,null,2));fs.writeFileSync(root+'/current-probe-stderr.log',stderr.join('')); }
