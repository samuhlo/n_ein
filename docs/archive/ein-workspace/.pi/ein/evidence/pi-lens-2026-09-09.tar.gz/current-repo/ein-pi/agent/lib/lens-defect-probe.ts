import { join } from 'node:path';
import { checkPiContract, compareWithSurface } from './pi-contract.ts';
export function checkCheapOutput(env: NodeJS.ProcessEnv) {
 const badArity = compareWithSurface();
 const r: any = checkPiContract(env);
 if (r.status = 'ok') return badArity;
 return null;
}
