import { readFileSync,writeFileSync } from 'node:fs';
import {resolvePiLaunchToolPlan} from '/Users/samu/.pi-ein/agent/npm/node_modules/pi-subagents/src/runs/shared/child-tool-plan.ts';
const s=readFileSync('/Users/samu/Documents/01_Proyectos/ein-agent/runtime/agents/sdd-apply.md','utf8');
const tools=/^tools: (.*)$/m.exec(s)![1].split(',').map(x=>x.trim());
const ext='/Users/samu/Documents/01_Proyectos/ein-agent/ein-pi/agent/extensions/internal/ein-apply-progress-child.ts';
const plan=resolvePiLaunchToolPlan({agentName:'sdd-apply',tools,subagentOnlyExtensions:[ext]});
const out={declaredTools:tools,declaredBuiltinTools:plan.declaredBuiltinTools,disableAmbientExtensions:plan.disableAmbientExtensions,extensionArgs:plan.extensionArgs,warnings:plan.warnings,toolAllowlistArgs:plan.toolAllowlistArgs,keys:Object.keys(plan)};
writeFileSync('/private/tmp/ein-lens-eval-20260909/child-plan.json',JSON.stringify(out,null,2));console.log(JSON.stringify(out));
