from pathlib import Path
import json,hashlib,tarfile
R=Path('/private/tmp/ein-engram-eval-20260911');S=Path('/private/tmp/ein-engram-sensitivity-20260911')
DEST=Path('/Users/samu/Documents/01_Proyectos/ein-agent/.pi/ein/evidence/engram-2026-09-11.tar.gz')
assert len(json.loads((R/'results.json').read_text()))==40
assert len(json.loads((S/'results.json').read_text()))==10
assert len(json.loads((R/'recall-results.json').read_text()))==8
excluded={'node_modules','__pycache__','recall-runs','capability-home','capability-cwd','capability-store'}
entries=[]
for prefix,root in [('primary',R),('sensitivity',S)]:
 for p in sorted(root.rglob('*')):
  rel=p.relative_to(root)
  if not p.is_file() or p.is_symlink() or any(x in excluded for x in rel.parts):continue
  if p.name in {'evidence-manifest.json','archive-receipt.json','auth.json','models-store.json'}:continue
  entries.append((f'{prefix}/{rel.as_posix()}',p))
manifest={name:hashlib.sha256(p.read_bytes()).hexdigest() for name,p in entries}
(R/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
DEST.parent.mkdir(parents=True,exist_ok=True)
with tarfile.open(DEST,'w:gz') as tar:
 for name,p in entries:tar.add(p,arcname=name,recursive=False)
 tar.add(R/'evidence-manifest.json',arcname='evidence-manifest.json')
with tarfile.open(DEST,'r:gz') as tar:
 actual={m.name:hashlib.sha256(tar.extractfile(m).read()).hexdigest() for m in tar.getmembers() if m.isfile() and m.name!='evidence-manifest.json'}
 assert actual==manifest
 assert not any(Path(name).name in {'auth.json','models-store.json'} for name in actual)
receipt={'path':str(DEST),'bytes':DEST.stat().st_size,'sha256':hashlib.sha256(DEST.read_bytes()).hexdigest(),'verifiedFiles':len(manifest)}
(R/'archive-receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt,indent=2))
