import { mkdtempSync,mkdirSync,writeFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { createSddMemoryLifecycle } from '/Users/samu/Documents/01_Proyectos/ein-agent/ein-pi/agent/lib/sdd-session-memory.ts';
const dir=mkdtempSync('/private/tmp/ein-engram-identity-');const repo=`${dir}/checkout`;mkdirSync(repo);
const git=(...args:string[])=>execFileSync('git',['-C',repo,...args],{stdio:'pipe',encoding:'utf8'});
git('init');git('remote','add','origin','https://github.com/fixture/shared-project.git');
writeFileSync(`${repo}/README.md`,'fixture');git('add','README.md');
git('-c','user.name=Fixture','-c','user.email=fixture@example.invalid','-c','commit.gpgSign=false','-c','core.hooksPath=/dev/null','commit','-m','fixture');
mkdirSync(`${repo}/subdir`);git('worktree','add','-b','work',`${dir}/other-tree`);
const rows=[];
for(const cwd of [repo,`${repo}/subdir`,`${dir}/other-tree`]){
 const calls:any[]=[];const life=createSddMemoryLifecycle(cwd,{transport:{async search(input){calls.push(input);return {operation:'search',status:'empty',reason:'no_results',entries:[]};},async save(){throw Error('unused');}}});
 await life.prepare({lifecycleKey:'probe',query:'project'});rows.push({cwd,projectId:calls[0]?.projectId});
}
const out={rows,sameProject:new Set(rows.map(r=>r.projectId)).size===1};
writeFileSync('/private/tmp/ein-engram-eval-20260911/identity-probe.json',JSON.stringify(out,null,2));console.log(JSON.stringify(out,null,2));
