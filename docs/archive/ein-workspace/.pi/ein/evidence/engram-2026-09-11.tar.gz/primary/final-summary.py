from pathlib import Path
import json,statistics
R=Path('/private/tmp/ein-engram-eval-20260911');S=Path('/private/tmp/ein-engram-sensitivity-20260911')
def cost(r):return r['planner']['usage']['cost']+r.get('executor',{}).get('usage',{}).get('cost',0)
def elapsed(r):return r['planner']['elapsed']+r.get('executor',{}).get('elapsed',0)
def group(rows):
 out={}
 for arm in sorted({r['arm'] for r in rows}):
  rs=[r for r in rows if r['arm']==arm]
  out[arm]={'n':len(rs),'pass':sum(r['pass_'] for r in rs),'cost':sum(cost(r) for r in rs),'plannerCost':sum(r['planner']['usage']['cost'] for r in rs),'executorCost':sum(r.get('executor',{}).get('usage',{}).get('cost',0) for r in rs),'seconds':sum(elapsed(r) for r in rs),'tokens':sum(sum(r.get(p,{}).get('usage',{}).get('totalTokens',0) for p in ['planner','executor']) for r in rs),'turns':sum(sum(r.get(p,{}).get('turns',0) for p in ['planner','executor']) for r in rs),'paired':[]}
  if arm=='none':continue
  for r in rs:
   b=next(x for x in rows if x['arm']=='none' and x['case']==r['case'] and x['repeat']==r['repeat'])
   out[arm]['paired'].append({'case':r['case'],'repeat':r['repeat'],'costDeltaPct':100*(cost(r)/cost(b)-1),'baseCost':cost(b),'armCost':cost(r),'bothPass':r['pass_'] and b['pass_']})
  out[arm]['medianCostDeltaPct']=statistics.median(p['costDeltaPct'] for p in out[arm]['paired'])
  out[arm]['aggregateCostDeltaPct']=100*(out[arm]['cost']/sum(cost(r) for r in rows if r['arm']=='none')-1)
 return out
primary=json.loads((R/'results.json').read_text());sensitivity=json.loads((S/'results.json').read_text());recall=json.loads((R/'recall-results.json').read_text())
assert len(primary)==40 and len(sensitivity)==10 and len(recall)==8
out={'primary':group(primary),'sensitivity':group(sensitivity),'recall':{},'captures':{n:json.loads((R/n).read_text())['usage']['cost'] for n in ['capture-result.json','recall-capture-result.json']}}
for case in ['retrieval','topics']:
 arms={}
 for arm in ['none','useful']:
  rs=[r for r in recall if r['case']==case and r['arm']==arm]
  arms[arm]={'n':len(rs),'cost':sum(r['usage']['cost'] for r in rs),'seconds':sum(r['elapsed'] for r in rs),'tools':sum(r['toolCalls'] for r in rs),'tokens':sum(r['usage']['totalTokens'] for r in rs)}
 arms['costDeltaPct']=100*(arms['useful']['cost']/arms['none']['cost']-1)
 out['recall'][case]=arms
base=sum(r['usage']['cost'] for r in recall if r['arm']=='none');mem=sum(r['usage']['cost'] for r in recall if r['arm']=='useful')
out['recallAggregate']={'baseCost':base,'usefulCost':mem,'costDeltaPct':100*(mem/base-1),'withCaptureDeltaPct':100*((mem+out['captures']['recall-capture-result.json'])/base-1)}
out['totalReportedApiCost']=sum(cost(r) for r in primary+sensitivity)+sum(r['usage']['cost'] for r in recall)+sum(out['captures'].values())
out['measuredModelCalls']=len(primary)*2+len(sensitivity)*2+len(recall)+len(out['captures'])
out['sensitivityWithCaptureDeltaPct']=100*((out['sensitivity']['useful']['cost']+out['captures']['capture-result.json'])/out['sensitivity']['none']['cost']-1)
(R/'final-summary.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
