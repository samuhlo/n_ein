import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { spawn, execFileSync } from 'node:child_process';
import { createServer } from 'node:net';
import { MemoryLifecycle } from '/Users/samu/Documents/01_Proyectos/ein-agent/ein-pi/agent/lib/memory-lifecycle.ts';
import { renderMemoryAdvisory } from '/Users/samu/Documents/01_Proyectos/ein-agent/ein-pi/agent/lib/sdd-session-memory.ts';
import type { EngramTransport } from '/Users/samu/Documents/01_Proyectos/ein-agent/shared/contracts/memory-contract.ts';
const R='/private/tmp/ein-engram-eval-20260911';
const notes=JSON.parse(readFileSync(`${R}/notes.json`,'utf8'));
const obsolete:Record<string,string>={
 fechas:'La validación de fechas usa únicamente forma YYYY-MM-DD. Se admiten días que Date normaliza al mes siguiente; no hace falta comprobar el calendario ni la longitud separadamente.',
 horario:'Las horas de inicio admiten minutos arbitrarios y formato H:mm. La jornada debe terminar estrictamente antes de las 21:00.',
 progreso:'Los decimales de hechos y total son significativos y se conservan; Infinity en hechos equivale a progreso completo.',
 stun:'stunUrl admite turn y turns porque el parser genérico de ICE ya reconoce estos esquemas válidos.',
 'ice-query':'La parte posterior al segundo signo de interrogación es información ignorada intencionalmente; split con límite dos implementa ese contrato.',
};
const net=createServer();await new Promise<void>(resolve=>net.listen(0,'127.0.0.1',resolve));
const port=(net.address() as {port:number}).port;await new Promise<void>(resolve=>net.close(()=>resolve()));
mkdirSync(`${R}/store`,{recursive:true});
const env={...process.env, ENGRAM_DATA_DIR:`${R}/store`, ENGRAM_NO_UPDATE_CHECK:'1'};
delete env.ENGRAM_CLOUD_AUTOSYNC;
const child=spawn('engram',['serve',String(port)],{env,stdio:['ignore','pipe','pipe']});
let serverLog='';child.stdout.on('data',v=>serverLog+=v);child.stderr.on('data',v=>serverLog+=v);
const base=`http://127.0.0.1:${port}`;
async function get(path:string){
 const response=await fetch(base+path,{signal:AbortSignal.timeout(1500)});
 if(!response.ok)throw Error(`HTTP ${response.status}`);
 const text=await response.text();if(Buffer.byteLength(text)>16384)throw Error('output_cap');return JSON.parse(text);
}
try{
 let ready=false;for(let i=0;i<50;i++){try{await get('/health');ready=true;break;}catch{await new Promise(r=>setTimeout(r,100));}}
 if(!ready||child.exitCode!==null)throw Error('isolated server did not start');
 const raw:any[]=[];
 const transport:EngramTransport={
  async search({query,projectId}){
   try{
    const found=await get(`/search?q=${encodeURIComponent(query)}&project=${encodeURIComponent(projectId)}&scope=project&limit=5`);
    raw.push({query,projectId,found});
    if(found===null||(Array.isArray(found)&&found.length===0))return {operation:'search',status:'empty',reason:'no_results',entries:[]};
    if(!Array.isArray(found))throw Error('expected search array');
    const entries=[];
    for(const candidate of found){
     if(!Number.isInteger(candidate.id))throw Error('missing ID');
     const full=await get(`/observations/${candidate.id}`);raw.push({id:candidate.id,full});
     if(typeof full.content!=='string'||full.project!==projectId)throw Error('invalid or cross-project observation');
     entries.push({content:`${full.title}\n${full.content}`,projectId:full.project,topic:full.topic_key,timestamp:full.created_at?.replace(' ','T')+'Z'});
    }
    return {operation:'search',status:'retrieved',reason:'ok',entries};
   }catch{return {operation:'search',status:'failed',reason:'malformed_output',entries:[]};}
  },
  async save(){throw Error('read-only prototype');},
 };
 const result:Record<string,any>={};
 for(const [c,note] of Object.entries(notes)){
  result[c]={};
  for(const arm of ['none','useful','irrelevant','conflicting']){
   const project=`eval-${c}-${arm}`;
   if(arm!=='none'){
    const content=arm==='useful'?String(note):arm==='conflicting'?obsolete[c]:`La página de documentación ${c} usa tipografía sans serif y navegación lateral. Esta observación describe presentación visual, no la validación de datos.`;
    execFileSync('engram',['save',`${c}: antecedente`,content,'--project',project,'--type','learning','--scope','project','--topic',`lesson/${c}`],{env,stdio:'pipe',timeout:5000});
   }
   const lifecycle=new MemoryLifecycle({transport,project:{kind:'remote',id:project}});
   const prepared=await lifecycle.prepare({lifecycleKey:'task',query:c});
   if(prepared.receipt.status!==(arm==='none'?'empty':'retrieved'))throw Error(`unexpected receipt ${c}/${arm}: ${JSON.stringify(prepared)}`);
   if(arm!=='none'&&!prepared.entries[0]?.content.includes(arm==='useful'?String(note):arm==='conflicting'?obsolete[c]:'tipografía'))throw Error('lost body');
   result[c][arm]={advisory:arm==='none'?'':renderMemoryAdvisory(prepared),receipt:prepared.receipt};
  }
 }
 writeFileSync(`${R}/memory.json`,JSON.stringify(result,null,2));
 writeFileSync(`${R}/memory-raw.json`,JSON.stringify(raw,null,2));
 console.log(JSON.stringify({combinations:20,completeNotes:15,emptyCorrect:5,store:`${R}/store`}));
}finally{child.kill();writeFileSync(`${R}/memory-server.log`,serverLog);}
