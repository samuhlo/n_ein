from pathlib import Path
import json,hashlib,re,statistics
R=Path('/private/tmp/ein-engram-eval-20260911');S=Path('/private/tmp/ein-engram-sensitivity-20260911')
def read(p):return json.loads(p.read_text()) if p.exists() else []
audit={'groups':{},'recall':[],'suspiciousToolCalls':[],'models':{},'phaseCalls':0}
for name,root in [('primary',R),('sensitivity',S)]:
 rows=read(root/'results.json')
 audit['groups'][name]={'count':len(rows),'passed':sum(r['pass_'] for r in rows),'errors':[]}
 for r in rows:
  for phase in ['planner','executor']:
   if phase not in r:continue
   m=r[phase];audit['phaseCalls']+=1
   for model in m['models']:audit['models'][model]=audit['models'].get(model,0)+1
   if m['errors'] or m['exitCode']!=0:audit['groups'][name]['errors'].append(m['id'])
   path=root/'logs'/f"{m['id']}-events.jsonl"
   for line in path.read_text().splitlines():
    try:e=json.loads(line)
    except:continue
    if e.get('type')!='message_end' or e.get('message',{}).get('role')!='assistant':continue
    for call in e['message'].get('content',[]):
     if call.get('type')!='toolCall':continue
     args=call.get('arguments',{});text=json.dumps(args)
     if 'holdout' in text or re.search(r'\b(?:npm install|bun add|git commit|git push)\b',text):audit['suspiciousToolCalls'].append({'id':m['id'],'tool':call['name'],'args':args})
     p=args.get('path')
     if isinstance(p,str) and (p.startswith('..') or (p.startswith('/') and not p.startswith(str(root/'runs'/r['id'])+'/'))):audit['suspiciousToolCalls'].append({'id':m['id'],'tool':call['name'],'path':p})
for r in read(R/'recall-results.json'):
 audit['phaseCalls']+=1
 for model in r['models']:audit['models'][model]=audit['models'].get(model,0)+1
 audit['recall'].append({'id':r['id'],'exitCode':r['exitCode'],'timeout':r['timeout'],'errors':r['errors'],'allQuotesExact':bool(r.get('quotes')) and all(q['exact'] for q in r['quotes']),'requiredPathsCited':r.get('requiredPathsCited',False),'unchanged':r['unchanged'],'diagnosisWords':len(r.get('answer',{}).get('diagnosis','').split())})
for filename in ['capture-result.json','recall-capture-result.json']:
 r=read(R/filename);audit['phaseCalls']+=1
 for model in r['models']:audit['models'][model]=audit['models'].get(model,0)+1
manifest=read(R/'recall-manifest.json');repo=Path('/Users/samu/Documents/01_Proyectos/ein-agent')
audit['originalTrackedFilesChangedSinceSnapshot']=[f for f,h in manifest.items() if not (repo/f).is_file() or hashlib.sha256((repo/f).read_bytes()).hexdigest()!=h]
(R/'audit.json').write_text(json.dumps(audit,indent=2));print(json.dumps(audit,indent=2))
