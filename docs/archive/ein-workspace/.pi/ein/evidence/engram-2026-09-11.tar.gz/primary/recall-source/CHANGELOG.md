# Changelog

Todos los cambios relevantes de Ein. El formato sigue
[Keep a Changelog](https://keepachangelog.com/es/1.1.0/) y el versionado es
[SemVer](https://semver.org/lang/es/). Las releases se publican como tags

## [0.96.0-alpha.3] - 2026-09-08

### Changed

- **Escala de contraste coherente en Pi.** El texto secundario deja de apilar
  `DIM` sobre gris; fases hechas, actuales y pendientes tienen pesos distintos.
  Los títulos de sección ganan presencia y el foco abre la fila por la izquierda.
- **Banner centrado en el trabajo.** Repositorio y sesiones recientes aparecen
  primero; los ajustes se agrupan en filas compactas y el inventario pasa al pie.
  La nota de Engram se traduce y ocupa el final del estado SDD.

### Fixed

- **La tarea iniciada conserva su sitio.** El TODO cuenta los encabezados de
  grupo y el resumen de tareas ocultas antes de seleccionar las filas visibles.
  Evita tanto perder la tarea actual como dejar un encabezado sin tareas debajo.
- **Los ajustes del banner no desaparecen al llenarse una fila.** Los pares
  continúan en otra línea, incluyendo Linear con idiomas distintos o TDD estricto.
- **El encabezado respeta terminales estrechas.** Reserva el ancho real de fase
  y progreso antes de recortar el nombre, también con totales de varias cifras.

## [0.96.0-alpha.2] - 2026-09-07

### Fixed

- **Cleaner arranca con sus herramientas en primer plano.** Carga una extensión
  propia sin los hooks del orquestador y conserva la causa de los fallos de
  arranque como evidencia no disponible.
- **Subagentes visibles durante el trabajo.** El panel nativo muestra agentes,
  actividad y estado sobre el editor; el TODO ocupa su espacio debajo. Se
  separan los nombres pegados y los mensajes heredan el fondo de la terminal.
- **Progreso tarea a tarea.** Apply registra inicio y finalización en `tasks.md`
  antes de avanzar. El TODO distingue una tarea iniciada de la siguiente
  pendiente y recupera el progreso al reabrir la sesión.
- **Cierre sin reintentos por formato.** Una herramienta genera los metadatos y
  comandos del resumen a partir de evidencia aprobada y fresca. Rechaza
  comandos no registrados y conserva las puertas de verificación y archivo.
- **Decisiones guardadas antes de scope.** La inicialización explícita publica
  modalidad y TDD conjuntamente. Mapa y diseño reciben asignaciones de contexto
  independientes, respetando los límites del usuario.

### Changed

- **Comunicación más breve y estados más precisos.** El pensamiento se oculta
  por defecto, las explicaciones se ajustan a la complejidad y la aprobación
  del mismo plan se conserva. Comprobación y cierre mantienen visibles las
  revisiones asesoras pendientes, fallidas o que ya no corresponden al código.

## [0.96.0-alpha.1] - 2026-09-07

### Added

- **Despliegue local sin publicar una alpha.** `bun run dev:install` compila
  únicamente para la máquina actual y ejecuta el instalador generado. Incluye
  previsualización con `--dry-run` y compilación sin despliegue con `--build-only`.

### Fixed

- **Cleaner conserva su tarea al delegarla.** Los escapes mantienen su contenido
  y las restricciones adicionales del padre no se confunden con una identidad
  caducada; alcance y frescura siguen comprobándose.
- **TDD tiene una sola decisión por cambio.** Se guarda en disco, se adopta al
  reanudar y actualiza la caché; cancelar la elección no equivale a desactivarlo.
- **El cierre y la revisión comparten contrato.** La forma de los encabezados
  deja de bloquear. El resumen conserva los informes terminales antes de
  compactar y el cierre no modifica `EIN.md`.
- **El TODO se actualiza mientras trabajan los subagentes.** Se muestra sobre
  el editor; la flota queda debajo y las tarjetas del chat son más compactas.
- **Estados y errores explican su causa.** Se distingue una revisión desactivada
  de una no disponible y se muestra la procedencia de la configuración Linear.

### Changed

- **Explicaciones proporcionales al cambio.** Los arreglos localizados no exigen
  siete secciones ni confirmaciones repetidas. La política de Claude permanece
  alineada con la fuente compartida.

## [0.95.0-alpha.4] - 2026-09-04

### Fixed

- **Los Apply Packets aceptan sintaxis TypeScript decidida.** Genéricos como
  `Record<string, unknown>`, comparadores escritos con espacios y el operador
  `??` ya no se confunden con placeholders o decisiones pendientes; los
  marcadores reales siguen bloqueando el encargo.
- **Scout conserva el trabajo útil de un modelo barato.** Los alias seguros
  observados en producción se canonicalizan antes del cierre estricto, las
  mezclas ambiguas continúan rechazándose y cada error de forma nombra la clave
  que debe corregirse.
- **El árbol interno de Pi se detecta y repara durante install/update.** Ein
  comprueba los rangos que declara el host, actualiza solo los paquetes
  `@earendil-works/*` incompatibles y vuelve a leer los manifiestos antes de
  declarar éxito. El doctor verifica la misma coherencia de forma independiente.
- **El aviso de grupos grandes cuenta escritura real.** Las rutas citadas como
  contexto de lectura o dentro de explicaciones ya no inflan el número de
  archivos que un grupo de Apply declara modificar.

### Release

- **El smoke publicado actualiza desde `0.95.0-alpha.3`.** La comprobación final
  descarga los assets públicos, ejecuta el update real y exige que la nueva
  instalación termine con el doctor en verde.

## [0.95.0-alpha.3] - 2026-09-03

### Fixed

- **Los fallos de arranque del scout conservan su causa real.** Si un workflow
  no produce resultados porque ningún modelo resulta utilizable, Ein muestra
  el error estructurado del runtime en lugar de culpar falsamente a foreground,
  y corta el siguiente intento del mismo turno antes de gastar más ramas.
- **Una respuesta vacía ya no inutiliza durante un día todos los agentes del
  mismo modelo.** La caché administrada de exclusiones baja de 24 horas a cinco
  minutos y acorta las entradas activas al reiniciar. Durante ese intervalo
  sigue fallando cerrado y nunca selecciona un fallback sin configuración del
  usuario.

### Release

- **El smoke publicado actualiza desde `0.95.0-alpha.2`.** La comprobación final
  descarga los assets públicos, conserva el estado y verifica la nueva versión
  antes de cerrar la release.

## [0.95.0-alpha.2] - 2026-09-03

### Fixed

- **Todo mensaje de Pi vuelve a llegar intacto al orquestador.** Se elimina el
  preflight léxico que convertía `hola`, auditorías contextuales y mensajes de
  extensión en un formulario, devolvía `handled` y dejaba al modelo sin la
  petición original. El modelo capaz decide ahora por significado si responde,
  trabaja o pregunta por una decisión material.
- **El canal de intención recupera su frontera explícita.** `/ein:intent` sigue
  disponible cuando una conversación de decisiones aporta valor, pero el
  runtime no lo activa ni persiste intención por inferencia.

### Changed

- **Pi actualiza su runtime administrado antes de abrir una sesión.** El
  launcher reconcilia host y extensiones `latest` una sola vez antes de entregar
  el terminal; un fallo solo degrada si la instalación existente sigue siendo
  utilizable y nunca filtra metadata efímera al updater.

### Release

- **El smoke publicado reproduce la reparación desde la alpha afectada.** La
  actualización final parte de `installer-v0.95.0-alpha.1`, preserva el estado
  del usuario y valida los assets públicos de `0.95.0-alpha.2`.

## [0.95.0-alpha.1] - 2026-09-03

### Added

- **El modelo capaz entrega una orden ejecutable por grupo.**
  `apply-packet/v2` convierte el siguiente grupo de `tasks.md` en pasos
  ordenados con fronteras independientes de lectura, escritura y verificación;
  una fuente obsoleta, un campo ausente o una decisión abierta fallan cerrado.
- **La calidad del handoff ya se puede medir en sesiones reales.** Cada intento
  exclusivo de `sdd-apply` conserva un recibo pequeño ligado al tool call, y
  `/ein:accounting` muestra estados, telemetría malformada, tasa de packets
  ejecutables y la racha actual sin confundir readiness con código correcto.

### Changed

- **Los modelos caros concentran el pensamiento donde aporta valor.** Scope,
  design y tasks recomiendan razonamiento alto; apply conserva trabajo mecánico
  con razonamiento bajo y la elección concreta de proveedor sigue perteneciendo
  al usuario.
- **Pi y las extensiones administradas siguen `latest`.** Instalación,
  reparación, actualización, CI y release resuelven la combinación vigente y
  hacen visible cualquier incompatibilidad upstream en vez de congelarla.

### Release

- **El smoke publicado actualiza desde la última alpha disponible.** La
  publicación de `0.95.0-alpha.1` probará preservación y actualización real
  desde `installer-v0.94.0-alpha.4` antes de darse por terminada.

## [0.94.0-alpha.4] - 2026-09-02

### Fixed

- **El smoke posterior a la publicación fija el tag objetivo exacto.** La
  verificación ya no depende de que el endpoint `latest` de GitHub refleje una
  release recién creada; descarga, instala y valida los assets publicados para
  la versión que disparó el workflow.

## [0.94.0-alpha.3] - 2026-09-02

### Changed

- **Ein vuelve a tener un único núcleo: Pi.** La instalación pública ofrece
  Ein o Ein con Claude Code; ya no admite Claude como destino independiente y
  el acceso normal queda concentrado en el ejecutable `ein` instalado.
- **Claude Code queda como complemento opcional.** Solo se instala después de
  verificar Pi y su ausencia ya no convierte una instalación básica de Ein en
  un falso error de dependencia.
- **La interfaz y la documentación explican el producto real.** El selector,
  la ayuda, el preflight y las guías distinguen el núcleo Pi de las
  integraciones opcionales sin añadir otra capa de instalador.

### Fixed

- **Un fallo de Pi detiene el flujo antes de Claude.** El ejecutor mantiene el
  orden núcleo-complemento y deja las operaciones posteriores como no
  ejecutadas en el diario de recuperación.
- **Un fallo al añadir Claude no deja bloqueado un Ein funcional.** Si Pi ya
  quedó verificado, el siguiente intento puede cerrar una instalación solo Pi
  o volver a intentar Claude desde una transacción nueva y comprobada.
- **La desinstalación conserva compatibilidad selectiva.** Aunque ya no se
  instala Claude en solitario, sigue siendo posible retirar únicamente sus
  superficies gestionadas sin tocar Pi ni los datos privados del usuario.

### Release

- **La publicación queda bloqueada por el E2E del instalador real.** Antes de
  generar checksums o subir assets, la CI prueba hogares Ubuntu limpios,
  Omarchy, reinstalación, rollback, desinstalación y el binario `ein` realmente
  promovido; después valida la actualización desde `0.93.0-alpha.4`.
- **El E2E desactiva la caché del transpilador Bun que ejecuta las pruebas.**
  Así los `.pile` desechables de Bun 1.4 no se confunden con una mutación del
  hogar de Ein en runners limpios de CI.

## [0.93.0-alpha.4] - 2026-09-02

### Fixed

- **Claude Code se instala y verifica de verdad cuando el destino es Claude o
  ambos runtimes.** El plan usa el instalador nativo oficial, exige que el
  ejecutable responda antes de desplegar Ein y deja de anunciar una integración
  utilizable cuando faltaba el CLI.
- **`gh` ya se instala en Omarchy y Arch.** Omarchy usa su integración de Mise
  con el backend explícito `github:cli/cli`, evitando el wrapper ambiguo que
  podía fallar; el resto de sistemas ejecuta su gestor de paquetes y verifica
  el binario resultante.
- **El bootstrap de una alpha ya no fuerza Pi.** `install.sh` acepta
  `--runtime pi|claude|both` y conserva ese destino al entregar el control al
  instalador descargado.
- **El E2E de Omarchy cubre el recorrido completo.** Instala Claude Code real,
  ejecuta `ein-cc` desde Fish y prueba reinstalación del destino combinado.

## [0.93.0-alpha.3] - 2026-09-02

### Fixed

- **Una instalación incompleta de `0.93.0-alpha.1` en Omarchy se recupera sin
  borrar estado a mano.** Si el despliegue gestionado llegó hasta `doctor` y
  falló allí, Ein reconoce únicamente esa forma cerrada del diario, crea una
  transacción nueva, toma backup y vuelve a ejecutar el plan con las
  dependencias observadas de nuevo.
- **El E2E parte ahora del fallo publicado real.** Descarga `alpha.1`, reproduce
  la divergencia de Pi y su diario bloqueado, y exige que el candidato complete
  dos instalaciones y termine con `doctor` sin fallos.

## [0.93.0-alpha.2] - 2026-09-02

### Fixed

- **La instalación de Pi ya no diverge en Omarchy cuando Bun redirige sus
  globales.** Ein fija su runtime administrado en `~/.bun/bin`, comprueba allí
  la versión realmente ejecutable y solo declara éxito si coincide con el pin
  requerido.
- **Las dependencias opcionales dejan de aparecer como éxitos falsos.** Si
  `gh`, Engram, Hypa o Codegraph no se instalan, la instalación puede continuar
  pero el progreso conserva la causa y lo muestra como aviso.
- **La matriz E2E reproduce la regresión observada.** Parte de Pi `0.84.4`,
  activa `BUN_INSTALL_GLOBAL_DIR` y `BUN_INSTALL_BIN` alternativos, instala dos
  veces y exige Pi `0.84.3` canónico más un `doctor` sin fallos.

## [0.93.0-alpha.1] - 2026-09-02

### Added

- **La salida de la auditoría arquitectónica queda convertida en fronteras
  verificables.** El núcleo SDD compartido concentra intención, routing,
  remedios, validación, sincronización OpenSpec, resumen y cierre; Pi y Claude
  lo consumen mediante adaptadores explícitos en vez de duplicar el cerebro.
- **La release prueba el ciclo de vida, no solo que el binario arranque.** La
  matriz en hogares desechables cubre Pi, Claude y ambos, reinstalación,
  actualización, rollback, launcher, uninstall recuperable y preservación de
  credenciales, sesiones, secrets y ficheros ajenos.

### Changed

- **El launcher y el estado de proyecto tienen dueños claros.** Lectores,
  sesiones, renderizado y acciones se componen desde una raíz explícita; los
  puentes que siguen siendo específicos de Pi están inventariados con su dueño
  y condición de retirada.
- **Repositorio, runtime distribuido y skills externas quedan separados.** El
  payload se construye mediante una allowlist y valida su grafo de cierre, de
  forma que la instalación compilada funciona fuera del checkout sin arrastrar
  tooling ni dependencias accidentales.
- **La publicación de una alpha enseña un comando reproducible por tag.** Las
  notas ya no ofrecen por error el bootstrap del canal estable y el workflow
  comprueba una actualización real desde la alpha anterior tras publicar.

### Fixed

- **Reinstalar deja de confundirse con idempotencia byte a byte en binarios Bun.**
  La evidencia compara el árbol gestionado estable y comprueba por separado la
  presencia y ejecución de los binarios compilados, cuyos bytes pueden variar
  entre compilaciones equivalentes.
- **La prueba de uninstall usa la copia realmente instalada de `ein-install`.**
  Así calcula el directorio de comandos del hogar desechable, retira solo lo
  gestionado y conserva el estado privado junto a su manifiesto de recuperación.

## [0.92.0-alpha.1] - 2026-08-28

### Added

- **Ein incorpora un canal de intención explícito y compartido.** `/ein:intent`
  recorre con la persona las decisiones que delimitan un cambio y solo escribe
  `intent.md` después de confirmación; `/ein:eh` reformula la petición en
  lenguaje llano sin actuar. Pi y Claude consumen el mismo protocolo sin cargar
  coste de prompt cuando no se invoca.
- **Una sesión de Pi puede recuperar el TODO sin reiniciarse.**
  `/ein:focus <cambio>` valida que el cambio siga activo, lo vincula a la sesión
  y repinta el panel sin despachar trabajo SDD al modelo.
- **`ein-install update` permite elegir canal de publicación.** `--channel
  stable|alpha` cambia la preferencia solo cuando la actualización se completa
  o ya estaba al día; dry-runs, bloqueos y fallos conservan el valor anterior.

### Changed

- **El preflight de intención se ejecuta antes de construir.** El flujo común
  clasifica trabajo normal frente a cambios pequeños o documentales, respeta
  primero cualquier lane declarada y persiste la resolución en `preflight.json`.
  Los riesgos protegidos y la evidencia insuficiente siguen tomando la ruta
  cerrada, mientras `/ein:intent` permanece exclusivamente humano.
- **El launcher hace visible qué cambio recibirá Pi.** Tras elegir un cambio en
  Estado del proyecto y volver atrás, la acción principal pasa a mostrarse como
  `Pi · continuar <cambio>` y una sesión nueva hereda ese foco antes de arrancar.

### Fixed

- **El TODO deja de desaparecer al iniciar o recuperar sesiones.** Una sesión
  sin binding muestra automáticamente el único cambio activo y, si hay varios,
  declara la ambigüedad en lugar de quedar vacía. El intent de lanzamiento se
  consume en el primer `session_start` válido aunque Pi use otro motivo de
  arranque.
- **Las tareas del TODO vuelven a ser distinguibles.** El título de un grupo se
  muestra una sola vez; las filas siguientes enseñan el texto real de cada
  tarea en vez de repetir la misma etiqueta sobre todos los checkboxes.

## [0.91.0-alpha.3] - 2026-08-27

### Changed

- **Ein adopta una nomenclatura única y enseña una sola puerta de entrada.**
  `ein` queda como aplicación pública y `ein-install` como bootstrap y
  reparación; los accesos avanzados pasan a llamarse `ein-pi`, `ein-cc` y
  `ein-cc-sdd`. Código, payload, ayuda, especificaciones y documentación usan
  ya esos nombres Ein-first.
- **La actualización aplica un corte limpio de los nombres anteriores.** La
  `legacy-migration` retira únicamente launchers y binarios de alpha.2 cuyo
  ownership puede probarse por bytes, marcador y ruta exactos; una colisión del
  usuario se conserva. Los hogares `~/.pi-ein/agent` y `~/.claude-ein`, junto a
  sus sesiones y configuración, permanecen sin cambios.

### Fixed

- **La retirada de accesos antiguos sobrevive a interrupciones.** Un manifiesto
  durable registra cada movimiento antes de ejecutarlo y permite reanudar o
  restaurar bytes y permisos mediante los journals de instalación y
  actualización; la copia de recuperación solo se elimina tras el commit
  global.
- **Los payloads generados en macOS son portables a Linux.** El empaquetado
  excluye metadatos AppleDouble y atributos extendidos, evitando miembros
  invisibles `._*` que GNU tar extraía fuera del manifiesto.

## [0.91.0-alpha.2] - 2026-08-27

### Fixed

- **Cleaner y Architect reciben alcances completos y cerrados.** Sus tools
  publican al modelo el esquema anidado real; Cleaner distingue exactamente el
  conjunto de ficheros cambiados de los selectores explícitos y Architect deja
  de encadenar reintentos `malformed-or-missing-scope` ante una auditoría válida.
- **Cleaner puede inspeccionar todo el código admitido sin escapar del repo.** El
  paquete visible para el modelo incluye cada fuente junto a los hechos medidos,
  admite configuración y scripts relevantes y rechaza lecturas o escrituras que
  atraviesen un enlace simbólico ancestro.

## [0.91.0-alpha.1] - 2026-08-27

### Added

- **El orquestador de Pi admite esfuerzo `high` y `xhigh`.** El modelo principal
  deja de ser la única pieza cuyo nivel de razonamiento no podía elegirse; la
  selección se guarda en la configuración administrada y sobrevive a reinicios
  y actualizaciones.
- **`ein:accounting` convierte el historial de sesiones en métricas útiles para
  modelos API y locales.** Agrega coste opcional, tokens de salida, picos de
  prompt y secuencia, turnos, fallos, fallbacks y reruns por padre, subagente,
  modelo y agente. Cada cifra declara su cobertura y procedencia; ausencia de
  precio o datos se representa como desconocida, nunca como un cero inventado.

### Changed

- **El runtime de Pi queda reproducible con versiones compatibles exactas.** El
  instalador reconcilia y los doctors verifican Pi `0.84.3`, `pi-subagents`
  `0.57.0`, `pi-mcp-adapter` `2.28.0`, `context-mode` `1.0.169`, `ask-user`
  `2.7.1` e `i18n` `2.7.1`, tanto en la declaración como en la instalación
  efectiva.
- **Los doctors comparten un único núcleo de comprobaciones.** Installer y
  runtime dejan de mantener copias divergentes de las mismas reglas, conservan
  los chequeos propios de cada superficie y respetan homes de agente aislados.

### Fixed

- **La instalación de paquetes de Pi funciona en una máquina limpia.** El
  instalador comprueba que exista Node `22.19.0` o posterior y explica cómo
  corregirlo antes de instalar Pi. Las extensiones usan Bun en vez de asumir
  que también existe `npm`; si fallan, se conserva la primera causa real.
- **`ein-scout` recupera informes válidos decorados por el runtime.** Los cierres
  por presupuesto, recibos y envoltorios de `pi-subagents` ya no convierten una
  investigación terminada en un falso contrato malformado.
- **El progreso del instalador es append-only.** Los pasos completados avanzan
  hacia abajo sin repintar las filas anteriores, evitando congelaciones y
  pérdida de trazabilidad en terminales reales y salidas redirigidas.
- **La contabilidad no duplica transcript y artefacto en los desgloses.** Las
  identidades de modelo se normalizan como `provider/modelo`, el canal primario
  prevalece también dentro de `byModel` y los transcripts parciales no pueden
  declarar cobertura completa. En el corpus auditado, `overall`, `byModel` y
  `byAgent` vuelven a sumar exactamente lo mismo.

## [0.90.0-alpha.2] - 2026-08-26

### Fixed

- **`ein-install update` ya puede saltar a una release alpha.** La sonda que
  verifica el binario descargado antes de reemplazarlo leía la versión con un
  patrón que exigía fin de línea tras `X.Y.Z`: con `0.90.0-alpha.1` casaba
  `0.90.0`, se topaba con el `-alpha.1` y devolvía nada, así que la
  actualización abortaba en `verifying`. Ahora lee el SemVer entero, sufijo
  incluido, y sigue rechazando lo que no es una versión.
- **Un intento de actualización fallido ya no deja restos.** Al abortar en la
  verificación se devolvía el error sin descartar el binario candidato ni el
  snapshot del template — unos 100 MB huérfanos junto al binario bueno por cada
  intento.

## [0.90.0-alpha.1] - 2026-08-26

### Changed

- **La marca es la misma en las tres puertas del producto.** El televisor deja
  de componerse por separado en cada superficie: `placaRows` vive con el aparato
  y la usan el banner de Pi, el splash, la portada de `ein` y el instalador. Y
  el mueble pierde antena y patas — siendo un rectángulo, todas sus filas miden
  lo mismo y el centrado por fila deja de descolocarlo.
- **El arranque de Pi baja de 44 filas a 30.** La marca y sus datos comparten
  banda en vez de apilarse, y las secciones `sistema` y `sesion` del panel de
  estado se dibujan en paralelo: ninguna de las dos pasaba de media placa. Sigue
  cabiendo en 62 columnas.
- **La portada de `ein` agrupa su menú por verbo.** Arrancar, continuar y taller,
  sin mover una fila ni cambiar un atajo. Su cabecera —que se leía `ein   ein`—
  pasa a ser la barra de contexto, con el cambio SDD en curso, su fase y su
  siguiente paso a la vista.

### Added

- **El instalador enseña su plan y lo va tachando.** Los pasos pendientes se
  pintan desde el primer fotograma, con contador y barra. El plan ya se calculaba
  antes de tocar la máquina —es lo que alimenta el journal de recuperación—, así
  que solo faltaba enseñarlo. Sin terminal no se repinta: `curl | bash` recibe un
  fichero, no una pantalla.
- **El TODO queda vinculado a la sesión de Pi.**

### Fixed

- **El foco vuelve a pintar en el menú de runtime del instalador.** Las tres
  opciones llegaban envueltas en `gold(...)` desde el punto de llamada, y el
  `concrete(...)` que el prompt aplica a la fila con foco no puede tapar un ANSI
  interior: salían las tres amarillas, con cursor encima o sin él. Sus pistas
  dicen ahora qué se instala y qué launcher deja puesto.
- **El efecto `spinner` del instalador deja de ser código muerto.** Los handlers
  llamaban al spinner real en vez de al inyectado, así que un test no podía
  silenciarlo ni saber qué paso corría.
- **El fixture de PTY queda aislado en Ubuntu.**

## [0.82.0-alpha.4] - 2026-08-25

### Fixed

- **La instalación de Pi vuelve a mantener coherente la integración Linear.**
  La selección `off`/`on`, su persistencia global y el resumen final comparten
  ahora el mismo contrato, incluido el valor `off` por defecto.
- **Los doctors del installer y del runtime validan el flujo dinámico actual.**
  Ambos comprueban el módulo canónico, la inyección del prompt y la evidencia
  persistida sin exigir el módulo ni el vocabulario Solo/Team retirados.
- **Una regresión staged cubre la instalación limpia de extremo a extremo.**
  El bundle generado atraviesa el deploy y los doctors reales para `off` y
  `on`, y conserva fallos cerrados ante costuras o evidencia defectuosas.

## [0.82.0-alpha.3] - 2026-08-25

### Fixed

- **Las instalaciones alpha con marcador v1 ya se reconocen como instalaciones
  standalone gestionadas por Ein.** Esto permite ejecutar `ein-install update`
  desde alpha.1 y alpha.2, mientras los canales no válidos siguen fallando de
  forma cerrada.

## [0.82.0-alpha.2] - 2026-08-25

### Fixed

- **El overlay del cambio ya no se congela al repintar.** El panel SDD
  (TODO overlay) dejaba de responder tras ciertos eventos de repintado: el
  layout del widget se recalculaba en un estado intermedio y el widget
  quedaba fijo en pantalla. La recuperación se activa ahora en cuanto se
  detecta el bloqueo, sin esperar a un gesto del usuario. Cobertura:
  `tests/sdd-overlay-repaint.test.ts` y `tests/subagent-widget-layout.test.ts`.
  Investigación completa en
  la investigación histórica del freeze, conservada en Git.
- **Los títulos de los grupos de tareas se renderizan correctamente sobre el
  overlay.** El router SDD no transmitía la referencia al título del grupo al
  componente de overlay, así que los grupos de tareas se enseñaban sin nombre.
  Se inyecta ahora esa referencia y la cobertura correspondiente.
- **El guard de dependencias de workspace ya no bloquea con falso positivo.**
  El detector de dependencias de workspace rechazaba cambios en raíz que no
  tocaban el lockfile del workspace, porque su lógica no distinguía entre
  «el workspace es monolítico» y «el cambio no afecta a ningún paquete».

### Added

- **Schema canónico del corpus de apply (`apply-corpus.ts`) y del paquete de
  entrega (`apply-packet.ts`).** Un corpus cerrado de 39+ patrones de ejecución
  del apply-cicle con su variante congelada, más un schema formalizado para
  los paquetes que `sdd-apply` intercambia con `sdd-verify`. Ambos blindan
  contra deriva del contrato y permiten comprobación determinista de cualquier
  entregable.
- **Tool receipts humanizados.** Los receipts de las herramientas delegadas
  pasan de volcados técnicos a mensajes concisos y accionables: quién, qué,
  resultado y una línea de detalle cuando el resultado lo merece. El modelo
  recibe la misma información estructurada; lo que cambia es lo que se impone
  en pantalla al usuario. Cobertura nueva en `tests/tool-receipts.test.ts`.
- **Selector explícito de cambio activo en el router.** El router SDD muestra
  y permite cambiar el cambio activo directamente, sin pasar por el panel de
  estado. La selección ambigua —varios cambios con el mismo nombre— se resuelve
  interactivamente en el CLI y con un error claro si se invoca sin contexto.
  Cobertura en `tests/cli-ambiguous-change.test.ts`.
- **Contrato de estilo como infraestructura.** Se define y se valida
  programmatically qué puede y qué no puede emitirse como bloque de estilo en
  el deliverable SDD: lint de estilo (`style-lint.ts`), contrato
  (`style-contract.ts`) y cobertura. El contrato es leíble por el modelo e
  interpretable por la máquina.
- **Cobertura de estados de pantalla.** Cada estado de la superficie
  (estado del proyecto, configuración, sesiones, sistema, runtime) tiene ahora
  una especificación canónica y una prueba determinista de su contenido en
  español e inglés, sin depender del locale de la máquina.
- **Estilo de Ein en Claude: segunda entrega.** El payload de Claude ya incluye
  el surface runner compilado, y la sincronización copia también el material
  del estilo. Las pruebas de paridad de estilo cubren la instalación desde
  cero (`tests/style-parity-claude.test.ts`).
- **Tool receipts humanos en Pi.** Los receipts de herramientas delegadas
  devuelven ahora un resumen legible en vez de un volcado de depuración.

### Changed

- **El modo `team` se retira.** La integración con Linear y la facturación por
  seats no estaban activas; el modo existía pero ningún flujo lo invocaba.
  Se elimina el módulo `mode.ts` y se limpian las referencias. El modo por
  defecto sigue siendo `single`.
- **Documentación: el roadmap se rescata como contrato vigente.** El documento
  el roadmap pasa a reflejar solo trabajo efectivamente
  construido o en construcción activa; el material obsoleto se archiva o se
  retira. El contexto estratégico histórico queda conservado en Git.

### Internal

- El evaluador de corpus (`evals/build-corpus.ts`) se alinea con el schema
  nuevo y reconstruye el corpus cerrado a partir de él.

## [0.82.0-alpha.1] - 2026-08-24

### Added

- Preparación de publicación alpha determinista del instalador y bootstrap exacto para Pi Ein.
`installer-v*` (binarios del instalador vía GitHub Actions).

## [0.81.1] - 2026-08-22

### Changed

- **El instalador pasa a `0.81.1`.** El paquete y la versión que expone el ejecutable quedan alineados con la release publicada `installer-v0.81.1`.

## [0.81.0] - 2026-08-20

### Fixed

- **El explorador deja de tirar la investigación que ya había hecho bien.**
  Cuando le pides a Ein que estudie un proyecto, manda a un explorador de solo
  lectura que lee ficheros y vuelve con lo que ha encontrado, citando cada
  afirmación con el fichero y las líneas de donde sale. Si una sola de esas
  citas terminaba dos líneas más abajo del final del fichero, el reporte entero
  se tiraba a la basura. Y el error no decía **cuál** cita fallaba, así que el
  segundo intento fallaba igual que el primero y la investigación se cortaba.

  Medido en uso real: dos exploraciones completas de veintitantas llamadas cada
  una, casi dos minutos de trabajo, descartadas con 19 de sus 21 citas
  perfectamente válidas. Las dos citas culpables eran del tipo "este fichero
  entero" con el final redondeado hacia arriba.

  Ahora la comprobación distingue dos cosas que antes trataba igual. Lo que el
  modelo no puede tener mal —que las referencias encajen entre sí— sigue siendo
  motivo de rechazo. Lo que sí escribe a mano —el número de línea— se corrige:
  un final que se pasa del fichero se recorta al final real, y una cita que no
  apunta a ninguna parte se descarta sola, diciendo por qué, sin llevarse por
  delante el resto del reporte. Solo se rechaza todo si no queda ninguna
  evidencia en pie. Y cuando algo se rechaza, el mensaje dice qué cita, en qué
  fichero, con qué rango y cuántas líneas tiene ese fichero de verdad.

  Las dos exploraciones que antes se perdían enteras ahora llegan completas, con
  un final de rango recortado cada una.

### Changed

- **Varios exploradores a la vez, en una sola llamada.** Hasta ahora solo podía
  correr uno por turno, así que investigar tres ángulos distintos de un proyecto
  costaba tres esperas seguidas. La razón por la que estaba prohibido dejó de
  ser cierta hace tiempo. Ahora salen hasta tres en paralelo, cada uno con su
  ángulo, y si uno vuelve mal los otros dos siguen valiendo: antes eso no
  existía porque no había "los otros dos".

## [0.80.1] - 2026-08-19

### Changed

- **La marca es ahora un televisor.** Un aparato de tubo con una terminal
  dentro, dibujado con caracteres. Aparece en el arranque de Pi, en el splash de
  la aplicación y en el instalador. Viene en cuatro tamaños que **pierden
  piezas** en vez de encogerse —con antena y patas, solo el mueble, compacto, y
  un mínimo donde el bisel desaparece y el mueble es la pantalla—, y el tamaño
  se elige por el ancho real de tu ventana: antes de recortar el dibujo, baja al
  corte siguiente, porque un televisor cortado por la derecha no es un
  televisor.

  El intento anterior dibujaba las letras `EIN` con bloques. Una letra vive en
  una rejilla de cuatro píxeles de alto: sale roma, y el fallo se nota porque
  todo el mundo sabe cómo es una E. Un objeto no tiene ese problema, y de paso
  las letras de dentro del televisor son texto normal.

  La pantalla puede emitir cosas distintas sin que cambie el aparato: la marca
  en reposo, el cambio y la fase en curso, nieve cuando algo está roto, o el
  piloto rojo latiendo cuando Ein está instalado pero parado.

### Fixed

- **El informe del doctor deja de romperse y de repetirse.** Con una etiqueta
  larga, el valor se pegaba a ella y la columna se partía justo en las filas más
  largas. Además, el detalle de cada chequeo que pasaba repetía su propia
  etiqueta, así que catorce comprobaciones correctas ocupaban catorce líneas
  para no decir nada. Ahora un grupo entero en verde cabe en su recuento y solo
  se despliega lo que **no** está bien: el informe pasa de unas sesenta líneas a
  ocho, sin ocultar nada que importe.

## [0.80.0] - 2026-08-19

Una release de cara: Ein deja de parecer tres productos distintos y pasa a
hablar el mismo idioma en el instalador, en el launcher y en la sesión.

### Changed

- **Se acabaron los recuadros.** El instalador, el launcher y el arranque de Pi
  dibujaban cada uno su propio marco de doble línea, con pestañas invertidas y
  líneas de puntos que llevaban cada etiqueta hasta su valor. Ahora ninguno
  dibuja contornos: la jerarquía la hacen el aire, la sangría y el apagado. Un
  bloque se agrupa con una barra fina a su izquierda, y la fila que tienes
  seleccionada se distingue por una banda de fondo cálida, no por un borde ni
  por un cursor que parpadea.
- **El negro es negro.** El color de fondo era `#0C0011`, que no es negro sino
  un morado muy oscuro. Pasa a `#0B0B0B`. Los ocho tonos de panel que se
  derivaban de aquel morado se han vuelto a calcular sobre la base nueva con una
  regla escrita, no a ojo, así que no queda ni un fondo con tinte violeta.
- **Un solo prefijo.** La misma idea se escribía de tres formas según dónde
  saliera: `/// 000.` en títulos, `■ 002.` en secciones y `// 000.` en las
  respuestas. Ahora es `//` en todas partes. Se comprobó antes de tocarlo que
  ningún código lo lee: 49 sitios lo imprimían, cero lo interpretaban.
- **El logo deja de ser un dibujo.** El bloque `EIN` de 54×10 caracteres
  aparecía en tres sitios, cada uno con su propia animación. Era un segundo
  alfabeto para una marca que en el resto de la interfaz se escribe `ein`. Queda
  el wordmark, con la `i` en amarillo — el mismo gesto de marca, en una fila en
  vez de en quinientas cuarenta celdas. El arranque conserva su momento: el
  panel de estado sigue entrando en cascada, que además de verse bien te dice
  algo.
- **El instalador es Ein por dentro y por fuera.** Usaba `@clack/prompts`, que
  traía su propio canalón `│ ◆` con sus colores: después de un arranque cuidado,
  volcaba líneas de log de desarrollador en un estilo ajeno. Tanto lo que cuenta
  como lo que pregunta —menús incluidos— se han reescrito en la gramática de
  Ein.

### Added

- **El TODO ya no se queda mudo.** Al marcar la última tarea, el widget del
  cambio se quedaba enseñando `7/7` y callado, aunque todavía faltaran verificar
  y cerrar. Ahora pinta el carril completo del cambio y, cuando las tareas se
  acaban, pasa a enseñar las fases que quedan y qué hace cada una. La
  verificación es la única fase que puede salir como *desconocida*: un informe
  anterior al último cambio de código no cuenta como aprobado.
- **El chat deja de llenarse de volcados.** Las dos herramientas que más se
  llaman escupían veinte líneas cada vez. Ahora dejan un recibo de una línea, y
  el detalle completo sigue estando a un toque. El modelo recibe exactamente la
  misma información que antes: lo que cambia es lo que se te impone en pantalla.
- **Claude recupera la voz de Ein.** El adaptador remitía al documento que define
  el formato de respuesta, pero ese documento nunca se copiaba al home aislado de
  Claude: le pedía seguir un contrato que no podía leer. Ahora viaja con el resto
  del material.

### Fixed

- **La instalación ya no te manda a comandos equivocados.** El script de arranque
  te decía que ejecutaras `ein`, que en ese punto todavía no existe — el binario
  recién instalado es `ein-install`. Y al terminar te mandaba a `pi` para usar el
  agente, cuando `pi` a secas es Pi sin Ein: el cerebro solo se carga a través de
  su lanzador.
- **Los colores dejan de volver al azul.** El tema de Ein se desplegaba
  correctamente pero nunca llegaba a seleccionarse, porque el ajuste que lo elige
  se conservaba como preferencia del usuario y cada actualización reimponía el
  tema anterior.
- **El carril corto ya no se bloquea a sí mismo.** Un cambio en modo `micro` con
  su alcance y su diseño escritos se leía como si le faltaran las dos fases que
  ese modo existe precisamente para saltarse, y quedaba atascado. El hueco se
  mide ahora contra las fases del carril, no contra las siete siempre.
- **Publicar una release ya no puede empaquetar código viejo.** Si el tag no
  apunta a la punta de `main`, la publicación se aborta en vez de subir binarios
  construidos desde un commit que `main` ya dejó atrás.

## [0.73.1] - 2026-08-19

### Fixed

- **El auditor automático dejó de girar en el vacío**: al revisar un cambio, Ein
  lanzaba su auditor (Cleaner) y esperaba su informe por el mismo canal por el
  que lo había llamado. Pero los subagentes arrancan en segundo plano, así que
  el informe volvía por otro sitio y se perdía. El auditor terminaba
  correctamente una y otra vez, el flujo no se enteraba, y verificar el cambio
  quedaba fuera de alcance. Ahora esas delegaciones corren en primer plano y su
  resultado se reconoce por su forma, no rebuscando texto.
- **Reintentar dejó de ser gratis y silencioso**: el registro de la delegación
  se destruía al lanzarla, antes de que existiera ningún informe, así que se
  podía repetir en bucle sin que nada protestara. Ahora sobrevive hasta que hay
  resultado, y un reintento sobre algo en marcha lo dice.
- **Desactivar el auditor ya libera el trabajo**: el reparto de participantes se
  congelaba al abrirse, de modo que apagar el Cleaner a mitad no servía de nada
  y no había salida. Ahora la identidad de esa revisión depende de QUÉ se
  audita, no de QUIÉN, y el reparto se recalcula al leer conservando siempre la
  evidencia de quien ya terminó.

### Added

- **Una regla escrita donde se lee por obligación**: los tres fallos anteriores
  tenían la misma raíz — dar por hecho que el trabajo de un subagente vuelve por
  donde salió. Ahora esa regla está enunciada junto al código que la implementa,
  con un inventario de quién depende de qué, clasificado por lo que pasa cuando
  falla. Un test se pone en rojo si alguien añade un consumidor sin declararlo:
  se comprobó insertando uno de mentira.
- **Salida para el cierre de un cambio en Claude**: el agente que redacta el
  resumen final a veces se niega a escribirlo, porque su propia política lo
  confunde con un informe no solicitado. Ya no es un callejón sin salida:
  `cc-ein-sdd summary <cambio>` lo persiste desde fuera, y Ein lo sugiere solo
  cuando toca.

### Known issues

- Que el modelo use esa salida no se puede garantizar por test. Lo garantizado
  es que negarse a escribir ya no bloquea el cierre.
- El detector de la regla solo cubre un punto de entrada; un consumidor cableado
  por otra vía se le escapa. Está declarado en el propio módulo, no escondido.

## [0.73.0] - 2026-08-18

### Fixed

- **`/ein:sdd-next` dejó de ser un callejón sin salida**: imprimía la ruta del
  cambio —"la fase que toca es verify"— y ahí se acababa todo. Ese texto es
  para la persona, no para el agente que ejecuta fases, así que la instrucción
  no iba dirigida a nadie y el comando parecía no hacer nada. Ahora, además de
  enseñarte la ruta, se la entrega al orquestador para que la recorra. Quien
  decide la ruta sigue siendo la misma herramienta determinista de antes.
- **El bloqueo de participantes viaja en esa entrega**: cuando la fase que toca
  es `verify` y el Cleaner todavía no ha corrido, el aviso va incluido. Antes se
  descubría chocándose con la puerta, y ese choque costaba una delegación.
- **El explorador ya no se escapa a segundo plano**: `ein-scout` declara ahora
  en su propia definición que corre en primer plano. Hasta ahora eso solo se
  forzaba sobre la marcha, y en una ejecución real tres exploradores salieron a
  segundo plano, gastaron su presupuesto y sus tres informes se tiraron.
- **Un informe fuera de contrato ya no abre la puerta al siguiente**: al
  descartarse liberaba el turno al instante, y por eso salieron tres seguidos.
  La regla de que dos fallos seguidos son una avería de infraestructura, y no
  mala suerte, estaba escrita en el prompt y ahora la aplica el código.
- **El mensaje de ese fallo dice lo que se vio, no lo que se supone**: antes
  afirmaba una causa que nadie había comprobado y mandaba a corregir lo que
  quizá no estaba roto.

### Changed

- **`--auto` se retira de `/ein:sdd-next`**: se reconocía y no hacía nada. Con
  la entrega al orquestador, el comando normal ya ejecuta.
- **El contrato de versión del release deja de pedir mantenimiento**: comprobaba
  la versión contra un literal escrito a mano, había que editarlo en cada
  release y se había desincronizado solo. Ahora comprueba que los tres punteros
  coinciden entre sí y tienen forma publicable, que es lo que de verdad importa.

### Known issues

- No está probado por qué aquellos tres exploradores acabaron en segundo plano
  pese a pedirse en primer plano. Lo que sí está verificado es que Ein hace bien
  su parte, y los arreglos de esta versión cortan el gasto y dejan evidencia
  utilizable si vuelve a pasar, en lugar de un diagnóstico supuesto.

## [0.72.0] - 2026-08-18

### Fixed

- **El arnés dejó de bloquearse a sí mismo**: antes de pasarle un cambio al
  Cleaner, Ein hacía una foto del proyecto y se la daba como salvoconducto
  —"audita esto, y aborta si algo cambió"—, pero para preparar ese encargo
  guardaba un fichero de estado dentro del propio proyecto fotografiado. La foto
  nacía caducada, el Cleaner respondía `source state is stale` en bucle y
  verificar el cambio quedaba bloqueado sin salida posible. El checkpoint de
  continuidad ya no es visible para git, en el carril SDD y en el adhoc.
- **El fixture que escondía el fallo**: la prueba de participantes escribía a
  mano la línea de `.gitignore` que el producto nunca generaba, así que el bug
  vivía en verde. Ahora la prueba mide el producto.
- **El scout se rechazaba después de ejecutarse**: lanzar varios exploradores a
  la vez fallaba al recoger el resultado, ya pagado. El rechazo ocurre ahora en
  el lanzamiento, y cuesta cero.

### Changed

- **El sello del pasaje mide el cambio, no el árbol entero**: se calcula sobre
  los ficheros declarados —ruta, identidad de inodo y contenido— en vez de sobre
  todo el repositorio. La garantía se conserva entera: si alguien toca uno de
  esos ficheros entre el plan y la admisión, el Cleaner sigue abortando. Lo que
  desaparece es el ruido que invalidaba pasajes sin motivo.
- **Los exploradores paralelos pasan a ser secuenciales**: el prompt del
  orquestador autorizaba hasta tres scouts a la vez y el código los prohibía.
  Mandaba el código; la contradicción se ha retirado del prompt.
- **La lista de ficheros de `apply-progress.md` tiene gramática fija**, donde se
  produce y comprobada por una prueba: el gate que la lee dejaba de funcionar
  cuando el ejecutor la escribía a su manera.

### Known issues

- La verificación sigue degradándose de `fresh` a `stale` cuando se escribe
  cualquier artefacto después de verificar. Queda declarado y medible, no
  resuelto.

## [0.71.0] - 2026-08-18

### Added

- **Codegraph puede arrancar desde Ein**: `on` es ahora el modo por defecto y,
  cuando falta el índice, Ein ofrece crearlo una sola vez por proyecto en vez de
  dejarte ejecutar `codegraph init` a mano. El modo heredado `auto` se conserva
  al leer la configuración existente.
- **La postura de cada cambio queda escrita en disco**: puedes declarar TDD
  `off` o `strict` y el carril del cambio antes de trabajar; Pi y Claude leen la
  misma decisión, sin heredar por accidente la postura de otro cambio o de otro
  runtime.

### Changed

- **Pi y Claude comparten un único cuaderno de Engram** en `.engram-ein`, y usan
  el mismo nombre de proyecto que deriva Engram. La memoria de un cambio ya no
  queda perdida en almacenes separados ni bajo un identificador que las
  herramientas MCP no consultan.


### Added

- **Un panel vivo del cambio, encima del editor**: qué cambio está activo, con
  qué carril, en qué fase y la lista de tareas con su progreso, actualizándose
  solo mientras trabajas. `ctrl+shift+e` lo pliega. Proyecta `tasks.md`: no
  tiene forma de escribir nada, así que no puede convertirse en una segunda
  versión de la verdad. Se descartó adoptar un paquete de terceros porque
  reconstruye su estado del historial de conversación en vez de leer el
  proyecto.
- **Carril declarado para el cambio pequeño**: `micro` se salta `map` y `tasks`
  —las dos fases que leen código— y no se salta nada más; verificar y cerrar
  siguen siendo puertas duras. Lo eliges tú al abrir el cambio, porque antes de
  planificar no existe ninguna señal fiable para adivinarlo. De 44 cambios
  archivados, 42 habían pagado las siete fases.
- **Claude escribe su propio delta de comportamiento** (`cc-ein-sdd delta`).
  Era el único punto donde alternar entre agentes se atascaba: un cambio con
  delta empezado en Claude no podía cerrarse.
- **Claude tiene cabina**: `/ein:status` y `/ein:settings` como comandos de
  sesión, envolviendo el CLI determinista.
- **Techo al prompt del orquestador**, con un test que falla si crece sin que
  algo salga a cambio.

### Changed

- **Claude trabaja con los ajustes de tu proyecto**, no con sus valores de
  fábrica: modo, idioma, persona, TDD y codegraph se leen del proyecto y se
  inyectan al arrancar la sesión. Antes, un trabajo con TDD estricto en Pi
  continuaba sin TDD en Claude sin que nadie se enterase.
- **Los bloqueos dicen cómo salir de ellos**: cada estado que impide cerrar un
  cambio trae ahora la acción concreta que lo desbloquea, nombrando el comando
  del runtime en el que estás.
- **`rules:` de `openspec/config.yaml` dejó de ser decoración**: se escribía y
  no la leía nadie. Ahora relaja avisos cuando el proyecto lo declara, y solo
  puede relajar: nunca añade comprobaciones.
- **Cleaner y Architect se declaran, no se ejecutan, en Claude**: son de Pi, y
  la participación automática se queda apagada allí por diseño. Antes ni se
  mencionaba, así que el cambio de estándar era silencioso.
- **El runtime de cada fase sale de una tabla** en vez de pedirle al
  coordinador que recuerde qué número pasar a cada una.

### Fixed

- **El presupuesto de duración del Cleaner se reporta en vez de tirar el
  trabajo**: un solo error juntaba «el árbol cambió» —que sí invalida la
  evidencia— con «tardó de más», que no. En un runner cargado, una recogida
  correcta salía como fallo.
- **La paridad entre runtimes deja de citar rutas y herramientas que no
  existen**, con un test que lo impide en adelante.

### Removed

- **Mil líneas de planes ya entregados**: el plan de continuidad Pi↔Claude
  describía trabajo construido, y dos análisis habían cumplido su propia
  condición de retirada. Sus lecciones duraderas subieron al manifiesto.
- **Documentación superada y el spike de OpenTUI detenido**, más 3,6 GB de
  artefactos de compilación en la raíz del repositorio.

## [0.62.1] - 2026-08-17

### Fixed

- **El recuadro del banner ya cierra por abajo**: la animación duraba más que su
  propio tope de tiempo, así que el corte llegaba antes de dibujar el borde
  inferior. El panel arranca ahora solapado con el final del logo y el margen de
  seguridad pasa de dos décimas a dos segundos y medio.
- **El logo deja de saltar de sitio**: se dibujaba centrado en pantalla mientras
  el panel no existía y se recolocaba al aparecer la caja. Ahora nace
  directamente en su posición final, sin recolocación intermedia.
- **El banner respira**: una fila de aire arriba y otra abajo en lugar de quedar
  pegado al borde.
- **El diagnóstico del instalador ya no se sale del recuadro**: el marco era fijo
  y las rutas y motivos largos se recortaban a mitad de palabra. Ahora se adapta
  al ancho del terminal.

## [0.62.0] - 2026-08-17

### Changed

- **Las tres superficies comparten una sola ventana de 16 bits**: el banner de
  arranque, la aplicación de terminal y el instalador usan ahora el mismo marco
  doble, las mismas pestañas de sección invertidas y las mismas líneas de puntos
  que llevan cada etiqueta hasta su valor. Arranque, uso e instalación se leen
  como el mismo producto.
- **El banner reparte logo y datos en dos columnas**: el logo, su animación y la
  placa de versión a la izquierda; el panel de estado a la derecha. Apilado
  medía 41 filas y se salía por abajo de un terminal de 30; en paralelo son 27.
  La columna más corta se centra en vertical.
- **La aplicación de terminal se lee como un menú**: la fila seleccionada lleva
  un cursor que late, los atajos quedan alineados al final de cada fila y los
  iconos por tipo de fila se conservan. Los atajos de teclado no cambian.
- **El instalador estrena la misma ventana** en el diagnóstico y en el listado
  de dependencias, con marcadores de correcto, aviso y fallo coherentes con el
  resto.

### Fixed

- **El banner ya no se corta por abajo**: el modo completo exige el ancho real
  de la composición en dos columnas en lugar de un mínimo heredado de cuando el
  diseño era vertical.

### Internal

- El marco de cada superficie vive en un módulo puro y probado
  (`lib/banner-panel.ts`, `surfaces/terminal-chrome.ts`, `installer/tui/frame.ts`).
  Esas pruebas detectaron dos descuadres de una columna y dos casos de
  desbordamiento antes de publicarse.
- El instalador duplica la gramática a propósito, porque se ejecuta antes de que
  exista el template; un test compara las tres copias para que no diverjan.

## [0.61.0] - 2026-08-16

### Changed

- **El banner de arranque estrena ventana de estado con estética de 16 bits**:
  marco doble, pestañas de sección invertidas y líneas de puntos que llevan
  cada etiqueta hasta su valor, con el blanco y el amarillo como colores
  dominantes. El marco superior se dibuja de izquierda a derecha y las filas
  caen en cascada mientras sus puntos corren hasta soltar el dato; el marco
  solo cierra cuando la última ha terminado.
- **Toda la información del arranque comparte por fin una sola rejilla**: las
  filas de Git (`HEAD`, `LOCAL`, `UPSTREAM`), las características de la sesión,
  la ruta del proyecto y las sesiones recientes se alinean en la misma columna.
  Antes Git se pintaba aparte, con su propio ancho de etiqueta, y nunca cuadraba
  con el resto.
- **Cleaner y Architect se muestran como fichas encendidas o en hueco** en lugar
  de ocupar dos celdas más de una rejilla uniforme: saber que existen y están
  desactivados es información.

### Internal

- La geometría y la animación del panel viven en un módulo puro
  (`lib/banner-panel.ts`): entra información y un instante de la animación,
  salen celdas. Se puede previsualizar y probar sin abrir un terminal, y esa
  prueba detectó un descuadre de una columna en las filas sin sufijo.

## [0.60.1] - 2026-08-16

### Changed

- **El banner de arranque de Pi se lee de un vistazo**: la placa de
  características pasa de una rejilla de catorce celdas —todas con el mismo
  marcador amarillo y con abreviaturas crípticas— a cuatro grupos por tipo
  (qué se cargó, cómo está la sesión, qué está activo, dónde). Lo desactivado
  deja de ocupar sitio y el amarillo vuelve a ser acento en vez de fondo. Las
  filas de Git y las sesiones recientes comparten ese lenguaje y se alinean en
  la misma columna.

### Fixed

- **El panel de terminal conserva sus iconos por tipo de fila**: el cambio de
  marca de 0.60.0 los había sustituido por un marcador uniforme y con eso se
  perdía la distinción entre Pi, Claude, estado, configuración y sistema.
- **Auditar con el Cleaner dentro de CI vuelve a ser posible**: el lector de
  resultados JUnit rechazaba el bloque `<properties>` que Bun emite cuando
  detecta GitHub Actions, así que cualquier ejecución dentro de un runner
  moría con «Unsupported XML element».
- **La suite deja de heredar el supervisor de continuidad de la sesión que la
  lanza**: `EIN_CONTINUITY_ENDPOINT` y su token bajaban a los procesos hijo de
  las pruebas, y un proceso «destino» que veía un socket ajeno se comportaba
  como «origen». Aislado en el fixture; el runtime ya limpiaba esas variables.

### Internal

- La publicación de releases instala las dependencias de la raíz y todas las
  variantes nativas por plataforma: el binario de la aplicación de terminal se
  compila desde las fuentes de la raíz y los cuatro objetivos se generan desde
  una sola máquina.
- La integración continua empaqueta el template compilando antes la aplicación
  para la plataforma anfitriona.

## [0.60.0] - 2026-08-16

### Added

- **Cleaner y Architect participan de forma independiente**: colectores
  deterministas de duplicación, complejidad, cobertura y entorno, más una
  auditoría de arquitectura de solo lectura, cada uno con su propia entrada al
  flujo sin secuestrar la cadena SDD.
- **Traspaso de trabajo entre Pi y Claude**: el checkpoint de continuidad
  transporta el progreso SDD real —tareas cerradas en `tasks.md`, la primera
  pendiente como siguiente acción y los bloqueos del router como decisiones sin
  resolver— en vez de literales genéricos.
- **Plano de control de instalación y desinstalación** en el instalador, con
  menú de runtime y ciclo de vida propio.
- **Aplicación de terminal sobre OpenTUI**, empaquetada por plataforma.
- **Splash de marca al arrancar la aplicación de terminal**: el mismo logo y la
  misma animación del instalador, con la versión instalada en el subtítulo.
  Respeta `--no-intro`, suena una sola vez por proceso y cae a estático en
  terminales sin color.

### Changed

- **La aplicación de terminal y el instalador comparten marca**: la app pasa de
  un tema azul propio a la paleta de `brand.json` (carbón, concreto,
  estructura, amarillo industrial), con placa `EIN`, reglas estructurales y
  valores alineados. Pi y Claude Code dejan de distinguirse por color y pasan a
  marcador (`■` accionable, `□` inerte), que además funciona en terminales sin
  color. El `doctor` del instalador adopta el mismo vocabulario en lugar de sus
  verdes y rojos propios.
- **El arnés SDD deja de bloquear por el formato de sus documentos**: los
  códigos que detienen una fase pasan de 18 a 5, y solo sobreviven los que
  alimentan a otra pieza (casillas de `tasks.md`, comando de verificación y las
  líneas de estado que lee el router). Un defecto de artefacto se corrige
  editando el artefacto, nunca abriendo una tarea y delegando una fase.
- **El contrato de aceptación es explícito o no existe**: se retira la
  inferencia a partir de la redacción de la tarea, que rechazaba trabajo
  terminado por no emitir un informe con la forma esperada. Las puertas que
  examinan el trabajo —ejecución real de la suite en `sdd-verify`, validación
  de artefacto y guarda de cierre— quedan intactas.
- **La entrega dispone de cinco minutos en vez de dos**: el presupuesto corto
  interrumpía entregas a mitad, entre el `push` y la apertura del PR.

### Fixed

- **«Continuar en Pi» arrancaba Pi sin Ein**: la aplicación de terminal lanzaba
  el runtime vanilla en lugar del workbench.
- **Un diario de actualización completado bloqueaba el instalador para
  siempre**, e impedía además la siguiente instalación.
- **`models-panel` salía del directorio que Pi autocarga**, donde tumbaba el
  arranque.

### Internal

- Una sola geometría del logo en el árbol `ein-pi`, antes duplicada en tres
  ficheros; el instalador conserva la suya a propósito, porque se ejecuta antes
  de que exista el template desplegado. Tests fijan que no vuelva a separarse y
  que ambas paletas se deriven de `brand.json`.
- Se retira la degradación por telemetría de los guardarraíles, muerta desde
  que se borró el ledger de coste.
- Roadmap, guías y política de memoria actualizados.

## [0.51.0] - 2026-08-11

### Changed

- **La aplicación de terminal pasa de visor a panel accionable**: el dashboard
  abre cada vista, inicia Pi o Claude Code y mantiene atajos directos además de
  la navegación por teclado.
- **Las sesiones de Pi y Claude Code comparten una sola vista**: se pueden
  iniciar o reanudar desde la misma lista, sin perder la identidad del runtime.
- **La configuración refleja el estado persistido en disco**: cada cambio pasa
  por el dueño del ajuste y la vista relee el valor escrito en vez de asumirlo.
- **El traspaso al runtime es seguro**: antes de lanzar o reanudar una sesión la
  app restaura el terminal, retira listeners y propaga el código de salida.
- **El render cubre terminales reales y automatización**: el modo estático no
  toma control del TTY, `NO_COLOR` elimina las secuencias ANSI y el layout se
  repinta al cambiar el tamaño de la terminal.

### Internal

- Las pruebas de la aplicación validan de forma determinista la copia exacta
  en español o inglés sin depender del locale de la máquina.

## [0.50.2] - 2026-08-11

### Fixed

- **El template de Pi ya despliega `app.ts` y `surfaces/`**: la lista blanca del
  empaquetador no los incluía, así que `~/.pi-ein/agent/surfaces` y
  `~/.pi-ein/agent/app.ts` nunca llegaban a la máquina. Consecuencias:
  el instalador no podía compilar la app —informaba «no desplegada»— y
  **`pi-ein workbench` y `pi-ein cleaner` nunca funcionaron desde una
  instalación empaquetada**, solo desde un checkout del repositorio.

  Es el mismo fallo que 0.50.1 corrigió en el payload de Claude, en el otro
  empaquetado. Ambos vienen del bloque M, que añadió las superficies sin
  añadirlas a ningún manifiesto.

- **El motivo del fallo llega al mensaje del instalador**: `promoteCommandNames`
  devolvía `app-source-missing` y el mensaje lo descartaba, dejando solo «no
  desplegada». Diagnosticar la primera instalación real costó una vuelta entera
  por eso.

### Internal

- `tests/template-agent-inventory.test.ts`: deriva del propio código —el
  launcher de Pi y el instalador— qué rutas deben viajar en el template, y falla
  si la lista blanca no las cubre. Verificado que detecta el fallo original.

## [0.50.1] - 2026-08-11

### Fixed

- **El payload de Claude ya incluye los binarios que compila** (PR pendiente):
  `cc-ein/sync.ts` compila el surface runner y la app de terminal desde
  `ein-pi/agent/`, pero el inventario del payload solo empaquetaba `cc-ein/` y
  `ein-pi/core/`. En una instalación empaquetada esos ficheros no existían y la
  compilación fallaba en la máquina del usuario.

  El surface runner arrastraba este fallo **desde que se publicó el bloque M**:
  `cc-ein workbench` y `cc-ein cleaner` nunca funcionaron desde una instalación
  empaquetada, solo desde un checkout del repositorio. La app de terminal era un
  segundo caso del mismo fallo, no uno nuevo.

  Ahora el payload incluye el cierre de imports de cada punto de entrada que
  `sync.ts` compila, y esas rutas están entre las requeridas: un paquete
  incompleto falla al empaquetar, no en tu máquina.

- **Las compilaciones dejan de tragarse el error** (PR pendiente): corrían con
  `stdio: "ignore"`, así que un simple "fichero no encontrado" llegaba como
  `Command failed` sin causa. Las tres compilaciones de `sync.ts` comparten
  ahora una sola forma que conserva `stdout` y `stderr` del proceso hijo.

## [0.50.0] - 2026-08-11

Ein deja de ser solo un harness invocado desde el runtime y pasa a tener
aplicación propia. `ein` abre una aplicación de terminal desde la que se ve y se
controla el proyecto; el instalador se muda a `ein-install`.

### Added

- **Aplicación de terminal (`ein`)** (PRs #136, #137, #138, #139, #140): cinco
  vistas que rotan con `tab` — estado del proyecto leído de OpenSpec,
  configuración editable, sesiones recientes, sistema, y selección de runtime.
  Atajos estilo LazyVim (`j`/`k`, `g`/`G`, `f`, `q`) con flechas como
  alternativa, y banner animado 8-bit al arrancar.

  Cada fila declara su fuente entre corchetes, y un dato desconocido se
  distingue de uno vacío: `unknown` no es `—`. La aplicación presenta estado; no
  lo inventa. Sin terminal interactiva pinta una vez, lo declara y sale con 0.

- **Vista de configuración** (PR #137): modo de trabajo, TDD estricto, Hypa,
  CodeGraph y persona, editables con `enter`. Escribe a través del dueño de cada
  ajuste; `EIN.md` sigue siendo contexto de proyecto, no configuración.

- **Resumen de sesiones** (PR #138): cada sesión reciente se identifica por lo
  último que pidió el usuario. Solo se lee texto del usuario — la salida de
  herramientas y el razonamiento del modelo nunca se muestran. La lectura barre
  hacia atrás por trozos con tope, en vez de leer transcripts de megabytes.

- **Vista de sistema** (PR #139): estado de actualización de Ein, binario de Pi,
  paquetes y Claude Code, más el diagnóstico. Imprime el comando exacto; no lo
  ejecuta.

- **Vista de runtime** (PR #140): elegir Pi o Claude Code, ver sus sesiones y
  lanzar. Absorbe lo que hacía `pi-ein workbench`, reutilizando los adaptadores
  y el plan de lanzamiento existentes. Un proveedor sin soporte de reanudación
  lo declara en vez de fallar al pulsar.

- **Aviso de actualizaciones por componente en el launcher** (PRs #129, #130,
  #131, bloque N): Ein, binario de Pi, paquetes y Claude Code, cada uno con su
  comando exacto. Las comprobaciones corren en paralelo con la selección de
  proyecto: nada espera por red. La ejecución sigue siendo del instalador.

- **Puerta de tipos para `ein-pi`, `cc-ein` y `tests`** (PRs #133, #135):
  `tsconfig.json` en la raíz, script `typecheck` y paso en CI. 127 errores de
  tipo arreglados sin añadir un solo `any`.

### Changed

- **`ein` abre la aplicación; el instalador es `ein-install`** (PR #141). Un
  solo `ein update` migra: el instalador se preserva bajo su nombre nuevo antes
  de que la aplicación tome `ein`. Los verbos viejos siguen reconocidos y
  redirigen con código de salida 2, para que un script que dependiera de ellos
  falle ruidosamente en vez de aparentar éxito.

- **El SDK de Pi se declara como dependencia del repo** (PR #132). Antes
  resolvía desde la caché global de Bun: funcionaba por suerte, no por diseño.

### Fixed

- **El aviso de actualización del arranque ya no se calla del todo** (PR #128):
  una sola comprobación que no podía completarse tumbaba el veredicto de las
  demás y silenciaba actualizaciones reales. Se disparaba con
  `PI_SKIP_VERSION_CHECK` y en toda instalación de Ein en desarrollo. El
  fail-closed del asesor era correcto; el consumidor sobre-confiaba en él.

- **La aplicación resuelve el home aislado por su cuenta** (PR #139): ejecutada
  sin launcher delante no tenía `EIN_PI_AGENT_HOME` y habría leído
  `~/.pi/agent`, que es Pi vanilla. Nunca lo asume: no leer nada es mejor que
  leer las sesiones de otro.

- **Un fallo de escritura de configuración ya no tumba la aplicación** (PR
  #137): un checkout de solo lectura se reporta como rechazo en vez de propagar
  la excepción.

### Internal

- `models-panel` sale de `lib/` al borde (PR #134): eran 663 líneas de TUI
  interactivo en el módulo determinista, y el único import de valor del SDK que
  quedaba en `lib/`.

## [0.45.1] - 2026-08-10

### Fixed

- **La limpieza `EXIT` del bootstrap ya no pierde la ruta temporal**
  (`9be2952`, PR #126): el trap captura la ruta concreta creada por `mktemp`
  antes de que la variable local salga de alcance, elimina ese directorio al
  terminar y deja de emitir `tmp: unbound variable`.
- **Los fallos de sincronización de Claude conservan el diagnóstico completo**
  (`9be2952`, PR #126): el instalador mantiene el `stdout` detallado y añade
  después el resumen de `stderr`; solo recurre al código de salida cuando el
  proceso hijo no produjo ninguna salida. La cobertura de regresión reproduce
  ambos fallos y fija el orden del diagnóstico.

## [0.45.0] - 2026-08-10

### Added

- **Superficies invocables de cleaner y workbench en Pi y Claude** (`e45a13e`,
  PR #124): los dos runtimes exponen entradas equivalentes sobre un runner
  compartido que falla cerrado, y la cobertura verifica también el seam tal
  como queda instalado.

### Changed

- **CI prepara Fish explícitamente** (`9588abb`, `0b444d3`, PR #124): los jobs
  de Ubuntu y macOS instalan sus prerrequisitos antes de ejecutar las
  comprobaciones que dependen de Fish.

## [0.44.1] - 2026-08-10

### Fixed

- **`ein update` daba por aplicado un `brew upgrade` que Homebrew había
  rechazado** (`0f13186`): `refreshEngram` descartaba el exit code de brew y
  devolvía éxito fijo, asumiendo que un fallo solo podía significar "ya al
  día". El tap de engram publica un cask y una fórmula con el mismo nombre, así
  que `brew upgrade engram` resolvía al cask —que Homebrew se niega a cargar
  desde un tap no confiado— y salía con error mientras el updater informaba
  "brew upgrade aplicado" con el binario congelado en la versión anterior.
  Ahora el resultado se comprueba siempre y se usa la fórmula cualificada
  (`--formula gentleman-programming/tap/engram`), que apunta a lo que está
  instalado y no dispara el gate de casks. Ante cualquier otro rechazo se
  reporta el comando exacto de `brew trust`: Ein no confía taps por su cuenta,
  porque saltarse ese gate en silencio es justo lo que Homebrew lo añadió para
  impedir. `installEngramMac` recibe el mismo trato; ese camino estaba igual de
  roto para instalaciones nuevas en macOS. Las herramientas que no se
  actualizan se listan como aviso, no como línea normal.
- **La terminal se partía durante el update** (`0f13186`): brew, npm y curl
  heredaban stdio mientras un spinner de clack repintaba la misma línea, y su
  salida se entrelazaba con ella. Ningún proceso hereda ya stdio bajo spinner:
  se captura la salida, se rescata la última línea para el mensaje de error y
  un timeout de 5 minutos cubre al proceso que, ya sin voz, podría atascarse
  sin avisar.

### Changed

- **Mensajes del instalador acentuados** (`4bbb6dc`): los textos del wizard, el
  updater y el doctor mezclaban "Actualizacion" con "última release". Pasada de
  tildes sobre los literales visibles al usuario.

## [0.44.0] - 2026-08-10

### Added

- **Perfil explícito `scope-only-out-of-flow`** (`a5f8b26`, PR #123): añade
  evidencia JSON canónica con hash y bytes del resumen, ligada al `HEAD` y al
  árbol de Git, y conserva el motivo de auditoría. La elegibilidad es
  estructural y exclusiva de scope; las entradas incompletas o incoherentes se
  deniegan fail-closed. No equivale al cierre normal ni al `force` legacy, y
  ofrece superficies de cierre equivalentes en Pi y Claude.

### Changed

- **Reconciliación de `docs-site-shell`** (`f710c23`, PR #123): se ajustó al
  estado real sin fabricar fases retrospectivas, se separaron sus brechas
  efectivas y se abrió el bloque M solo como scope; `surface-wiring` no se
  declara implementado.

## [0.43.1] - 2026-08-10

### Fixed

- **El aviso de arranque afirmaba una configuración que nunca había leído**
  (`5c06891`): el arranque evalúa el asesor solo con evidencia de
  actualización, sin clave `configuration`, así que la faceta caía en la rama
  de evidencia ausente y publicaba `Configuration: status=unavailable` en cada
  sesión aislada. Además `recommendation()` no cubría ni `update-available` sin
  handoff —la rama de observaciones nunca lo produce— ni una configuración no
  disponible, y caía al `none/read-success` final: declaraba que todo estaba
  correcto con una actualización pendiente. El aviso pasa a renderizar solo
  evidencia de actualización y vuelve a nombrar el comando (`ein update`,
  `pi-ein update --all`), derivándolo del handoff o de la procedencia de las
  observaciones. Calla salvo que haya una actualización fresca y aplicable: el
  sondeo es best-effort y fallar abierto no debe generar un aviso. Las
  semánticas completas siguen disponibles en la superficie del workbench, que
  sí aporta evidencia de configuración.

## [0.43.0] - 2026-08-09

### Fixed

- **Forma de la delegación bajo `pi-subagents` ≥ 0.44** (`45c8c4e`): el runtime
  movió la ejecución a `workflowScript` y los seis inspectores de delegación de
  Ein quedaron ciegos a la vez — el gate de entrega dejó de emitir el grant
  (todo `git push` delegado bloqueado y ninguna confirmación previa), el gate de
  TDD dejó de preguntar, las fases de planificación perdieron su
  `acceptance: none`, el backstop de turnos del apply desapareció, la
  reconciliación de fase dejó de rescatar artefactos entregados y el scout perdió
  su contrato acotado. La forma se centraliza en `lib/delegation-shape.ts`, que
  lee el script y las formas legacy, y un canario avisa una vez por sesión
  cuando una delegación no produce ni un child en vez de dejar los gates en
  no-op silencioso.
- **Grants de entrega sin interfaz** (`439257c`): la política (`off`, o `auto`
  con petición explícita del usuario) se evalúa antes de ceder al guard de bash,
  así que una sesión sin UI vuelve a emitir el grant que el subagente headless
  necesita.

### Added

- **Cleaner: auditoría de solo lectura** (`9efa2a1`): hallazgos deterministas y
  trazables sobre el estado proyectado, con informe congelado (`mode:
  read-only`, `appliedChanges: 0`) y sin capacidad de mutación.
- **Cleaner: mutaciones acotadas** (`0d0de9f`): convierte un único hallazgo ya
  revisado en una sustitución exacta de un solo fichero — una escritura, sin
  reintentos ni rollback, con verificación fresca ligada al estado resultante.
  Detectar una oportunidad sigue sin conceder permiso para escribir.
- **Ledger de áreas revisadas** (`09af955`): evidencia normalizada de qué áreas
  se revisaron, con outcome y frescura preservados.
- **Asesor compartido de configuración y actualizaciones** (`327ab9a`): lectura
  común para Pi y `cc-ein`.
- **Sitio de documentación** (`fd69b0a`).

## [0.42.0] - 2026-08-05

### Fixed

- **Proveniencia de reintentos de scope** (`ad6190f`): los reintentos conservan
  los deltas persistidos válidos y evitan que una proveniencia OpenSpec no
  resuelta o conflictiva avance a `map`, disponible tanto para Pi como para
  `cc-ein` a través del core compartido.

## [0.41.0] - 2026-08-05

Preparación de metadata para el selector de runtimes y la compatibilidad de
versionado del instalador en Linux y macOS.

### Added

- **Selector no interactivo de runtime**: `ein install --yes --runtime
  pi|claude|both`, con Pi como valor predeterminado, rechazo fail-closed de
  formas inválidas y menú interactivo conservado como autoridad.
- **E2E real en contenedores aislados**: escenarios independientes para rechazo,
  Pi, Claude y Both; los casos válidos se repiten y Both verifica el orden Pi
  antes de Claude y la convergencia de artefactos.

### Fixed

- **Identidad del banner y del binario**: `--version` conserva una línea de
  identidad del instalador y una línea independiente `template-version`, y el
  banner usa la versión del binario sin alterar la etiqueta de recuperación.
- **Verificación de checksums**: los assets no avanzan cuando el checksum es
  ausente, duplicado, malformado o corresponde a otro destino.
- **Escrituras seguras de secretos**: las escrituras atómicas rechazan destinos
  simbólicos o no regulares y limpian los temporales ante errores.

### Changed

- **Versión en macOS**: los binarios Darwin preparados comparten la fuente de
  versión del instalador y el contrato de salida de Linux, manteniendo la
  comprobación independiente de `template-version`.


Release unificada y sustancial para los dos runtimes soportados: Pi + Claude.

### Added

- **Superficie multi-runtime Pi + Claude**: el instalador prepara el runtime
  elegido, mantiene aislados sus hogares vanilla y despliega sus launchers y
  migraciones sin mezclar artefactos.
- **Payload Claude determinista**: el contenido de `cc-ein` se materializa y
  valida con rutas requeridas antes de sincronizarlo.

### Fixed

- **Hotfix de materialización BunFS**: los binarios compilados ya copian el
  payload Claude embebido a un fichero real antes de entregarlo a `tar`, por lo
  que `cc-ein` vuelve a instalarse correctamente fuera del directorio del repo.

### Changed

- **Compiled smoke del payload**: la release ejecuta un smoke compilado de BunFS
  antes de generar checksums o publicar assets.
- **Versionado unificado**: Pi, Claude, el instalador, el workflow y la
  documentación comparten `0.40.0`; la release se publica como
  `installer-v0.40.0`.

## [0.34.0] - 2026-08-04

Release pública `installer-v0.34.0`, con el título de GitHub **EIN v0.4**.

### Added

- **Selección multi-runtime de Pi/Claude**: el instalador detecta y prepara el
  runtime elegido sin mezclar sus rutas ni sus artefactos.
- **Migración y launchers aislados**: las rutas de cada runtime quedan separadas
  y sus migraciones y lanzadores se ejecutan sobre ese contexto.
- **Payload y sync deterministas de Claude**: el contenido empaquetado y su
  sincronización se validan con una forma estable antes de instalar.

### Changed

- **Aviso de actualización corregido**: la notificación de `ein update` refleja
  el destino y el estado reales de la actualización.

### Note

- **Superseded for Claude installs**: la entrada y la release `0.34.0` se
  conservan para historial, pero no debe usarse para instalar Claude: su
  payload necesita el hotfix de materialización BunFS incluido en `0.40.0`.

## [0.33.1] - 2026-08-01

Mini fix: primera pieza del aligerado del orchestrator (norte de Ockham).

### Changed

- **Retirado el protocolo legacy de intercom del orchestrator** (PR #85). El
  bridge de intercom va OFF por config (`extensions/subagent/config.json` →
  `intercomBridge.mode: "off"`, fijado por test), así que los ~3 párrafos de
  protocolo (*Intercom asks* reply+`wait`; *Detached-child liveness* stat del
  `session.jsonl` mtime) gobernaban un estado imposible: con el bridge apagado,
  ningún ejecutor se desacopla mid-run pidiendo al supervisor. Colapsados a un
  párrafo que conserva los guards vivos (bridge off → `status: blocked`, un
  detach es anomalía a reportar, no `wait`/`sleep`-poll, nunca rehacer una fase
  por un ask tardío). ~1950 chars / ~487 tokens menos por sesión del parent (el
  orchestrator se carga siempre), con cero pérdida de calidad de entrega. Test
  P2 de `sdd-phase-runtime-contract` actualizado en lockstep.

### Note

- La investigación a fondo del aligerado del orchestrator concluyó que **el
  resto no es grasa**: ~15 tests anti-drift fijan su contenido como invariantes
  ganadas por incidentes. El intercom (muerto por config) era el único peso
  muerto real; cortar más sería borrar guards de calidad.

## [0.33.0] - 2026-08-01

Batch de simplificación del sistema de skills + Context7 (norte de Ockham:
menos ceremonia, más núcleo). El valor real —el selector que inyecta los
`SKILL.md` relevantes en cada subagente— iba envuelto en maquinaria patrón-recibo.

### Changed

- **Sistema de skills 1467 → 847 líneas** (PR #83). En `ein-skill-maintenance`
  (597 → 269) fuera el package-manager (lock, hash, reconcile, `skills-lock.json`):
  queda `git clone --sparse` + copiar (clonar trae lo último, copiar sobrescribe).
  En `ein-skill-registry` (870 → 578) fuera la caché del registro, el árbol
  `.pi/ein/atl` + `skill-registry.md`, el tool `ein_skill_feedback` y el comando
  `skill-registry:refresh`. La resolución de skills es automática (el parent ya no
  lee ni casa un registro a mano).
- **Selector arreglado: puntúa por el trigger declarado, no por escanear el
  fichero** (PR #83). `inferTriggers` escaneaba todo el `SKILL.md` contra una lista
  fija de keywords, así que `architecture` acababa etiquetada `nuxt, vue, react` (su
  trigger real es refactor/architecture/design) y las skills verbosas ganaban en
  cualquier tarea. Ahora `extractTriggers` lee la cláusula declarada (`Trigger:` /
  `Use when`) de la descripción y el match es por palabra completa. Cobertura nueva
  (`tests/skill-resolution.test.ts`): el selector no tenía ningún test.
- **Context7 cubre el long tail con una regla always-on** (PR #83). El enrutado
  era un mapa hardcodeado de 11 keywords (drizzle, zod, postgres…) que solo conocía
  tecnologías comunes que el modelo ya domina, y quedaba mudo justo para la librería
  rara o el atasco. Fuera el mapa + la detección por-tarea (~55 líneas); dentro una
  regla always-on en `core/AGENTS.md`: cualquier librería sin skill curada —sobre
  todo si no la dominas o te atascas— va a Context7 por el topic concreto
  (`resolve-library-id` → `query-docs`), nunca el manual entero. Se conserva el
  servidor MCP context7 (docs frescas topic-scoped ya las hace `query-docs` nativo).

## [0.32.0] - 2026-07-31

Batch de simplificación siguiendo el norte (menos ceremonia, más núcleo; navaja
de Ockham). Cinco cambios que hacen EIN más simple, más claro y más útil sin
tocar lo que da valor.

### Changed

- **Bootstrap de `config.yaml` adelgazado 799 → ~180 líneas** (`a2b…`, PR #77).
  Era un detector heurístico multi-lenguaje (walker de 20k ficheros, tablas de
  hints, inspectores Node/Go/Rust/Python/Makefile) que adivinaba stack/comandos
  peor que el modelo y dejaba `test_command` vacío en repos con tests. Ahora lee
  la fuente autoritativa —los `scripts` de package.json— más fallbacks
  implícitos (bunfig→`bun test`, tsconfig→`tsc --noEmit`); lo que no sabe lo deja
  vacío para que el `sdd-scope` lo rellene. `context` apunta a EIN.md.
- **models-panel pulido** (PR #78). Fuera el coloreado de modelo por familia
  (regex que se pudría y contradecía la doctrina del panel) → un color de marca;
  paleta honesta (3 colores reales, no 5 alias que mentían); esfuerzo inline
  (`e` cicla en la fila) en vez de un picker de pantalla. Intacto lo que vale:
  tabla agrupada, barras, recomendación por rol, búsqueda.
- **sdd-preflight partido + menos fricción** (PR #79). El cajón de sastre (835
  líneas, 4 trabajos) se parte: `sdd-session-memory.ts` y `sdd-assets.ts` salen a
  sus ficheros. El cuestionario de arranque baja de 5 a 3 preguntas: fuera el
  `chained-PR strategy` (4 modos redundantes con el Review Workload Guard) y la
  pregunta del budget (fijo 400).
- **Lección de acceptance colapsada** (`76618ea`, PR #80). El "acceptance verdict"
  de pi-subagents rechaza en falso las fases de planning; un hook determinista ya
  inyecta `acceptance: none` y lo neutraliza, así que los 5 bullets de prompt que
  lo explicaban se colapsan a un párrafo. El hook (el mecanismo) se conserva;
  solo se resta la prosa que subsume. Conservadas las lecciones de thinking/
  runtime/scoping.

### Added

- **Tool determinista `ein_review_forecast`** (`7fe32af`, PR #81). El Review
  Workload Guard medía el tamaño del PR con un `git diff --shortstat` + 15 globs
  codificado como string de prompt en 3 sitios, ejecutado inline por el parent
  caro, con un test anti-drift. Ahora una tool es dueña única del pathspec: el
  parent la llama (deja de ejecutar git), ein-git confía en el número reenviado,
  y el anti-drift desaparece (no hay 3 copias que desincronizar).

## [0.31.0] - 2026-07-31

Sigue la línea del cambio de rumbo: menos ceremonia, más núcleo. Se retira el
segundo "sistema-recibo", se desenvuelve Engram conservando lo que vale, y se
cierra el hueco de que las herramientas externas envejecían en silencio.

### Removed

- **Ledger de coste / procedencia** (`3ea8e1d`, PR #73). RunReceiptV1 con sha256
  source bindings, `fileIdentity` (dev/ino/mtime), métricas
  reported/estimated/unavailable y aggregates con dedup — todo para atribuir
  tokens/coste por fase. Mismo patrón sobre-ingenierizado que el recibo de
  candidato, y no funcionaba: pedirle a un modelo barato procedencia honesta de
  coste daba `n/a` y problemas de atribución que ensuciaban el status. −783
  líneas netas. Se conserva el budget (self-report barato) y la reconciliación de
  fase.

### Changed

- **Engram desenvuelto: la taxonomía E0/E1/E2 colapsa a una regla** (`c2b9b34`,
  PR #74). El bloque "## Notebook Contract" se repetía en los 7 agentes SDD +
  orchestrator + doctor (~22 líneas de prompt por flujo). La regla que importa
  vive ahora una vez en `AGENTS.md`. La herramienta Engram y todos los guardas
  (secret-scrub, dedup, noise-reject, budgets) quedan intactos.
- **Memoria de Engram a granularidad de sesión, no de fase** (`23e99c4`, PR #74).
  Se hacía una búsqueda Engram + inyección de advisory por fase (map/design/
  apply/verify): coste por fase y superficie de fallo para un modelo barato. Ahora
  solo el parent recibe el snapshot de sesión; recuperar al arrancar, guardar al
  cerrar.

### Added

- **`ein update` auto-actualiza las deps externas presentes** (`70689ef`,
  PR #75). engram, hypa y codegraph son binarios fuera de la transacción de Ein y
  envejecían en silencio. `ein update` los refresca (re-ejecuta el instalador
  oficial = última versión) bajo la misma confirmación que pi, **solo si ya están
  presentes** — respeta el opt-out `--no-hypa`/`--no-codegraph`/`--no-engram`.
  Best-effort: un fallo de red conserva la versión actual.

## [0.30.1] - 2026-07-30

Hotfix de 0.30.0: el `ein-scout` no arrancaba con un modelo barato.

### Fixed

- **El reporte del scout tolera la forma natural de un modelo barato**
  (`4e47482`). La 0.30.0 quitó el `outputSchema` inyectado al lanzar el scout,
  que era lo único que forzaba la forma del JSON. Sin él, un modelo `thinking
  low` emite `uncertainties` como strings (no `{level, statement}`) y
  `references` con un campo `lines` "N-M" (no `startLine`/`endLine`), y el
  validador estricto descartaba el reporte con `missing or invalid uncertainty`
  — el scout parecía no arrancar aunque hacía el trabajo con citas correctas.
  `parseReport` normaliza ahora ambas formas a la canónica; la validación de
  citas contra disco (fichero:línea real y en rango) sigue estricta. El prompt
  del scout especifica las formas exactas con un esqueleto JSON.

## [0.30.0] - 2026-07-30

Cambio de rumbo. EIN se había alejado de su objetivo —simplicidad y ahorro de
tokens con un núcleo pequeño— acumulando maquinaria sobre-ingenierizada. Esta
release quita el aparato más caro y deja el proyecto y sus docs en su estado
real. El salto de 0.25 a 0.30 marca el nuevo capítulo (hacia un gentle-pi propio
más ligero), sin prometer estabilidad todavía.

### Removed

- **Subsistema de recibo de candidato** (`3ea8e1d`, PR #70). Ligaba los bytes
  que pasó `sdd-verify` a un árbol de git y lo revalidaba en cuatro fronteras
  (pre-commit, post-commit, pre-push, pre-PR) más una retirada contra el PR
  mergeado en GitHub. Copiaba el `candidate_tree`/receipt de gentle-pi, pero allí
  el recibo es salida de un review NATIVO real; EIN no lo tiene, así que sellaba
  un `sdd-verify` auto-reportado: garantía aparente sobre la palabra de un agente,
  a cambio de bucles de corrección y fases de más. Fuera 4 libs (~1.686 líneas),
  2 tools (`ein_candidate_receipt`, `ein_candidate_receipt_retire`), el gate del
  hook de entrega y 4 suites de test.
- **Docs de planificación, roadmaps y spikes** (`1f81a7b`, PR #70). `docs/` pasó
  de 21 ficheros a 2. Doctrina nueva: `docs/` guarda solo estado actual; la
  historia de lo planteado vive en git y en `openspec/changes/archive`. Se
  conserva la decisión del workload guard (hoy ADR 0001) y `ein-multiagente-plan.md`
  (semilla del replanteamiento, ahora trackeado).

### Changed

- **Flujo de entrega de `ein-git`** (`3ea8e1d`, PR #70). Eliminada la declaración
  de contenido y las cuatro gates del recibo; la entrega queda protegida por la
  capa determinista barata que sí ahorra tokens: staging cerrado
  (`git-staging.ts`), guardrails y el grant de intención de un solo uso.
- **Spec `sdd-lifecycle`** (`3ea8e1d`, PR #70). De 283 a 73 líneas al retirar 30
  escenarios de recibo; menos superficie que razonar en cada fase.

### Fixed

- **El reporte de scout se valida desde `finalOutput`** (`f4c3be7`). El contrato
  exigía el reporte por el canal `structuredOutput` del runtime, que el modelo
  trata como opcional: 3 de 4 scouts lo emitían como mensaje final (texto) y se
  descartaban con `missing structured report`. Ahora se lee `finalOutput` como
  cualquier subagente y corre la misma validación de citas/schema/paths; un
  launch async devuelve un error accionable en vez del opaco. Se borra el
  `outputSchema` inyectado (código muerto: `parseReport` ya validaba a mano).

## [0.25.0] - 2026-07-30

### Added

- **Preflight de specs canónicos** (`fae19d4`, PR #68). El sync de close mergea
  cada delta dentro de su spec canónico base; un base heredado sin cabeceras
  reventaba con `invalid-format` en la última fase, tras todo el trabajo ya
  hecho. `lintCanonicalBases` valida esos bases desde `lintChange`, así
  `ein_sdd_check` lo saca ya en scope.
- **Serializador y tool de deltas OpenSpec desde datos estructurados**
  (`54410bc`, PR #68). Los deltas se escribían a mano y fallaban el parser
  estricto una y otra vez. `serializeOpenSpecDelta` + `buildOpenSpecDelta`
  generan y validan el delta re-parseando con la gramática del sync; la tool
  `ein_openspec_delta_write` lo escribe o lo rechaza sin dejar rastro.
  `sdd-scope` la usa y nunca teclea el markdown.

### Changed

- **Investigación pre-scope acotada del parent** (`1fa5e37`, PR #68). El parent
  delega la investigación amplia al `ein-scout` de solo lectura con un packet
  acotado y reutiliza la evidencia citada en vez de redescubrirla.

### Fixed

- **El preview cuenta contratos `.md` como producción** (`70b1ef9`, PR #68). El
  clasificador excluía `.md`, así que un cambio que solo tocaba contratos
  mostraba «sin ficheros de producción». Predicado compartido que incluye `.md`
  pero excluye artefactos de proceso SDD y el árbol `openspec/`.
- **La procedencia del ledger deja de figurar como bloqueo** (`08c55fe`, PR #68).
  `change-unresolved` y `legacy-metadata-excluded` (attribution de recibos)
  aparecían bajo «bloqueos» en cada status, ahogando los reales. Ahora salen solo
  en la línea `ledger provenance:`.
- **Staleness de verify por superficie entregada** (`02209a8`, PR #68). Una
  normalización post-verify (cabecera de spec, docs) reescribía `apply-progress.md`
  y forzaba un re-verify completo aunque no cambiara código ni tests. Se compara
  contra el mtime de los ficheros que `tasks.md` declara.
- **El budget avisa al superar lo asignado** (`0eaa440`, PR #68). El «asignado»
  era decoración muda; ahora `formatBudget` marca `⚠ sobre lo asignado (N%)` al
  cruzarlo (advisory, no bloquea el cierre).

## [0.24.4] - 2026-07-30

### Fixed

- **Structured handoff y lifecycle del scout** (`03272bb`, PR #62). El resultado
  estructurado se obtiene desde `details.results[0].structuredOutput`, se
  conservan los diagnósticos de error del runner y se limpia el tracking al
  terminar la sesión.
- **Contrato de extensiones vacías y cobertura aislada del scout** (`730509b`,
  PR #63). Se alinea el contrato entre especificación, doctor y pruebas, se
  corrige el falso negativo del doctor y se añaden cobertura determinista y un
  smoke aislado opt-in. El smoke respaldado por proveedor permanece
  **Unavailable** sin modelo y credencial explícitos.

## [0.24.3] - 2026-07-30

### Fixed

- **Scout de solo lectura sin skills y orientación acotada del orquestador**
  (`f0c786d`, PR #60). `ein-scout` recibía inyección de skills como cualquier
  agente nombrado, pese a estar aislado al repo con `inheritSkills: false`: los
  paths absolutos de `SKILL.md` caían fuera de su sandbox → `Skills not found` y
  ejecución degradada. Ahora se excluye al scout de la inyección de skills.
  Además el orquestador acota su orientación de arranque (`ein_sdd_status` +
  `git status --short`), reconoce que limpiar un cambio sin trackear es `rm -rf`
  en vez de una auditoría, y usa las herramientas `ctx_*` en modo indexar-y-buscar
  en vez de volcar output — evitando que se coma el contexto nada más empezar.

## [0.24.2] - 2026-07-30

### Fixed

- **Arranque de `ein-scout` sin extensiones** (`47712f8`, PR #58). El frontmatter
  declaraba `extensions: []`; pi-subagents parsea ese campo con
  `parseFrontmatterList` (no JSON), que trata `[]` como token literal y lo
  convierte en `--extension []` → el launcher intentaba cargar una extensión en
  `<cwd>/[]` y tumbaba el arranque de cualquier subagente. Ahora el campo va
  definido pero vacío (`extensions:`), que dispara `--no-extensions` sin token
  basura. Un test reproduce los dos parsers de frontmatter de pi-subagents sobre
  los agentes reales, y el orquestador acota sus lecturas inline y trata un scout
  caído como incidente en vez de tragar la investigación.

## [0.24.1] - 2026-07-30

### Fixed

- **Arranque de subagentes con `ein-scout` instalado** (`c2f9775`, PR #55). El
  frontmatter de `ein-scout` declaraba `turnBudget`/`toolBudget` como objeto con
  claves sin comillas; pi-subagents los pasa por `JSON.parse` y el error tumbaba
  el arranque de cualquier subagente (p.ej. `sdd-scope`), porque al lanzar uno se
  enumera el registro entero de agentes. Ahora son JSON válido; un nuevo test
  valida el frontmatter inline real de todos los agentes.

## [0.24.0] - 2026-07-30

### Added

- **`ein-scout` de solo lectura** (`ffe2034`, PR #52). Permite una exploración
  acotada con `read`, `grep` y `find`, lanzada de forma directa y fresca; sus
  informes citados fallan cerrados cuando falta evidencia.
- **Proveniencia fiable para el coste SDD** (`f823cae`, PR #51). El ledger usa
  recibos locales estructurados, no infiere datos por nombres de tarea y muestra
  `n/a` cuando no hay información suficiente.

### Changed

- **Retornos SDD más compactos** (`619c87a`, `9cc1c48`, PR #53). Las siete
  fases devuelven el resumen necesario y derivan la investigación amplia previa
  al alcance a scout; el detalle canónico permanece en disco.
- **Contrato de enseñanza más claro** (`b84cbd6`, PR #50). Las explicaciones
  de Ein y del orquestador priorizan a la persona que las usa.

### Fixed

- **Aceptación y cierre SDD sin ambigüedad** (`dbd6187`, PR #50). La aceptación
  normal queda en `none` y el modo verificado exige declararse; los cierres y
  forzados rechazan estados no permitidos en vez de avanzar por error.

## [0.23.0] - 2026-07-29

### Added

- **Entrega ligada al candidato verificado** (`57c78cb`). Los bytes y el árbol
  exactos que verificó el candidato quedan ligados al repositorio, worktree,
  HEAD y rutas declaradas, y se comprueban antes de entregar el commit.

### Fixed

- **Recuperación de timeout exacta** (`81a1ddd`). Antes de reintentar, la
  entrega reconcilia el estado real del repositorio y ejecuta una sola vez el
  delta restante exacto.
- **Retiro de receipts tras merge** (`1f89b0f`). El retiro pasa a ser explícito
  y solo sucede después de confirmar un PR fusionado en el mismo repositorio,
  sin borrar su evidencia.
- **Retiro durable de receipts** (`961aefa`). La revalidación, observación del
  remoto, locks y persistencia endurecen ese ciclo de vida sin aceptar estados
  dudosos.
- **Evidencia OpenSpec separada** (`874cab4`). El hardening conserva su
  evidencia en su propio cambio para que la trazabilidad del retiro siga siendo
  revisable.

## [0.22.1] - 2026-07-21

### Added

- **Contrato con Pi.** Ein codificaba supuestos sobre Pi —nombres de tools
  builtin en las allowlists de los agentes, hooks de extensión, métodos de
  `ExtensionAPI`— y ninguno estaba comprobado en ningún sitio: cada `pi update`
  era una ruleta. Ya salió caro una vez (`glob` no existe en Pi y tres fases SDD
  salieron ✗ con sus artefactos correctos). Ahora ese contrato es explícito y se
  valida en dos direcciones: si **Ein** empieza a usar algo sin declararlo, falla
  en CI; si **Pi** deja de ofrecerlo, `ein doctor` lo dice por su nombre antes de
  que un run falle de forma incomprensible. La comprobación contra la
  instalación real se salta declarándose cuando Pi no está, nunca fingiendo un
  veredicto.

### Changed

- El set de tools builtin de Pi vivía replicado en tres sitios. Ahora hay una
  sola fuente, contrastada contra la instalación real: tres copias de la misma
  verdad son la duplicación que ya abrió un agujero en la validación de OpenSpec.

## [0.22.0] - 2026-07-21

### Added

- **OpenSpec canónico**: especificaciones vigentes en `openspec/specs/<dominio>/`
  y deltas de comportamiento por cambio, con parser estricto, sincronización
  determinista por hashes y `sync-report.md` como recibo. El cierre exige specs
  sincronizadas; `spec_delta: none` con una razón real cubre el trabajo mecánico.
  Nuevo tool `ein_openspec_sync`: sin él el motor era código muerto y un cambio
  con deltas se quedaba bloqueado para siempre.
- **Pathspec cerrado en la entrega.** Un commit contiene lo que se decidió
  entregar, no lo que hubiera en el árbol. Se rechazan `git add -A/-u/.` y
  `git commit -a`, también dentro de `bash -c`, y se bloquea el `git add dir/`
  que arrastraría ficheros no trackeados o ignorados que nadie nombró — ahí es
  donde se cuela un `.env` o el trabajo en curso de otro. La salida siempre es
  la correcta: nombrar las rutas.
- **Recibo de candidato verificado.** Un verify que pasa ya no dice solo "pasó":
  fija QUÉ bytes pasaron en un árbol git construido con un índice temporal (sin
  tocar el índice ni el worktree reales) y lo liga a repositorio, worktree,
  cambio, HEAD, rutas declaradas, informe y comandos. Solo se emite sobre un
  verify en `pass`, no obsoleto y con el apply completo. Nuevo tool
  `ein_candidate_receipt`. Aún no bloquea la entrega: eso es el siguiente paso.

### Fixed

- **El cierre SDD estaba muerto.** La guarda de specs se evaluaba antes que
  `--force`, así que un cambio sin declaración no podía archivarse por ninguna
  vía. Ahora solo un `conflict` real es inmune a `--force`.
- **`synchronized` era inalcanzable**: el estado se recalculaba reaplicando el
  delta sobre specs ya sincronizadas, lo que producía un conflicto artificial.
  El motor escribía "synchronized" y el router leía "pending" para siempre.
- **Integridad de la sincronización**: un nombre de cambio con `..` escribía
  fuera de `openspec/changes/`, un nombre cualquiera creaba un cambio fantasma
  con solo su recibo, y un recibo copiado de otro cambio pasaba por bueno.
- El recibo de candidato representa correctamente altas, bajas y renombrados.

## [0.21.0] - 2026-07-21

### Fixed

- **`glob` no existe en Pi: los siete agentes SDD declaraban una tool fantasma.**
  Los builtins son `read/bash/edit/write/grep/find/ls`; el equivalente se llama
  `find`. Como `tools:` es una allowlist ESTRICTA, el runner convertía la tool
  ausente en un error AL CERRAR el run: la fase salía ✗ **aunque el artefacto
  estuviera escrito** y `ein_sdd_check` lo validara. Encima anteponía al prompt
  del hijo "reporta este error de configuración", así que reintentaba mientras
  trabajaba. Coste medido en una sesión real: scope/map/design en ✗ con sus
  artefactos correctos y ~120k tokens en reintentos.
- **El gate de entrega fallaba-cerrado por un adjetivo.** Deducía de la prosa de
  la task si una delegación era una entrega: "push the branch" acuñaba el grant
  y "push current branch" no, con el mismo significado. Al no acuñarlo, `ein-git`
  headless quedaba bloqueado **sin salida**. Ahora decide el agente destino
  (`ein-git` ES entrega, se redacte como se redacte) y la prosa queda como red
  secundaria. Además: la intención de entrega del usuario es PEGAJOSA con TTL
  (antes un log pegado a mitad del encargo revocaba en silencio tu "haz push"),
  el grant admite usos acotados en vez de uno solo (un reintento legítimo se
  quedaba sin autorización) y el mensaje de bloqueo dice que falta el GRANT —
  el genérico anterior hacía creer al subagente que faltaba `.pi/ein/git.json`.

### Added

- **El artefacto manda sobre el veredicto del runner.** Una fase SDD entrega UN
  artefacto: si está escrito y sano, la fase está hecha. El runner marca ✗ por
  cosas que no dicen nada del trabajo (tool ausente en la allowlist, respuesta
  final vacía, timeout en la lectura final) y el orquestador repetía una fase
  completa. Ahora se reconcilia de forma determinista, y **solo** si el artefacto
  de esa fase apareció o cambió DURANTE el run, es el único candidato y pasa su
  lint sin errores. El error original viaja siempre dentro del reporte.
- **`ein doctor` audita las allowlists de tools desplegadas**, no solo el repo:
  detecta la deriva entre `~/.pi/agent/agents/` y la plantilla.
- **La puerta de calidad corre en Ubuntu y macOS** con una versión de Bun fijada
  (matriz compartida, sin workflows duplicados). El E2E con Docker sigue solo en
  Ubuntu.
- **Roadmap de calidad** en `docs/quality-roadmap/`.

### Changed

- Suite blindada contra estas dos clases de fallo: contrato de tools de agentes
  (valida cada nombre declarado contra los builtins reales de Pi y cruza la tabla
  del orchestrator con el frontmatter) y reconciliación de fases, con la mayoría
  de casos cubriendo lo que NO debe reconciliarse.
- Los tests fijan el `AGENT_DIR` temporal en un preload, así que el orden de
  descubrimiento de ficheros deja de decidir si la suite pasa.

## [0.20.2] - 2026-07-17

### Removed

- **Fuera los presets de modelos `/ein:models:full` y `/ein:models:lite`.** Salen
  modelos y cambian precios cada semana: un preset que hardcodea nombres se pudre
  en silencio y da falsa confianza. Se eliminan los comandos, el modo del panel y
  todos los nombres de modelo de la documentación. Se queda lo que NO caduca: el
  esfuerzo por agente (un nivel, no un nombre) y la recomendación por rol.

### Changed

- **Las recomendaciones de `/ein:models` ahora se ven.** Marca `!` en cualquier
  agente cuyo esfuerzo fijado se desvíe del recomendado, más una línea explícita
  "Fuera de recomendación: X → recomendado Y" para el agente enfocado.
- **`sdd-apply` se recomienda ahora con modelo CAPAZ y esfuerzo bajo.** El coste
  lo controla el esfuerzo, no abaratar el modelo: uno barato no ahorra, flaquea
  (135 turnos y 1.5M tokens en un grupo con TDD estricto, agotando la cuota del
  proveedor). Sin routing condicional ni preguntas nuevas: mejor recomendación.
- **`apply-progress.md` se mantiene compacto**: cada grupo aporta un resumen, no
  un volcado (un cambio llegó a 906 líneas y disparó el aviso de tamaño).

## [0.20.1] - 2026-07-16

### Added

- **Brief docente antes de la compuerta de apply.** En un SDD interactivo, antes
  de preguntar "¿aplico?", el orquestador ahora presenta un resumen en tono
  docente: QUÉ consigue el cambio, CÓMO va a funcionar por dentro (del diseño),
  QUÉ SE TOCA (grupos + ficheros de producción exactos) y RIESGOS — y luego
  pregunta. La lista de ficheros es determinista (`resolveSddPlanPreview` sobre
  `tasks.md`, tests excluidos), no la paráfrasis del modelo; `ein_sdd_status` la
  adjunta en la ventana de apply. Se acabó decidir a ciegas.

## [0.20.0] - 2026-07-16

Cierra el arco de coste y fiabilidad del SDD acumulado en la serie 0.19.x
(updater transaccional funcionando, apply barato, TDD off por defecto, guards de
cierre, calibración de map/verify). Esta release recalibra el último cabo suelto
y termina el right-sizing de grupos.

### Fixed

- **El `turnBudget` de apply ya no aborta trabajo legítimo (regresión de E4).**
  El cap de 40 turnos cortaba a mitad un apply de TDD estricto —que corre muchos
  ciclos RED/GREEN legítimos— y llegó a bloquear un SDD entero. Ahora los applies
  de TDD estricto **no llevan cap de turnos** (los gobierna `maxRuntimeMs`); el
  cap normal sube a 60, como backstop solo de runaways reales.

### Changed

- **`sdd-tasks` dimensiona los grupos al trabajo real (bloque F).** Ni demasiados
  ni grupos monstruo: cada grupo ≤3-4 ficheros de producción, un tipo fundacional
  va en su propio grupo mínimo (nunca junto a sus consumidores), y bajo TDD
  estricto los grupos son aún más pequeños. `ein_sdd_check` avisa `oversized-group`
  cuando un grupo toca >4 ficheros de producción, para partirlo antes de aplicar.

## [0.19.14] - 2026-07-16

### Changed

- **Calibrado el thinking de map/verify y recomendaciones en `/ein:models` (bloque G).**
  Tras abaratar apply (bloque E), el coste se movió a `sdd-map` (~222k) y `sdd-verify`
  (~297k) — fases que leen y verifican, no diseñan. Ahora corren a `thinking: medium`
  por defecto; solo `orchestrator` y `sdd-design` (que razonan) siguen en modelo
  capaz/high. El detalle que design necesita vive en `map.md`, no en los tokens de map,
  así que bajar su thinking no pierde detalle. Además, el panel `/ein:models` muestra la
  recomendación por agente (barato/capaz + thinking + por qué) para elegir sin memorizar
  la arquitectura.

## [0.19.13] - 2026-07-16

### Added

- **Aviso de sesión obsoleta tras un `ein update` a mitad de sesión.** La plantilla
  (agentes, orchestrator.md, preflight/config) se carga al arrancar la sesión y
  corre una vez; un `ein update` cambia los ficheros en disco pero la sesión viva
  sigue con lo anterior. Ahora la sesión padre interactiva registra la versión
  instalada en su primer turno y, si cambia a mitad de sesión, avisa UNA vez de
  reiniciar Pi para cargar los cambios.

## [0.19.12] - 2026-07-16

### Changed

- **TDD off por defecto, una sola pregunta, sin doble-ask (bloque B).** El default
  de TDD pasa a **off** (la mayoría del trabajo frontend/simple no necesita
  RED/GREEN ni debe quemar tokens); strict es opt-in. El preflight pregunta la
  postura UNA vez al arrancar (off/strict, default off) y **siempre** fija la
  decisión de sesión, así el gate de delegación ya no vuelve a preguntar a mitad
  de flujo — fin del doble-ask que salía cuando el modo global era `ask`.

## [0.19.11] - 2026-07-15

### Changed

- **La fase apply del SDD ejecuta, ya no razona (bloque E: coste).** Apply era el
  sumidero de tokens (un cambio de 1 línea llegó a 47 turnos y rechazos varios).
  Ahora: `sdd-apply` corre a `thinking: low` (E0); se delega con `acceptance: none`
  por defecto y `sdd-verify` es el gate runtime real (E1), quitando el peaje del
  acceptance-report que hacía thrashear a los modelos baratos; nunca toca la línea
  `status:` de `tasks.md` y el lint acepta un tasks 100% cerrado (E2); y lleva un
  `turnBudget` backstop contra runaways (E4). El orquestador puede pedir
  `acceptance: verified` explícito cuando quiera re-ejecución por grupo.

## [0.19.10] - 2026-07-15

### Added

- **`ein_sdd_close` como herramienta.** El orquestador solo tenía el comando de
  usuario `/ein:sdd-close` (que no puede invocar por sí mismo), así que cerraba
  con rodeos (importar la librería a pelo) o pedía al usuario que lo tecleara.
  Ahora es una tool determinista —gemela de `ein_sdd_status`/`ein_sdd_check`—
  con el mismo guard de readiness, receipt de memoria y refresco de EIN.md.

### Fixed

- **Fuga de artefacto al usar una fase como explorador.** Delegar `sdd-map`
  (que es una FASE y escribe `map.md`) para investigar un cambio aún sin scope
  dejaba un `map.md`/dir stray. El router marca ahora un artefacto **fuera de
  orden** (una fase presente cuyo predecesor falta) para que `ein_sdd_status` lo
  surface; la investigación pre-scope debe ir por lectura directa, no por una fase.

## [0.19.9] - 2026-07-15

### Changed

- **El SDD ya no pregunta entre cada fase.** El modo interactivo se redefine: las
  fases de planificación (scope→map→design→tasks) corren de corrido sin preguntar;
  la única compuerta humana normal es UNA confirmación antes del primer apply, que
  cubre todos los grupos aprobados. verify/close siguen automáticos si pasan, pero
  paran con la causa exacta ante fallo, bloqueo o evidencia obsoleta.
- **Apply por grupos, reanudable.** `ein_sdd_status` muestra `next pending: <id>
  <título>` (la primera tarea sin marcar). Tras reabrir Pi, el flujo continúa desde
  ese grupo sin rehacer lo ya hecho.

## [0.19.8] - 2026-07-15

### Fixed

- **El SDD ya no puede cerrar sobre evidencia obsoleta.** Si una corrección se
  aplica DESPUÉS de que verify pasara, `verify-report.md`/`summary.md` seguían
  afirmando el estado viejo como verificado, y `/ein:sdd-close` (un move puro)
  archivaba igual. Ahora el router detecta la obsolescencia de forma determinista
  (por mtime: apply-progress más nuevo que verify → `verifyStale`) y enruta de
  vuelta a `verify`; `closeChange` rechaza archivar salvo que apply esté completo,
  verify sea pass y fresco, summary exista y fresco, y no queden tareas pendientes.
  `--force` es el escape deliberado.

## [0.19.7] - 2026-07-15

### Fixed

- **`ein update` completa la transacción (el arreglo definitivo).** La transacción
  spawnea el binario nuevo con tres entry-points que no existían en `main.ts`, así
  que fallaba etapa tras etapa (`verifying`, luego el swap, luego el deploy). Toda
  la transacción solo se había probado contra `child.spawn` mockeado. Ahora el
  binario implementa: `--version` con línea `template-version` (el probe necesita
  ambas), `--ein-continuation` (confirma identidad tras el swap) y
  `--ein-deploy-template` (extrae el template embebido). Se añade un smoke test que
  ejercita los tres contra el `main.ts` real. Como corren sobre el binario nuevo,
  `ein update` desde una versión rota los alcanza y completa la actualización.

## [0.19.6] - 2026-07-15

### Fixed

- **`ein update` seguía cortándose al descargar (segunda mitad del arreglo).**
  Tras subir el cap de tamaño (v0.19.5), el deadline HTTP de 15 s —correcto para
  el JSON de metadata— abortaba a mitad la descarga del binario Bun de ~90 MB
  (`acquiring-metadata: The operation timed out`). `http.get` acepta ahora un
  timeout por llamada: metadata/checksums fallan rápido (30 s) y la descarga del
  asset dispone de 300 s. Igual que con v0.19.5, hay que reinstalar una vez con
  el script `curl` para estrenar el arreglo.

## [0.19.5] - 2026-07-15

### Fixed

- **`ein update` fallaba en Linux y macOS-x64.** El actualizador transaccional
  limitaba toda respuesta HTTP a 64 MB, pero el binario del instalador es un
  ejecutable Bun standalone que empaqueta el runtime y pesa ~66-95 MB (linux-x64:
  91 MB). La descarga del asset reventaba el límite y el update abortaba en
  `acquiring-metadata: Response exceeds size limit`. Cap subido a 256 MB, con
  test de regresión. Para recibir el arreglo hay que reinstalar una vez con el
  script `curl`: `ein update` desde una versión anterior seguirá fallando porque
  el límite viejo va compilado en el binario.

## [0.19.4] - 2026-07-15

### Fixed

- **Los ejecutores SDD ya no se desacoplan del padre.** El intercom bridge de
  pi-subagents queda desactivado para los agentes EIN (`intercomBridge.mode:
  off`): en vez de detenerse a mitad pidiendo una decisión al supervisor —lo que
  dejaba al orquestador en bucles de `sleep`— devuelven `status: blocked` con la
  causa concreta.
- **El preflight Git deja de convertir stashes en una falsa emergencia.** Un
  stash es trabajo aparcado, no evidencia de un HEAD incorrecto; solo un `reset`
  reciente dispara la reconciliación. Y esa directiva se inyecta solo al
  orquestador, no a cada ejecutor: reconciliar el árbol es asunto del padre una
  vez, y los ejecutores dejan de re-auditar el repo (`git fsck`/`reflog`/`stash`).

## [0.19.3] - 2026-07-15

### Fixed

- **Fases documentales del SDD ya no se rechazan en falso.** Un hook determinista
  inyecta `acceptance: none` en las delegaciones de planificación (scope, map,
  design, tasks, close); el runner deja de exigir evidencia `tests-added` a un
  artefacto que `ein_sdd_check` ya valida. La ✗ dependía de que el orquestador
  recordara pasar el campo, por eso a veces aparecía y a veces no.

### Changed

- **TDD se elige al inicio del SDD.** El preflight pregunta la postura de TDD
  (off/strict/auto) junto al modo de ejecución; elegir off o strict fija la
  decisión de la sesión y el flujo no vuelve a interrumpirse a mitad.

## [0.19.2] - 2026-07-15

### Fixed

- **El instalador siempre nombra el paquete pi con scope.** El `pi` pelado en
  npm es una librería matemática ajena cuyo bin pisa al agente y rompe `pi`; el
  mensaje de fallo de `installPi` lo abreviaba a `bun install -g pi`, un footgun
  si se copiaba. Ahora nombra `@earendil-works/pi-coding-agent`, con un test que
  impide reintroducir la forma sin scope.

## [0.19.1] - 2026-07-15

### Fixed

- **`ein update` vuelve a actualizar pi.** La reescritura transaccional del
  actualizador dejó de refrescar el agente subyacente (`bun install -g pi`) y
  los paquetes Pi declarados, aunque el menú y la ayuda seguían prometiendo
  «Ein y pi». Tras un update verificado y no dry-run, pi y sus paquetes se
  refrescan de nuevo (best-effort, con confirmación); un fallo al refrescar pi
  no invalida el update del binario de Ein.

## [0.19.0] - 2026-07-14

### Added

- **Actualizador transaccional y verificado.** `ein update` resuelve releases
  estables, descarga el asset de la plataforma y valida su checksum antes del
  despliegue; sustituye el ejecutable, el template y el marker de instalación
  de forma atómica. Un fallo revierte el estado previo y una transacción
  interrumpida se recupera en la siguiente ejecución.
- **Ciclo de vida de Engram determinista.** El adapter CLI acota la memoria a
  operaciones verificables en fuente/desarrollo, guarda los descubrimientos de
  fase con claves estables y deja OpenSpec como verdad canónica cuando Engram
  no está disponible o falla sin bloquear el flujo.

### Changed

- **Semántica de Git y banner aclarada.** El estado mostrado distingue de forma
  determinista sincronía, remoto adelantado, commits sin publicar y cambios sin
  commit, con fallback explícito para offline, repos sin remoto y no-repos.
- **Experiencia de README y release más verificable.** La ruta rápida de
  instalación, el enlace a la instalación detallada y el bloque de última
  release se alinean con el registro local; la publicación conserva el tag
  genérico `installer-v<semver>`.

## [0.18.0] - 2026-07-13

### Added

- **Grafo de código (CodeGraph), opt-in y conmutable.** Si el proyecto está
  indexado con [codegraph](https://github.com/colbymchenry/codegraph)
  (`codegraph init`; AST determinista → SQLite local), Ein inyecta al
  orquestador y a las fases SDD la directiva "un `codegraph explore` antes que
  una docena de grep/read" — código verbatim + call paths + blast radius en una
  llamada, por CLI (la ruta MCP se descartó: el interop con pi-mcp-adapter
  cuelga; detalles en `docs/codegraph-spike-plan.md`). `/ein:codegraph`
  (`auto`|`off`, default `auto` = binario + índice); sin cualquiera de los dos,
  cero prompt gastado. `sdd-map` gana bash acotado EXCLUSIVAMENTE a queries
  codegraph read-only. `.codegraph/` entra al gitignore gestionado; celda
  CGRAPH en el banner. Medido en Fase 0: -38% mediana de payload (hasta -85%
  en ficheros grandes) frente a grep+read manual.
- **codegraph como dependencia opcional del installer** (wizard con default no,
  `--no-codegraph`, doctor `warn`), con `codegraph telemetry off` automático
  tras instalar — la política de Ein es no-telemetría.

### Changed

- **Bootstrap de `openspec/config.yaml` compartido y automático.** La
  detección/creación se extrae de `sdd-init` a una lib compartida y corre
  create-if-absent en el preflight SDD: los subagentes ya no se atascan
  preguntando por config vía intercom. El router deja de reportar "tasks.md
  ausente" como bloqueo en fases previas a tasks (era ruido en cada status).
- **Doctrina de intercom del orquestador renovada** (validada con incidentes
  reales): el canal supervisor nativo funciona (detach→reply→resume) — ante un
  ask vivo: verificar realidad → responder con decisión → `wait` inmediato sin
  cerrar el turno; y ante un hijo detachado "aparentemente muerto" (wait ciego,
  status congelado, resume rechazado), comprobar el mtime de su session file
  antes de lanzar una continuación — dos applies concurrentes sobre el mismo
  árbol se pisan.
- Tabla-inventario del orquestador sincronizada con los tools reales de
  `sdd-map` (write + bash acotado; estaba stale desde v0.17.5).

## [0.17.6] - 2026-07-13

### Fixed

- **Un `tasks.md` 100% completado ya pasa el gate.** Regresión destapada por
  0.17.5: al ordenar a `sdd-apply` marcar los checkboxes en ambos modos, un
  cambio terminado deja todo `- [x]` — y la señal obligatoria del linter solo
  matcheaba el literal `- [ ]`, así que `ein_sdd_check` reventaba con
  `missing-checkbox` justo al acabar el trabajo (y empujaba a des-marcar tareas
  hechas). La señal acepta ahora `- [ ]` y `- [x]`: significa "hay checklist",
  no "hay trabajo pendiente".

## [0.17.5] - 2026-07-13

### Fixed

- **Fin del `parent-fallback` en cada `sdd-map`.** Causa raíz: pi-subagents
  resuelve un `output` relativo dentro de su sandbox `.pi-subagents/`, nunca en
  el repo — el "runner escribe el artefacto" era una premisa falsa y CADA map
  acababa copiado a mano por el parent con warning de provenance. Ahora
  `sdd-map` tiene `write` (como todas las demás fases) y escribe él mismo su
  único artefacto en `openspec/changes/{change}/map.md`; el orquestador ya no
  pasa `output`/`outputMode` al delegar fases y el fallback queda como último
  recurso.
- **Checkboxes de `tasks.md` en strict TDD.** La instrucción de marcarlos solo
  existía en modo standard: un cambio terminado en strict reportaba `pending=N`
  para siempre en `ein_sdd_status`. Ahora se marcan en ambos modos.
- **`.pi-subagents/` en el bloque gestionado del gitignore.** El scratch de runs
  de subagentes no se ignoraba; `openspec/changes/` (el board) nunca se ignora.

### Changed

- **Guía de runtime por fase en el orquestador.** Apply estricto/multi-grupo
  ≥30 min (y continuar desde `apply-progress.md` tras un timeout, no reiniciar);
  fases de planificación que leen código (map/tasks/revisiones) ≥10 min; >6
  grupos en un `tasks.md` = smell de scoping (trocear en cambios hermanos).
- **Límite de shell compuesto en `ctx_batch_execute`.** `for`/`if`/heredocs
  rompen por el prefijo `NODE_OPTIONS` del wrapper; el orquestador ahora los
  envuelve en `bash -c '…'` en vez de reintentar en bucle.

## [0.17.4] - 2026-07-10

### Added

- **Estado de sync de git en la tabla de inicio.** GIT pasa a su propia fila con
  el estado real de la rama, calculado de forma **determinista** (cero tokens de
  modelo, una ronda de red con `ls-remote`): `✓ sync` · `⚠ pull (remoto adelante)`
  · `↑N sin pushear` · `○N sin commitear`. Para saber, antes de tocar nada, si
  otro PC ya adelantó la rama. Best-effort: offline → `sync?`, sin remoto →
  `local`, sin repo → nada.

### Fixed

- **`linear-workflow` no se inyecta en modo Solo.** La skill puntúa alto por sus
  tags (`nuxt`/`github`), así que el advisor la metía en `sdd-scope` en cualquier
  proyecto Nuxt aunque Linear estuviera dormido — ruido y tokens malgastados.
  Ahora las skills solo-Team se excluyen fuera de Team (filtro en la inyección,
  no en el registro: un cache viejo ya no la cuela).

## [0.17.3] - 2026-07-10

### Fixed

- **Onboarding: "Personalizar" repasa los 5 esenciales.** Antes solo preguntaba
  por lo pendiente (fichero de config ausente), así que en un proyecto con
  persona/lang/tdd ya configurados de antes solo pedía hypa + EIN.md — sensación
  de flujo incompleto. Ahora "Personalizar" repasa siempre los 5 mostrando el
  valor actual (`← actual`); "Usar recomendados" sigue rellenando solo lo
  ausente (nunca pisa una elección previa). La intro indica qué falta.

## [0.17.2] - 2026-07-10

### Fixed

- **`ein update` reventaba con `ENXIO: no such device or address`.** El backup
  previo copiaba `intercom/broker.sock` (socket IPC del runtime de Pi) con
  `cpSync` → `open()` sobre un socket falla con ENXIO y abortaba la actualización.
  Se excluye `intercom/` del backup y se añade un filtro que salta cualquier
  socket/FIFO/dispositivo (blindaje ante ficheros especiales sueltos).

### Changed

- **Tabla de inicio (banner de Pi) a 3 columnas** — más legible — y añade
  **HYPA** con su estado resuelto (`auto·on`/`auto·off`/`on`/`off`), como el TDD.
- **Animación del installer, una vez por proceso.** Menú → Install la repetía;
  ahora la segunda vez pinta estático. Añade una frase de la casa atenuada bajo
  el logo tras materializarlo.

## [0.17.1] - 2026-07-09

### Added

- **Índice de EIN.md autoactualizable.** Al cerrar un cambio (`sdd-close`) el
  `## Índice` se mantiene solo: cobertura **determinista** (los dirs nuevos
  entran con placeholder, se preservan las descripciones, caen los que ya no
  existen) + descripciones que el agente `sdd-close` rellena **solo para los
  dirs que tocó el cambio** (una línea, sin reescribir lo existente ni tocar
  otras zonas). El mapa del repo no envejece sin trabajo manual.

## [0.17.0] - 2026-07-09

### Added

- **Onboarding first-run.** La primera vez que Ein entra a un proyecto sin
  configurar (agnóstico a su edad: mira "¿está configurado?", no "¿es nuevo?"),
  un wizard único en `session_start` resuelve los esenciales —persona, idioma de
  artefactos, TDD, Hypa— y genera `EIN.md`. "Usar recomendados" de un toque o
  personalizar. Pendiente = fichero `.pi/ein/*.json` (o `EIN.md`) ausente; una
  vez escritos no vuelve a preguntar. No-op sin UI. Comando `/ein:onboard`.
- **`## Índice` y `## Docs` en EIN.md.** El scaffold siembra un `## Índice`
  curado con las carpetas del repo (una línea de "qué es cada cosa", preservado
  al refrescar) y la zona AUTO añade `## Docs` con links a la documentación
  detectada. `sdd-close` refresca la zona AUTO al cerrar un cambio.

### Changed

- **Hypa: default `auto` con detección de stack.** Nuevo modo `auto` (default,
  antes `off`): envuelve en toolchains verbosos no-Bun (dotnet/gradle/terraform/
  k8s → 90-100% menos ruido) y se queda crudo en Bun puro (ya terso). Modos
  `auto|on|off`; se retira el "ask" (el onboarding ya pregunta).
- **TDD `ask` pregunta al arrancar el SDD completo.** El gate se dispara al
  delegar la fase `scope` (no a mitad del apply) y cachea la decisión por run →
  no re-pregunta en applies sucesivos (slices).

## [0.16.0] - 2026-07-09

### Added

- **Compresión determinista de salida de comandos (Hypa).** `/ein:hypa on`
  envuelve el tool `bash` con [Hypa](https://github.com/Hypabolic/Hypa) para
  reducir el ruido que tragan los modelos baratos en `sdd-apply`/`sdd-verify`.
  Solo se envuelve un allowlist de tools con reducer real (git de lectura,
  vitest/jest/eslint/biome/oxlint, dotnet, cargo, terraform…); el genérico se
  deja a `context-mode` y el streaming/interactivo (`dev`, `serve`, `--watch`,
  `logs`, `-f`, `-it`) nunca se toca. Opt-in, default `off`, persistente en
  `.pi/ein/hypa.json`.
- **Integración EIN-native (sin la extensión `pi-hypa`).** El wrap se hace
  mutando `event.input.command` en el hook `tool_call`: los guardrails corren
  sobre el comando ORIGINAL primero y solo entonces se envuelve. Normaliza el
  prefijo Bun (`bunx vitest` → `vitest`) e inyecta `./node_modules/.bin` en el
  PATH para resolver el binario sin romper el anchor del reducer.
- **Hypa como dependencia opcional del installer.** `checkDeps` la detecta
  (no bloqueante), el wizard ofrece instalarla (`--no-hypa` para omitir), y el
  doctor la reporta en RUNTIME (`warn`, nunca falla). Si falta el binario, el
  wrap queda inerte y Ein cae a bash + `context-mode`.

## [0.15.3] - 2026-07-08

### Added

- **Modelo de ramas `feature -> dev -> main` en `github-workflow`.** La skill de
  delivery adopta un flujo de promoción explícito: `main` = producción (solo
  recibe merges desde `dev`), `dev` = integración/staging donde el trabajo
  terminado convive antes de publicar, y las ramas `feat/*`/`fix/*`/`chore/*`
  salen de `dev` y apuntan a `dev`. Incluye la excepción de hotfix (rama desde
  `main`, PR a `main`, y merge `main -> dev` de vuelta), el bootstrap del repo
  (crear `dev` desde `main` si falta) y la nota de previews de Vercel. Nuevo
  hard-stop gate que verifica la base de la rama antes de cualquier `git`/`gh`.

## [0.15.2] - 2026-07-08

### Added

- **Cobertura de comportamiento en `verify`.** Un `status: pass` con solo build
  y typecheck verdes ya no basta: `sdd-verify` declara `behavior_coverage`
  (`verified | partial | none | n-a`) y `ein_sdd_check` avisa (warning, no
  bloquea el routing) cuando un PASS no confirmó el comportamiento observable —
  un build verde no prueba no-regresión.

### Changed

- **Retirado el fallback cross-provider de los 9 agentes.** Se elimina
  `fallbackModels`: Ein deja de cambiar de modelo automáticamente a media
  tarea, restaurando la promesa del README. Un corte transitorio del proveedor
  se absorbe con el retry paciente (`maxRetries: 6`, backoff) en el mismo
  modelo; agotar cuota de verdad es una decisión manual (`/ein:models:lite`).
  Evita picos de coste silenciosos (un agente barato escalando al modelo caro)
  y caídas de calidad a mitad de un trabajo con estado.

## [0.15.1] - 2026-07-08

### Added

- **Baseline de git en el preflight SDD** (`lib/git-baseline.ts`). Al arrancar
  un flujo SDD, Ein hace un snapshot determinista del árbol (`reflog`, `status`,
  `stash list`) e inyecta un WARNING en el bloque de preflight si detecta un
  `reset` reciente o stashes — señal de trabajo posiblemente huérfano. Obliga a
  reconciliar HEAD con el usuario **antes** de la primera mutación. Cubre el
  fallo donde el flujo refactorizaba sobre un árbol revertido y `verify` firmaba
  PASS sobre trabajo perdido.

### Changed

- **Cortafuegos anti-inline en el orquestador.** Si se agotan los subagentes
  ("spawn limit reached"), el parent PARA en vez de ejecutar todo inline —
  evita invertir el modelo de coste, saltarse la re-ejecución de acceptance y
  convertir el gate en autocertificación.
- **`ein_sdd_check` rechaza telemetría fabricada.** Valores tipo `tokens:
  unknown` o un `ledger` con excusas (`parent-direct`, `subagent limit
  reached`) son ahora error duro. La ausencia de telemetría de run se relaja a
  warning **solo** con `authored_by: parent-fallback` — salida honesta que no
  obliga a inventar cifras para pasar el gate.

## [0.15.0] - 2026-07-02

### Added

- **Backups v2 del instalador.** Snapshots comprimidos (`.tar.gz`) con sidecar
  de metadatos, dedup por hash de contenido (si el árbol no cambió, no se crea
  otro backup), poda automática conservando los 5 más recientes y pins
  (`ein restore --pin/--unpin <nombre>`) que la poda respeta. Los backups
  legacy (directorio) siguen listándose y restaurándose. Los backups ya **no
  incluyen `auth.json`** (ni `bin/` ni `disabled-skill-conflicts/`): restaurar
  un backup antiguo nunca pisa credenciales actuales — antes sí podía.
- **Rollback automático.** `ein install` (sobre un árbol existente) y
  `ein update` snapshotean antes del deploy y, si la extracción falla a
  medias (el deploy limpia los dirs del template antes de extraer), restauran
  solos el estado anterior.
- **`--dry-run`** en `ein install` y `ein update`: muestra el plan completo
  (deps a instalar, backup, contenido del template, pasos restantes) sin
  ejecutar nada.
- **`template-manifest.json`** generado por el bundler dentro del tarball:
  describe exactamente qué agentes/chains/extensiones lleva el bundle. Lo
  consumen `ein doctor` (valida lo desplegado contra lo distribuido, sin
  listas cableadas) y `--dry-run` (lo lee del binario sin desplegar).
- **E2E real en Docker** (`e2e/docker-test.sh` + workflow manual `e2e`):
  instala Ein en un Ubuntu limpio (bun + pi desde la red), verifica doctor,
  reinstalación con backup y dry-runs.

### Changed

- **Reorganización del repo: `ein-pi/core/` (portable) vs `ein-pi/agent/`
  (runtime Pi).** `agents/`, `skills/`, `prompts/`, `docs/` y `AGENTS.md` viven
  ahora en `core/`; `extensions/`, `lib/`, `chains/`, `assets/` y los JSON de
  runtime siguen en `agent/`. El bundler compone ambas raíces y el layout
  desplegado en `~/.pi/agent` no cambia (Pi lo espera plano). `assets/` se
  queda en runtime porque `lib/persona.ts` y `lib/sdd-preflight.ts` lo leen
  relativo al módulo; migrará a `core/` cuando esa lógica se extraiga al CLI.
  Preparación para adapters no-Pi (OpenCode) sin tocar comportamiento.

## [0.14.6] - 2026-07-02

### Added

- **Tema pi `ein`** (`themes/ein.json`): la paleta brutalista del banner
  aplicada a toda la TUI — Concrete `#FAF3F0` como texto, Structure `#737373`
  para lo secundario, Industrial Yellow `#FFCA40` como único acento y fondos
  derivados de Carbon `#0C0011`. El indicador de thinking escala del gris al
  amarillo industrial según el esfuerzo. `settings.json` del template arranca
  con `theme: ein`; el bundle incluye `themes/` pero el deploy NO lo gestiona
  como dir manejado (criterio `skills/`: un `ein update` no destruye temas
  personales).
- **Coste real por cambio en `ein_sdd_status`.** Nuevo `readSddRealCost()` en
  `sdd-router.ts`: suma el consumo REAL de inferencia desde los `meta.json`
  de `.pi-subagents/artifacts/` (atribución determinista por mención del
  cambio en el task del run) y el status muestra `coste real: N runs · in/out
  · $ · min` con desglose por agente, junto al budget del ledger (tokens
  estimados de lectura — otra magnitud). Un cambio real que el status
  reportaba como `consumed≈9000` costó 910k tokens y $3.71.
- **Procedencia de artefactos SDD.** Si el parent persiste un artefacto por
  fallback debe marcarlo con `authored_by: parent-fallback`; `lintChange`
  emite `WARNING provenance-parent-fallback-<fase>` para que verify/review
  sepan que no lo escribió el executor de fase. Prohibido fabricar números de
  ledger que el hijo no reportó.

### Changed

- **El acceptance de `sdd-apply` pasa de atestación a verificación mecánica.**
  Los applies behavioral se delegan con `acceptance: { level: "verified",
  verify: [...] }` usando los comandos reales de `openspec/config.yaml`
  (`testing.runner`/`testing.typecheck`): el runner de `pi-subagents`
  re-ejecuta los comandos al terminar el hijo y rechaza el run si fallan — un
  modelo barato ya no puede afirmar tests verdes que nunca corrió. Los applies
  mecánicos (taxonomía `tdd: "off"`) llevan `level: "none"` con reason porque
  `verified`/`checked` exigen estructuralmente evidencia `tests-added` que un
  apply honesto sin tests no puede producir. `sdd-apply.md` gana la sección
  "Runtime Acceptance Verification": prohibido amañar la verificación —
  `blocked` honesto antes que verde mentiroso.

## [0.14.5] - 2026-07-02

### Fixed

- **`sdd-map` ya no puede interbloquearse pidiendo permiso para escribir su
  artefacto.** Su contrato era autocontradictorio: una línea ordenaba
  "Write map notes to `map.md`" y otra decía que la chain lo captura — con
  tools `read, grep, glob` (sin write). En un run real el agente escaló al
  supervisor vía intercom, la reply nunca le llegó (los hijos no interactivos
  no reciben replies mid-run) y el padre acabó escribiendo `map.md` a mano.
  Nuevo **Artifact Persistence Contract** en `sdd-map.md`: el RUNNER persiste
  el artefacto (step de chain con `outputMode: file-only`, o `output` +
  `outputMode` pasados por el padre en modo fase a fase) y el agente emite
  SIEMPRE su output final como el contenido completo listo-para-persistir;
  la falta de write tool es intencional, no un bloqueo.
- **Falsos `acceptance: rejected` en fases de planificación.** `pi-subagents`
  infiere el nivel de acceptance del texto de la task y exige un
  `acceptance-report` con evidencias con forma de código (changed-files,
  tests-added, commands-run) que un artefacto de planificación no puede
  satisfacer — scope/design/tasks salían `rejected` con artefactos perfectos.
  Nueva regla en `orchestrator.md`: fases de planificación (`scope`, `map`,
  `design`, `tasks`, `close`) se delegan con `acceptance: { level: "none",
  reason: ... }` porque `ein_sdd_check` es el gate determinista real;
  `apply`/`verify` mantienen auto (ahí un `rejected` es señal); y el loop SDD
  NUNCA se rutea por el veredicto de acceptance, siempre por
  `ein_sdd_status` + `ein_sdd_check`.

### Changed

- **Fail-fast en los 7 agentes de fase SDD.** Todos los `sdd-*.md` prohíben
  bloquearse en asks de supervisor/intercom (un hijo no interactivo no puede
  recibir la reply): ante un bloqueo devuelven inmediatamente
  `status: blocked` con la causa concreta y qué debe arreglar el padre.
- **`orchestrator.md`: asks de intercom bajo sospecha.** El runtime puede
  entregar un ask minutos después de que su run terminara. Antes de actuar
  sobre CUALQUIER ask: `intercom pending` + realidad (`ein_sdd_status` /
  artefacto en disco); si ya está resuelto se ignora — nunca se rehace una
  fase por un ask tardío. Y al delegar `sdd-map` directo, pasar siempre
  `output` + `outputMode: "file-only"`; si aun así falta el artefacto, se
  persiste desde el envelope/`_output.md`, sin re-runs ni bucles de polling.

### Added

- **`tests/sdd-phase-runtime-contract.test.ts`** (17 casos): pinnea el
  contrato de persistencia de `sdd-map`, la regla fail-fast en los 7 agentes
  y las reglas de acceptance del orquestador.

## [0.14.0] - 2026-07-02

### Changed

- **Prompts con un dueño por política (−39% de contexto fijo del padre).**
  `AGENTS.md` queda reducido a las reglas que comparten TODAS las sesiones
  (170 → 44 líneas): la política de coordinación vive solo en
  `assets/orchestrator.md`, los contratos de ejecución en cada `agents/*.md`,
  y lo que ya es determinista en código (gates, guardrails, router) solo se
  referencia, no se re-especifica. Se elimina la contradicción entre los
  "Human Approval Gates" de AGENTS.md y el gate determinista de entrega en
  modo `auto` (causa raíz del doble-ask), y el contrato docente de 7 puntos
  obligatorios pasa a ser proporcional al peso del cambio (criterio único:
  "synthesis weight matches change weight" del orquestador).
- **`orchestrator.md` comprimido** (~4300 → ~3100 palabras) conservando todas
  las reglas y frases de contrato testeadas; menos anécdota, misma normativa.

### Added

- **Raíz de cambios SDD dual.** `resolveChangesDir()` en `sdd-router.ts`:
  `openspec/changes/` sigue siendo canónica; si no existe pero hay
  `.sdd/changes/` (gramática previa / herramienta externa), el router, el
  gatekeeper (`lintChange`), el cierre (`closeChange`) y la extensión la usan.
  Alias de artefactos legacy: `explore.md` cuenta como scope+map y `apply.md`
  como design, de modo que `ein_sdd_status`/`ein_sdd_check`/`/ein:sdd-close`
  funcionan sobre trabajo existente sin migrar ficheros.

### Fixed

- **Guardrails: negación de entrega POR VERBO/CLÁUSULA, no por texto.**
  Antes cualquier negación ("…pero no hagas merge") cancelaba TODO el texto y
  el push/PR legítimo quedaba sin grant → bloqueo headless y retry-loop.
  Ahora solo se descarta el verbo negado (negador a ≤16 chars, sin cruzar
  comas): "abre PR pero no hagas merge" emite el grant del PR. En el mensaje
  del usuario (`messageRequestsDelivery`) la negación sigue vetando la
  autorización automática (conservador), pero acotada por cláusula: "no rompas
  nada, haz push" ya autoriza.
- **Guardrails: `push` a secas ya no emite grant.** "implementa push
  notifications" abría una ventana de 10 min en la que cualquier `git push`
  headless pasaba sin confirmación. Ahora la task debe nombrar la entrega con
  contexto (`git push`, `haz push`, `push the branch`, `push to origin`,
  `pushea`, orden completa "push") — mismo criterio que documenta el
  orquestador para re-delegar.

## [0.13.5] - 2026-07-01

### Fixed

- **Delegación/PR: detección `open-PR` y `delegated`.** Los patrones de entrega en
  `guardrails.ts` y `git-delivery.ts` ahora reconocen `open-PR` (alias de `open_pr`)
  y `delegated` como modos de entrega válidos. `taskRequestsGuardedDelivery()` y
  `requestsCommitLikeAction()` devuelven `false` cuando el intent es explícitamente
  `delegated` u `open-PR`.

- **Seguridad: negación primero en `taskRequestsGuardedDelivery()`.** Verificación
  de patrones de negación (`no push`, `sin commit`, `do not tag`) *antes* de evaluar
  patrones positivos, evitando falsos positivos en frases como "haz commit pero sin push".

- **Loop `ask_user_question` en delivery: cortado.** La recursión infinita entre
  `ask_user_question` y delivery se corta en raíz — si la task头来 pide entrega
  pero no puede auto-delegarse, se responde con el tool result directamente sin
  volver a preguntar.

- **Tests de guardrails actualizados.** Casos para `delegated`, `open-PR` y
  negaciones añadidos; antiguos casos de negación corregidos.

## [0.13.3] - 2026-06-30

### Changed

- **`ein-readme` migrate a skill local.** El agente de generación de README pasa de
  `agents/ein-readme.md` (subagent visible) a `skills/local/readme-style/SKILL.md`
  (skill local). Ya no aparece en el inventario de subagentes del orquestador ni
  en la documentación arquitectónica. Se invoca implícitamente cuando el contexto
  lo requiere; no necesita `subagent({ agent: "ein-readme" })`.

- **Nota de estilo: `Vandal Note` → `_note:`.** La marca estética en los README
  generados cambia de `> _Vandal Note:` a `> _note:` — una convención de estilo
  neutral que no funciona como título de autor ni marca personal.

### Fixed

- **Negación en `taskRequestsGuardedDelivery()` (`guardrails.ts`).** La función
  que detecta si una task de delegación pide push/commit no manejaba negaciones:
  frases como "haz commit pero sin push", "sin push", "do not push" devolvían
  `true` cuando debían devolver `false`. Añadido `DELIVERY_NEGATION_PATTERNS`
  (copiado de `git-delivery.ts`) con verificación previa a los patrones positivos.

- **Ruta del template en `installer/README.md`.** El comment de `bundle-template`
  decía `../.pi/agent` y ahora dice `../ein-pi/agent` (ruta real del repo).

- **Ejemplo de release hardcoded en `README.md`.** El tag de ejemplo cambiaba de
  `installer-v0.13.0` a `installer-v0.13.3`.

## [0.13.2] - 2026-06-29

### Changed

- **Las tools SDD deterministas ya no vuelcan JSON crudo en la conversación.**
  `ein_sdd_status` y `ein_sdd_check` ahora devuelven el mismo texto compacto y
  legible que los comandos `/ein:sdd-status` y `/ein:sdd-audit` (`formatSddStatus`
  / `formatChangeLint`), en vez de un muro de `JSON.stringify(..., null, 2)` con
  el array `tasks.items[]` entero. El report/estado crudo viaja ahora en
  `details` para uso programático. El orquestador sigue enrutando por la línea
  `next:`.

### Fixed

- **Falsos positivos del aviso "subagent needs attention".** Nuevo
  `extensions/subagent/config.json` que sube `control.needsAttentionAfterMs` de
  60s a 240s, alineado con el umbral de "active long-running" de `pi-subagents`.
  Los modelos baratos (MiniMax) dejan de disparar el nudge durante applies
  multi-fichero largos, sin perder la detección de cuelgues reales.
- **`subagent list` repetido y ruidoso.** `orchestrator.md` declara ahora la
  tabla "Subagent Inventory" como fuente autoritativa y prohíbe explícitamente
  llamar a `subagent({ action: "list" })`.

## [0.13.1] - 2026-06-29

### Added

- **Skill propia `slidev`**. Construir, editar y exportar presentaciones de
  desarrollador con Slidev (Markdown + Vue): `SKILL.md` + `references/` (syntax,
  cli, layouts, components, animations, code, themes-config, export-deploy,
  presenter). Vive en `skills/local/` y se sincroniza desde `samuhlo/ein-agent`
  como el resto de propias; registrada en `skills-lock.json`.

## [0.13.0] - 2026-06-29

> **Major SDD Workflow Release.** Esta release renombra y consolida las fases
> y agentes SDD definitivas. Es un cambio SemVer minor en código, pero una
> **gran release funcional** para el workflow: las fases, artefactos y comandos
> principales adoptan nombres canónicos.

### Added

- **Fases SDD definitivas** (`scope → map → design → tasks → apply → verify → close`):
  agentes `sdd-scope`, `sdd-map`, `sdd-design`, `sdd-tasks`, `sdd-apply`,
  `sdd-verify`, `sdd-close`; artefactos `scope.md`, `map.md`, `design.md`,
  `tasks.md`, `apply-progress.md`, `verify-report.md`, `summary.md`; helper
  de cierre `sdd-close.ts`. Todo queda bajo el namespace `/ein:sdd-*`.

- **SDD mantiene el namespace OpenSpec** en `openspec/changes/<change>/`; los
  nombres de las fases son definitivos y no se renombrarán.

- **`/ein:sdd-close` como comando canonical** (antes `/ein:sdd-archive`).
  `/ein:sdd-archive` se elimina como alias visible. El routing determinista
  actualiza sus checks para reflejar `close`/`summary` en vez de `archive`/
  `close-report`.

- **Status enriquecido** (`/ein:sdd-status`) con fase actual, siguiente paso,
  artefactos, tareas, blockers y budget. **`/ein:sdd-audit`** queda como
  validación completa de un cambio y `/ein:sdd-check` permanece solo como alias
  legacy de audit.

- **Split `design` / `tasks` formalizado**: `sdd-design` produce el spec
  (`design.md`); `sdd-tasks` lo convierte en checklist ejecutable
  (`tasks.md`). Son fases separadas con gate propio.

### Changed

- Los nombres antiguos `sdd-init`, `sdd-explore` y `sdd-archive` desaparecen
  de la superficie pública del workflow. Solo quedan aliases internos de
  migración para preservar configuraciones de modelos existentes.

- **`/ein:sdd-next`** muestra el siguiente paso recomendado basándose en el
  estado determinista del router. En esta versión `--auto` es dry-run: explica,
  pero no ejecuta fases.

### Migration Note

- **Cambios vivos con `init.md` / `exploration.md`** pueden necesitar
  migración manual a `scope.md` / `map.md`. Las nuevas sesiones SDD usan los
  nombres canonicales desde el primer momento.

### Breaking / Installer Note

> **Nueva release de installer requerida.** El script `install.sh` descarga
> desde `releases/latest`, así que para recibir esta versión es necesario
> publicar el tag `installer-v0.13.0` después de este bump y reinstalar con el
> `curl` de instalación. Un binario viejo ejecutando `ein update` redespliega su
> template embebido viejo; no puede actualizarse a sí mismo hasta que descargues
> la nueva release.

## [0.12.0] - 2026-06-25

### Added

- **Capa de estado SDD determinista** en TS puro expuesta como tools de Pi:
  - **Router** (`lib/sdd-router.ts` + tool `ein_sdd_status` + `/ein:sdd-status`):
    calcula en qué fase va un cambio leyendo SOLO los ficheros de
    `openspec/changes/<x>/` y la línea `status:` de verify-report → `nextRecommended`.
    El orquestador enruta por esto, no por lo que el modelo crea recordar.
    Reanudar entre sesiones es gratis: `ein_sdd_status` reubica el cambio sin
    volcar contexto.
  - **Gatekeeper** (`lib/sdd-guardrails.ts` → `lintPhaseArtifact`/`lintChange` +
    tool `ein_sdd_check`): valida cada artefacto de fase (secciones, señales
    obligatorias como el `status:` de verify, placeholders, tamaño) antes de
    avanzar. Una fase mala se re-ejecuta una vez y, si falla, para — no se
    construye sobre basura.
  - **Fase `archive`** (`agents/sdd-archive.md` + `lib/sdd-archive.ts` +
    `/ein:sdd-archive`): condensa un cambio verificado en un `summary.md`
    revisable y mueve los ficheros de trabajo a `openspec/changes/archive/`, así
    `openspec/changes/` solo contiene cambios vivos.

### Changed

- **Flujo SDD fase a fase** en el orquestador: router →
  delegar una fase (`context: "fresh"`, referencias no contenido) → gatekeeper →
  repetir. La chain `ein-sdd` de un tiro queda como fallback (`/run-chain`), no
  como ruta primaria, porque no permite gate intermedio. SDD pasa a 7 fases
  (init → explore → design → tasks → apply → verify → archive).
- Doctor COHERENCIA: checks de router/gatekeeper/archive cableados.

## [0.11.3] - 2026-06-25

### Fixed

- **Documentación pura ya no dispara la pregunta de TDD**. En modo global `ask`,
  un cambio de docs delegado a `sdd-apply` lanzaba el select de TDD si el parent
  no adjuntaba el hint (o si el campo se perdía). Nuevo `delegationIsDocsOnly`:
  detección **determinista** de no-código (señal de docs —`.md`/`README`/
  `CHANGELOG`/"documenta…"— **y** ausencia de señal de código) que se salta el
  gate, independiente del hint. Conservador: ante la duda, pregunta como antes.
- **`sdd-apply` ya no cuelga corriendo un build de producción**. Un
  `bun run build`/`nuxt build` tuberiado por `| tail`/`| head` retiene toda la
  salida hasta el final → el runtime ve "no activity" y lo marca colgado.
  `sdd-apply` tiene prohibido correr un build completo como gate (eso es
  `sdd-verify` o el parent, con env + `timeout`, streaming, nunca por `tail`/
  `head`); el orquestador deja de pedírselo.

### Changed

- **Aviso de TDD solo en `strict`**. `setTaskTddMode` ya no notifica
  `TDD para esta tarea: off` — `off` es un no-evento (mecánico/docs/trivial) y
  anunciarlo era ruido. Solo se avisa cuando TDD queda forzado ON.
- **Higiene de comandos en `sdd-verify`** (donde el build es legítimo): stream
  en vez de buffer, `timeout` siempre, y env del build (`DATABASE_URL`…) o
  reportar que no puede validarse en vez de colgarse.

## [0.11.2] - 2026-06-25

### Fixed

- **`ein-git` ya no se cuelga al abrir el PR**. El cuelgue #1 de delivery: en un
  subagente headless (sin TTY), un `gh pr create` pelado cae en su prompt de
  título / editor de body y **arde hasta el timeout** (minutos de reloj, casi sin
  tool calls). `agents/ein-git.md` manda ahora la receta **no interactiva
  obligatoria**: body a fichero (`mktemp` + heredoc `<<'EOF'`), flags explícitos
  `--title`/`--body-file`/`--base`/`--head`, prefijo `GH_PROMPT_DISABLED=1
  GH_PAGER=cat`, prohibido el `gh pr create` pelado y el `--web`; read-back por
  `gh pr view --json`. Regla: si un `gh` sigue pidiendo input, arregla los flags
  — no esperes ni reintentes el comando idéntico.

### Changed

- **Precheck de scope `workflow`** en `ein-git`: antes de pushear algo que toca
  `.github/workflows/**`, comprueba `gh auth status`; si falta el scope, STOP +
  `gh auth refresh --scopes workflow` (falla rápido, no lento).
- **`maxRuntimeMs` tirante para delivery**: el orquestador pasa ahora ≈`120000` a
  `ein-git`, nunca el presupuesto de chain (`1800000`) — un cuelgue aborta en
  ~2 min, no en 10.

## [0.11.1] - 2026-06-25

### Changed

- **Review Workload Guard: presupuesto solo-producción**. El gate de tamaño de
  PR mide ahora las líneas de **producción** (`git diff --shortstat` con pathspec
  de exclusión), no el diff entero. Tests y generados (`*.test.*`, `*.spec.*`,
  `**/tests/**`, `*.snap`, `*-lock.*`, `dist/`, `.output/`, `.nuxt/`, `coverage/`,
  `*.min.*`) se **reportan aparte** pero **no cuentan** contra el presupuesto: el
  review gatea sobre lógica, no sobre volumen de test/fixture. Un refactor con
  TDD estricto deja de dispararse por las líneas de los tests que añade. Regla
  reforzada: nunca separar el código de una slice de sus tests en PRs distintos.
  Sincronizado en los tres puntos (parent forecast, preflight, gate de `ein-git`)
  con un test anti-drift.
- **Hand-off cerrado a `sdd-apply`**. Si el parent ya diagnosticó la edición
  exacta, entrega un *patch cerrado* (archivo + `before → after` + tests) y el
  apply no re-escanea el árbol para re-derivar lo que ya recibió (menos tokens
  del modelo barato en fixes triviales).

### Fixed

- **El apply ad-hoc ya no ensucia el repo**. Un `sdd-apply` fuera del chain SDD
  devuelve su report **inline** en vez de escribir un `*.md` de scratch en la
  raíz del proyecto (que luego obligaba a un segundo apply solo para borrarlo).
  Los artefactos in-repo (`openspec/changes/<change>/…`) quedan reservados para
  chains reales. `agents/sdd-apply.md`: "Apply Progress" pasa a chain-only.

## [0.11.0] - 2026-06-25

### Added

- **Modo de entrega git (`/ein:git`, `auto`/`ask`/`off`)**: controla la
  confirmación antes de un push/PR delegado, persistido en `.pi/ein/git.json`.
  En `auto` (default), si tu mensaje pidió la entrega (commit/push/PR) no se
  vuelve a preguntar — ya la autorizaste; la entrega por iniciativa del agente sí
  confirma. `ask` confirma siempre; `off` nunca. El `git push --force*` sigue
  **denegado en seco** en cualquier modo y el grant one-shot se emite igual.
  Nuevos `readGitDeliveryMode()` y `messageRequestsDelivery()`.

### Changed

- **Fin de la doble pregunta de entrega**: el orquestador ya no añade su propio
  `ask_user_question` antes de commit/push/PR/merge — la confirmación es ahora
  responsabilidad única del gate determinista (`confirmDelegatedDelivery` decide
  por modo + intención del mensaje).
- **Gate de TDD `ask` refinado**: deja de preguntar en CADA delegación que
  escribe código. El orquestador clasifica el cambio y adjunta un hint `tdd`
  (`off` en mecánicos —mover/renombrar/config/copy/CSS/docs—, `strict` en lógica
  clara); solo cuando no clasifica se pregunta. Default sigue siendo preguntar
  (degradación segura). Nuevos `readDelegationTddHint()` y
  `gateTddForDelegation()`.

## [0.10.2] - 2026-06-21

### Changed

- **Disciplina de coste del parent endurecida**: el orquestador NUNCA edita
  código (ni un one-liner) — entender → `sdd-explore`, escribir → un `sdd-apply`
  acotado (no la cadena entera), entregar → `ein-git` con `context: "fresh"`
  (deja de arrastrar el hilo del padre: un commit trivial medía ~382k tokens de
  input por `fork` → decenas de miles con `fresh`).
- **Review Workload Guard**: el parent mide el diff (`git diff --stat`) y
  pregunta single/split **antes** de delegar el PR; `ein-git` pasa a backstop.
- **`maxRuntimeMs` obligatorio** en chains como backstop ante stalls de
  proveedor; nudge de inactividad que inspecciona estado antes de interrumpir un
  subagente sano (evita corromper un apply multi-fichero a medias).
- **Voz brutalista** como registro-suelo de toda respuesta, no solo de cambios
  importantes.

### Added

- **Gate determinista de TDD**: se dispara en `tool_call` ante cualquier
  delegación que escriba código (`sdd-apply` directo o dentro de un chain), no
  solo en el trigger SDD explícito. Un cambio ad-hoc también resuelve la decisión
  de TDD (modo `ask`), sin doble pregunta. Nueva `delegationTargetsApply()`.

## [0.10.1] - 2026-06-21

### Fixed

- **Crash del banner al arrancar**: el indicador `MODE` se añadió como fila de un
  solo par y el render desestructura cada fila como dos → `undefined is not
  iterable` tumbaba toda la sesión de Pi. MODE emparejado con TDD + loop
  defensivo (una fila malformada ya nunca crashea el banner).

## [0.10.0] - 2026-06-20

### Added

- **Modos de trabajo Solo / Team** (`/ein:mode`, `lib/mode.ts`): Solo por
  defecto (sin Linear; board = `openspec/changes/` + git + EIN.md), Team activa
  Linear como board + preflight. Indicador `MODE` en el banner y en
  `/ein:status`. El installer escribe el modo global (`--no-linear` → Solo) en
  vez de borrar ficheros.
- **Windows vía WSL**: `install.sh` detecta WSL y despliega la build Linux;
  sección de instalación y roadmap de Windows nativo en el README.

### Changed

- **Orquestador recortado** 625 → ~190 líneas: fusión de reglas redundantes,
  gates reubicados al agente que los ejecuta, diferenciadores intactos
  (teaching, routing caro→barato, EIN.md, SDD-5, Plan/Scope Gate). Test de
  presupuesto anti-engorde.
- **Narrativa mode-aware**: fin del "Linear is the primary board" incondicional
  en prompts, agentes, skills y docs.
- **Modelos**: `sdd-apply` → MiniMax-M3 en ambos presets (M2.7 se quedaba corto
  escribiendo código). `ein-git` entra en el flujo Solo (entrega siempre vía
  subagente, nunca git a pelo desde el orquestador).
- **README** reescrito en estética propia (harness personal, stack curado,
  modelos como elección personal personalizable con `/ein:models`).

## [0.9.5] - 2026-06-19

### Added

- **`EIN.md` — contexto de proyecto versionado** (`/ein:init`): verdad de base
  del repo (comandos, arquitectura, convenciones) que se inyecta al orquestador
  y a las fases SDD para que los modelos baratos no re-descubran lo mismo cada
  run. Dos zonas: **curada** (la escribe el humano; Ein no la pisa) y **auto**
  (comandos detectados de `package.json`/lockfiles + estructura, regenerable),
  con sello `rev` (SHA git) + fecha. `/ein:status` avisa de cuántos commits
  atrás quedó el sello para detectar la deriva.
- **`context-mode`** (`npm:context-mode`) integrado: sandboxea las salidas de
  tools, persiste estado de sesión sobre las compactaciones y añade una KB con
  búsqueda. La mayor palanca de ahorro de contexto en sesiones largas. Se
  autoinstala con los demás paquetes declarados.
- **Fan-out read-only paralelo**: guía en el orquestador para lanzar varios
  `sdd-explore` concurrentes (áreas independientes) y sintetizar. Acota cuándo
  NO usarlo (escrituras, la chain SDD, dependencias entre áreas) y recuerda que
  ahorra reloj, no tokens.

### Changed

- **`ein-github` → `ein-git`**: el agente de entrega también hace git local, no
  solo GitHub. Rename completo (agente, routing de modelos, doctor, verify,
  orquestador, docs) con **alias de migración** que remapea la clave legacy en
  `models.json` al leer (no orfana configs previas).
- **Estado de Ein consolidado bajo `.pi/ein/`**: `.atl/` (registro de skills)
  pasa a `.pi/ein/atl/`, junto a `lang/tdd/persona`. Ein aporta así una sola
  carpeta, en el namespace idiomático de Pi (`.pi/agents`, `.pi/chains`).
- **`.gitignore` con un único bloque gestionado** (`lib/gitignore.ts`): cubre
  `.pi/ein/` y `.piagents/`, idempotente y escrito en `session_start`. Migra
  automáticamente el bloque legacy (`# Local Pi runtime state` + `.atl/`) y
  limpia el `.atl/` huérfano de la raíz (solo ficheros generados; nunca toca
  `.atl/skills`).

### Fixed

- **Ficheros huérfanos al actualizar** (`deploy.ts`): la extracción del tarball
  solo añade/sobrescribe, nunca borra, así que un rename upstream (p. ej.
  `ein-github.md` → `ein-git.md`) dejaba el fichero viejo conviviendo con el
  nuevo. Ahora el deploy hace **reemplazo limpio** de las carpetas 100% del
  template (`agents`, `assets`, `chains`, `docs`, `extensions`, `lib`,
  `prompts`) antes de extraer. Se excluye a propósito `skills/` (skills
  descargadas + symlinks del usuario) y la raíz del agente (`auth.json`,
  `sessions/`, `backups/`, `.sdd/`), que siguen intactos.

## [0.9.2] - 2026-06-17

### Changed

- **`sdd-apply` acotado** (coste/calidad con modelos baratos): se queda en el
  slice del design; **prohibido instalar dependencias/frameworks** por su
  cuenta (si hace falta, para y lo decide el padre); tests enfocados, no
  exhaustivos; en el loop corre solo tests focalizados y la suite completa una
  vez al final (lo holístico es de `sdd-verify`).

### Fixed

- **El modo `ask` de `/ein:tdd` no preguntaba nunca**: se pedía como
  instrucción al padre "antes de apply", que dentro de un chain no dispara.
  Ahora se resuelve de forma determinista en el preflight (`ctx.ui.select`
  real por tarea, vía el `input` hook), con override por sesión.

## [0.9.1] - 2026-06-17

### Added

- **Control de TDD estricto** con `/ein:tdd` (`auto`/`strict`/`off`/`ask`),
  persistente por proyecto en `.pi/ein/tdd.json` y autoritativo sobre
  `openspec/config.yaml`. En modo `ask`, Ein pregunta **antes de cada apply**
  si usar el ciclo RED/GREEN — para retoques visuales/triviales se evita el
  desperdicio de tokens.
- **Indicador en el banner** del estado de TDD y persona.

### Changed

- **Ejecutores más estrechos (coste/calidad con modelos baratos)**:
  - `ein-github` es git/gh exclusivo: prohibido correr tests/builds/linters,
    lecturas mínimas (`git diff --stat`, no el diff completo), sin `grep`/`glob`.
  - `ein-linear` exige metadata completa (project, assignee, state, tags,
    labels, milestone) con recipe determinista de IDs y read-back.
  - Las convenciones de código (comment/logging/file-naming) se inyectan solo
    en el parent y `sdd-apply`, no en delivery/linear/explore.
  - `orchestrator`: hand-off explícito ("da la orden, no el problema") — el
    modelo caro resuelve y pasa tareas pequeñas y concretas a los baratos.

### Fixed

- `/ein:tdd` usa `t()` para su descripción (consistencia de locale es/en).

## [0.9.0] - 2026-06-16

### Added

- **Sistema de idioma con dos ejes**, configurable con `/ein:lang`:
  conversación/UI (locale compartido de `rpiv-i18n`, autodetectado de `LANG`,
  también `pi --locale` / `/languages`) y artefactos PR/commit/Linear (config
  por proyecto en `.pi/ein/lang.json`, hereda el de conversación). Permite
  hablar en castellano y generar PRs/issues en inglés.
- UI bilingüe **es/en**: `/ein:help`, `/ein:status`, panel de `/ein:models`,
  selectores y notificaciones; cabeceras de artefactos traducidas para
  `ein-github` / `ein-linear`.
- `/ein:lang` en la ayuda, grupo de checks **I18N** en el doctor y fila
  **LANG/ARTF** en el banner.
- **CI** (`.github/workflows/ci.yml`): suite de tests + typecheck del
  installer + smoke de empaquetado del template en cada push a `main` y PR.
- Test de **paridad es/en** de las claves de UI (invariante de mantenimiento).
- Tests del sistema de idioma (`tests/lang.test.ts`): ejes, herencia,
  directivas, `pick`/`pickFor`, `buildEinPrompt`.

### Changed

- La **persona** controla solo el **tono**; el idioma se gestiona aparte. El
  modo `samuhlo` ya no fija una variante regional: español peninsular por
  defecto vía la directiva autoritativa de idioma.
- Documentación al día: README + las 5 guías de `docs/` documentan el sistema
  de idioma; cifras corregidas (12 skills locales, "8 grupos de checks").
- `installer/src/core/settings.ts`: funciones puras de preservación de
  settings extraídas de `deploy.ts` (la suite corre sin compilar el template).
- Versión del instalador a `0.9.0` (`version.ts` + `package.json`).

### Removed

- Skill local `comment-writer` (sin uso, heredada de una versión previa).

### Fixed

- El test `deploy-settings` ya no depende del template embebido
  (`template.tar.gz`); la suite queda verde de raíz.

---

Releases anteriores (`installer-v0.8.2` y previas) están en
[GitHub Releases](https://github.com/samuhlo/ein-agent/releases).
