# Engram en ein: evaluación para decidir

Fecha: 11 de septiembre de 2026. **Recomendación: sí a mejorar la integración selectiva existente; no a adoptar completo el comportamiento de gentle-pi/gentle-engram.** Primero reparar recuperación y observabilidad. Después comprobar si el recuerdo mejora los planes y abarata su ejecución con la misma calidad. No hay evidencia aún para prometer ahorro de modelos ni ejecución local más fiable.

## Qué se evaluó

- El MANIFIESTO.md de este árbol de trabajo, incluidos los cambios locales que ya existían. Ein HEAD: `b9e6959b665ba2517cbcb9d02270ff61eb3f7f9b`, con modificaciones previas sin confirmar. No representa un checkout limpio de ese commit.
- gentle-pi, checkout `6c4a69310c1e19c4a11a94e2f58f9706b73fbde9`, package.json 2.5.0. Se usó código descargado: la página indexada de GitHub mostraba información de versión anterior.
- Engram y su proveedor Pi, checkout `de322e985310d453897071d8939cc0683b4e9c65`, `plugin/pi` 0.1.12. gentle-engram vive en el repositorio de Engram, no en un repositorio independiente.
- Binario instalado **Engram 1.20.0**. El código upstream actual y ese binario no se presuponen idénticos.
- Configuración local de Pi y consulta SQLite de solo lectura al cuaderno `~/.engram-ein/engram.db`. Las escrituras experimentales se hicieron exclusivamente en bases temporales.

Entregables: [prueba CLI](engram-probe-2026-09-11.ts), [resultado sin red](engram-probe-2026-09-11.json), [resultado con red](engram-probe-network-2026-09-11.json), [prueba MCP](engram-mcp-probe-2026-09-11.py), [resultado MCP](engram-mcp-probe-2026-09-11.json).

## Cómo lo usa gentle-pi

Hay dos capas distintas. gentle-pi define el flujo de trabajo y permite herramientas de memoria a agentes SDD. gentle-engram aporta las herramientas, el protocolo y los eventos de sesión.

| Momento | Comportamiento observado | Naturaleza |
|---|---|---|
| Inicio de sesión | Inicializa proveedor y estado de disponibilidad | Código del plugin; no implica una búsqueda inicial automática |
| Antes de cada turno del agente | Añade protocolo de memoria; captura el prompt cuando cumple sus condiciones | Código; el prompt se limita a 2.000 caracteres y procesa etiquetas privadas |
| Decisión, arreglo, descubrimiento, configuración, patrón o preferencia | Pide guardar inmediatamente con `mem_save` | Instrucción al modelo, no garantía de que recuerde llamar |
| Recuperación de trabajo anterior | Indica `mem_context`, búsqueda con 1–2 palabras distintivas y lectura completa por ID | Protocolo; contempla ampliar búsqueda a otros proyectos |
| Retorno de agentes | Los contratos piden un bloque final `Key Learnings`, omitible sin aprendizaje reutilizable | Prosa del agente; el proveedor envía resultados de herramientas elegibles al endpoint de captura pasiva |
| Compactación | Intenta archivar resumen, recuperar contexto y preparar una indicación para el siguiente turno | Hook de código con tratamiento de fallos e identidad de sesión |
| Cierre | Pide resumen de sesión antes de responder que terminó | Protocolo; el shutdown no equivale a ese resumen automático |
| Trabajo SDD | Puede persistir artefactos en OpenSpec, Engram o ambos | Elección arquitectónica adicional a guardar aprendizajes |

La captura pasiva no significa guardar todo resultado como observación: se envía para extracción. Sí supone trabajo de transporte y procesamiento para resultados que no producirán recuerdos. El protocolo de memoria actual ocupa aproximadamente **2,7 KB de texto**, además de esquemas de herramientas, resultados e instrucciones SDD. No es una medición de tokens facturados.

Fuentes de implementación: [protocolo y hooks de gentle-engram](https://github.com/Gentleman-Programming/engram/blob/de322e985310d453897071d8939cc0683b4e9c65/plugin/pi/index.ts), [contrato de apply](https://github.com/Gentleman-Programming/gentle-pi/blob/6c4a69310c1e19c4a11a94e2f58f9706b73fbde9/assets/agents/sdd-apply.md), [delegación](https://github.com/Gentleman-Programming/gentle-pi/blob/6c4a69310c1e19c4a11a94e2f58f9706b73fbde9/assets/orchestrator-delegation.md).

En modo Engram sin archivos canónicos, el motor de estado de gentle-pi declara que no tiene autoridad sobre esos artefactos y deriva su recuperación al orquestador. Eso no elimina todas sus garantías deterministas: conserva otras autoridades, como el registro nativo de intentos. Pero **copiar la resolución de fases desde memoria chocaría con el manifiesto de ein**. Fuente: [contrato de estado por almacén](https://github.com/Gentleman-Programming/gentle-pi/blob/6c4a69310c1e19c4a11a94e2f58f9706b73fbde9/assets/support/sdd-status-contract.md).

## Lo que ein ya tiene y lo que realmente ocurre

Ein dispone de almacén compartido aislado, memoria asesora no confiable, presupuestos, filtrado, recibos y guardado tras comprobar artefactos. El modo predeterminado es `off`; la disponibilidad se deduce de nombres de herramientas activas. La recuperación se prepara tras el preflight, de forma asíncrona, con la consulta fija **`SDD session context`**, y queda cacheada por sesión. No es una búsqueda relacionada con la tarea.

El guardado de una fase acepta un `memoryCandidate` explícito. Al cerrar se construye además una nota genérica que remite al cambio archivado: conserva una pista, pero no extrae por sí sola su aprendizaje. Los agentes no tienen permitido llamar directamente a Engram; el padre debe gestionar y trasladar el contexto útil.

Referencias locales: [sesión y consulta](../ein-pi/agent/lib/sdd-session-memory.ts), [preflight](../ein-pi/agent/lib/sdd-preflight.ts), [transporte CLI](../ein-pi/agent/lib/engram-cli.ts), [filtrado y temas](../shared/contracts/memory-contract.ts), [guardado de fases](../ein-pi/agent/lib/sdd-memory-save.ts), [política del padre](../runtime/assets/orchestrator.md).

En la instalación inspeccionada:

- El cuaderno esperado contiene **0 observaciones**. Esto no demuestra que nunca se usara Engram ni descarta recuerdos en otros almacenes; demuestra que ese cuaderno no aporta aprendizajes hoy.
- Existe una copia de gentle-engram 0.1.7 en node_modules, pero no figura en la lista de paquetes activos de settings.json. Tenerla instalada físicamente no prueba que se cargue.
- El MCP de Engram está configurado con `directTools: false`. La prueba de disponibilidad de ein exige ver nombres `mem_save` concretos: hay una posible discrepancia con herramientas expuestas mediante gateway. No se ha abierto una sesión interactiva completa para afirmar qué lista efectiva recibe ese detector.

## Experimento y resultados

Se sembraron seis notas sintéticas basadas en conceptos del manifiesto, en una base temporal. Cada nota tenía una palabra distintiva y una explicación breve. Son casos de contrato y recuperación, **no un benchmark de agentes**.

| Comprobación con binario real | Resultado |
|---|---|
| Guardar seis notas, con red disponible | 6/6 reconocidas como guardadas |
| Buscar por la consulta fija de ein | 0 coincidencias reales |
| Estado que devuelve ein para una consulta sin coincidencias | `retrieved`, incorrectamente |
| Buscar cada nota por su palabra distintiva, salida CLI | 6/6 contienen el aprendizaje esperado |
| Buscar esas mismas notas mediante transporte + filtro de ein | 0/6 conservan el aprendizaje en el contexto preparado |
| Repetir guardado con el mismo tema y contenido nuevo | Una nota actualizada en el caso probado |
| Buscar en otro proyecto explícito | Sin coincidencias en el caso probado |
| MCP: buscar una nota y leer su ID | Recupera el contenido completo de esa nota |

**Causa del fallo principal:** el parser CLI divide cada respuesta por líneas. Cada línea pasa a ser una memoria sin fecha ni tema. El filtro permite solo dos entradas sin frescura comprobada: consume esas plazas con «Found 1 memories» y el título. El cuerpo queda fuera. También convierte «No memories found» en un recuerdo válido.

Sin red, el binario instalado emite un aviso de fallo al consultar actualizaciones en stderr. El adaptador considera inválido cualquier stderr residual: marcó fallidos **los seis guardados aunque las notas existían**, y fallaron las recuperaciones. La variable `ENGRAM_NO_UPDATE_CHECK=1` no evitó ese comportamiento en el binario probado, aunque el código upstream actual sí documenta e implementa esa opción. La repetición con red separó este efecto de los defectos del parser.

MCP ofrece IDs y metadatos en el resultado de búsqueda de la versión instalada, y `mem_get_observation` devuelve el contenido completo dentro de su envoltorio. No debe describirse como JSON completamente tipado de principio a fin: ese binario todavía devuelve parte del contenido en texto y no anuncia `response_format: compact`. El upstream actual añade esa opción. Cualquier sustitución del transporte debe validar la versión y el contrato, no asumir que cambiar CLI por MCP basta.

Validación ejecutada: **48 tests existentes de ein, todos pasan**. Esto muestra una carencia de cobertura frente al formato real, no una integración correcta. También se ejecutaron **26 tests upstream** de herramientas, captura pasiva y recuperación: todos pasan en la repetición sin restricciones. La primera ejecución tuvo un abort nativo de Node en el archivo de captura pasiva; no se atribuye a un defecto del plugin ni se oculta como verde. Estas pruebas no son una ejecución completa de gentle-pi ni demuestran menor coste de modelos.

## Decisión frente al manifiesto

| Opción | Valor y coste | Decisión |
|---|---|---|
| Mantenerlo tal cual | Poco coste adicional, pero recibos incorrectos y contenido perdido | No |
| Instalar todo gentle-engram y copiar el flujo gentle-pi | Mejor captura y recuperación; más instrucciones, herramientas, eventos y decisiones del ejecutor | No como integración directa |
| Reparar y ampliar el cuaderno selectivo de ein | Reutiliza inversión existente; ayuda a preparar planes con precedentes verificados | Sí, por etapas |
| Guardar estado de fases y pruebas solo en Engram | Duplica o desplaza autoridad canónica hacia recuperación e interpretación | No |

El beneficio buscado debe ser **que el modelo capaz prepare una ruta mejor gracias a lo aprendido**, para que el barato la ejecute con razonamiento bajo y sin descubrir de nuevo las mismas restricciones. Dar más herramientas de memoria a todos los ejecutores no demuestra ese beneficio y puede exigirles más interpretación.

### Primera entrega propuesta

Un único comportamiento: **cuando se pide recuperar memoria, ein entrega observaciones reales y completas dentro del presupuesto, o un estado vacío/fallido veraz**.

1. Corregir el contrato de lectura, vacío y confirmación de escritura con pruebas contra el binario real y almacenamiento temporal. Mantener versión/capacidades explícitas y distinguir fallo de operación de aviso accesorio.
2. Verificar disponibilidad efectiva sin confundir herramientas gateway con ausencia del CLI; probar nombre de proyecto desde raíz, subdirectorio y worktree, además del cuaderno compartido entre runtimes.
3. Conservar límites, procedencia y precedencia de disco. Un fallo de memoria no bloquea OpenSpec. No activar todavía captura pasiva universal ni nuevos protocolos globales.

### Ampliación si la base funciona

- Recuperación dirigida por el padre al preparar un trabajo relacionado con antecedentes: pocas palabras distintivas, pocos candidatos y lectura completa solo de los seleccionados. Consultas equivalentes deben reutilizar resultados.
- El padre verifica las lecciones contra el repositorio y las transforma en restricciones concretas del plan. El ejecutor recibe ese plan; no una búsqueda abierta sobre memoria histórica.
- Capturar decisiones, causas de bugs y descubrimientos comprobados, incluidos trabajos pequeños sin SDD completo. Guardar lo que cambie una decisión futura; no todos los pasos ni cierres genéricos.
- Mantener candidatos estructurados y guardado central. Aprovechar la idea de aprendizajes de gentle-pi sin imponer un bloque de prosa repetido a todos los agentes.
- Tras compactación o relevo, recuperar el estado desde disco; consultar Engram solo para antecedentes que ese estado no contiene. La memoria no certifica que tests antiguos sigan siendo válidos.

### Criterio de adopción definitiva

Propuesta de ensayo posterior a la reparación: 12 tareas emparejadas, cuatro con un aprendizaje relevante sembrado desde trabajo verificado, cuatro sin memoria relevante y cuatro con memoria obsoleta o contradictoria. Mismo modelo, razonamiento, plan de partida, límites y pruebas de aceptación; aislar ramas y cuadernos entre condiciones, alternar orden y repetir para reducir variación.

Medir resultado correcto, llamadas y coste del padre, coste de ejecutores, tiempo total, correcciones del plan, memoria realmente usada y errores provocados por recuerdos. Incluir coste de crear y comprobar la nota, no solo el de leerla. Contar esos costes entre reutilizaciones con supuestos explícitos.

Umbral propuesto, no resultado medido: mantener calidad en todos los casos, cero regresiones por memoria obsoleta y una reducción mediana de al menos 15% del coste total en casos con antecedentes, con sobrecoste mediano máximo de 5% cuando no ayuda. Si falla, mantener recuerdo explícito bajo demanda y retirar inyección automática. El corpus pequeño orienta uso propio; no certifica ahorro general ni viabilidad local.

**Decisión disponible hoy:** merece la pena reparar y probar la memoria selectiva de ein. No merece la pena aumentar llamadas indiscriminadamente ni adoptar el sistema completo de gentle-pi. La evidencia actual justifica la reparación; el ahorro económico y la mejora del ejecutor siguen pendientes de una evaluación con agentes.

## Reproducción

Desde la raíz de ein, con Bun, Python 3 y Engram disponibles:

```sh
bun evals/engram-probe-2026-09-11.ts /tmp/ein-engram-result.json
python3 evals/engram-mcp-probe-2026-09-11.py /tmp/ein-engram-result.json /tmp/ein-engram-mcp-result.json
bun test tests/engram-memory-contract.test.ts tests/engram-memory-lifecycle.test.ts tests/ein-sdd-memory-lifecycle.test.ts tests/engram-project-name.test.ts tests/engram-candidate-schema.test.ts tests/engram-single-store.test.ts
```

Cada ejecución CLI crea una base temporal nueva y deja su ruta en el JSON para la prueba MCP. No usa el cuaderno personal. Los resultados varían con el binario y la disponibilidad de red. Los JSON adjuntos conservan la evidencia de esta sesión. No se cambiaron runtime, configuración, manifiesto ni archivos de trabajo previos para esta evaluación.
