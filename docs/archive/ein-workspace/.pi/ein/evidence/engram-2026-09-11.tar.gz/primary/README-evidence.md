# Evidencia Engram / Ein — 2026-09-11

Este archivo reúne experimentos controlados, no una integración desplegada.

- primary/protocol.md: comparación inicial de 40 pares de planificación/ejecución.
- sensitivity/protocol.md: 10 pares adicionales sin exigir atribución de memoria.
- primary/recall-protocol.md: 8 investigaciones de código, separadas.
- primary/final-summary.json y audit.json: métricas finales y auditoría.
- primary/initial-analysis.md: análisis provisional anterior, sustituido por el informe final del repo.
- primary/initial y holdout: código inicial y pruebas visibles/reservadas.
- primary/recall-source: snapshot del código inspeccionado; recall-manifest.json permite comprobarlo. Las ocho copias idénticas se excluyen del archivo para evitar duplicación; audit.json registra que no cambiaron.
- primary/logs y sensitivity/logs: eventos/sesiones Pi, peticiones, pruebas, tipos y diffs.
- primary/memory.ts: prototipo HTTP de recuperación estructurada que reutiliza MemoryLifecycle y renderMemoryAdvisory de Ein. memory-raw.json conserva respuestas del Engram real. store contiene SOLO notas sintéticas de esta prueba.
- identity-probe, capability-probe y topic-probe: comprobaciones independientes de los defectos del adaptador actual.

Para auditar sin modelos, comprobar cada SHA-256 de evidence-manifest.json, leer resultados/planes/diffs y contrastar logs de tests/tipos. No se incluyen credenciales ni node_modules. Los scripts conservan las rutas exactas del experimento; para repetir en otra ubicación, ajustar R/P/REPO/AUTH y las importaciones absolutas. initial, holdout y recall-source conservan los inputs necesarios aunque desaparezcan las carpetas temporales originales. Proveer Bun 1.3.14, Pi 0.85.1, TypeScript 5.9.3, Zod 4.4.3 para fechas, Engram 1.20.0 y un hogar Pi temporal autenticado. Las llamadas de modelo consumen cuota y sus respuestas/caché no son deterministas.

El coste es el reportado por Pi, no una factura. Incluye 110 llamadas: 60 Astra/high y 50 Luna/low, incluidas dos extracciones de notas. Se excluye una comprobación inicial de conectividad sin registro de uso, la preparación/supervisión de Codex, la revisión humana y recursos locales. La captura se suma una vez al total; los escenarios de amortización no la duplican. No se afirma equivalencia del runtime SDD completo, confinamiento del modelo ni viabilidad local.

Incidentes de preparación conservados: initial fechas no resolvía Zod en un primer chequeo previo; se añadió el enlace a la dependencia y los cinco tests iniciales fallaron por comportamiento antes de las llamadas. La primera sonda de capacidades restringía herramientas a read; se repitió sin esa restricción y conectando el gateway. No se cambiaron criterios tras observar fallos de modelos: todos los recorridos terminaron sin timeout ni reintento externo. El ajuste del informe de atribución es un estudio separado y sus resultados no se mezclan con los iniciales.
