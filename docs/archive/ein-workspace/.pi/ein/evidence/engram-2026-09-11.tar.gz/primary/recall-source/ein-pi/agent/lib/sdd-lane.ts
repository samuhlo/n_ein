// =============================================================================
// [CORE] CARRIL DEL CAMBIO
// Un cambio declara con cuántas fases se conduce. Dos carriles, y los elige el
// humano al abrirlo.
//
// POR QUÉ EXISTE -> medido sobre los 44 cambios archivados: 42 usaron las siete
// fases. La ceremonia se paga siempre, también para un cambio de una línea, y el
// manifiesto (§ 008) lo declara no-objetivo explícito.
//
// POR QUÉ LO ELIGE EL HUMANO -> no existe señal determinista ANTES de planificar.
// Lo que mide tamaño (`reviewForecast`) mira el diff ya hecho, y el presupuesto
// declarado solo existe cuando ya hay `tasks.md`: los dos llegan después del
// punto donde hay que decidir. Inventar una heurística ahí ascendería un
// determinismo débil a conclusión, que es lo que § 002 prohíbe.
//
// POR QUÉ `micro` SON CINCO FASES Y NO TRES -> `scope.md` guarda la declaración
// de delta de spec, y sin ella el cierre se bloquea (`spec-delta-unresolved`).
// Cerrar sigue siendo puerta dura. Lo que se ahorra —`map` y `tasks`— son
// justamente las dos fases que LEEN CÓDIGO, las más lentas después de apply.
//
// FAIL CLOSED -> un fichero ausente, ilegible o con un valor desconocido cae a
// `standard`. El error se paga en ceremonia de más, nunca en comprobación de
// menos.
// =============================================================================

import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";

import {
	DEFAULT_LANE,
	LANE_PHASES,
	type SddLane,
	type SddPhase,
} from "./sdd-routing-core.ts";

export { DEFAULT_LANE, LANE_PHASES, type SddLane } from "./sdd-routing-core.ts";

export const SDD_LANES: readonly SddLane[] = ["micro", "standard"];

export const LANE_LABEL: Readonly<Record<SddLane, string>> = Object.freeze({
	micro: "micro (sin map ni tasks)",
	standard: "standard (siete fases)",
});

export function laneConfigPath(changeDir: string): string {
	return join(changeDir, "lane.json");
}

export function normalizeLane(value: unknown): SddLane | undefined {
	if (typeof value !== "string") return undefined;
	const token = value.trim().toLowerCase();
	return (SDD_LANES as readonly string[]).includes(token) ? (token as SddLane) : undefined;
}

export type ChangeLaneInspection = Readonly<{
	lane: SddLane;
	/** Any existing lane.json is an authoritative legacy declaration. */
	exists: boolean;
	/** Whether the existing file contains a recognized lane value. */
	valid: boolean;
}>;

/**
 * Reads the lane and preserves the evidence needed by provenance consumers.
 * Corrupt files remain declarations while falling back to the safe lane.
 */
export function inspectChangeLane(changeDir: string): ChangeLaneInspection {
	const path = laneConfigPath(changeDir);
	if (!existsSync(path)) return Object.freeze({ lane: DEFAULT_LANE, exists: false, valid: false });
	try {
		const parsed: unknown = JSON.parse(readFileSync(path, "utf8"));
		if (typeof parsed === "object" && parsed !== null && !Array.isArray(parsed)) {
			const lane = normalizeLane((parsed as Record<string, unknown>).lane);
			if (lane) return Object.freeze({ lane, exists: true, valid: true });
		}
	} catch {
		// Broken declaration → full ceremony, without erasing its authority.
	}
	return Object.freeze({ lane: DEFAULT_LANE, exists: true, valid: false });
}

/** Reads the effective lane. Unknown state always falls back to `standard`. */
export function readChangeLane(changeDir: string): SddLane {
	return inspectChangeLane(changeDir).lane;
}

export function writeChangeLane(changeDir: string, lane: SddLane): void {
	const path = laneConfigPath(changeDir);
	mkdirSync(dirname(path), { recursive: true });
	writeFileSync(path, `${JSON.stringify({ lane }, null, 2)}\n`);
}

/** ¿Esta fase se ejecuta en este carril? */
export function laneIncludes(lane: SddLane, phase: SddPhase): boolean {
	return LANE_PHASES[lane].includes(phase);
}

/** Las fases que este carril NO ejecuta. Vacío en `standard`. */
export function laneSkips(lane: SddLane): readonly SddPhase[] {
	return LANE_PHASES.standard.filter((phase) => !laneIncludes(lane, phase));
}
